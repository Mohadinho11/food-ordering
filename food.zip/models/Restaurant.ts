import mongoose from "mongoose"

const RestaurantSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please add a restaurant name"],
    trim: true,
    maxlength: [100, "Name cannot be more than 100 characters"],
  },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  description: {
    type: String,
    maxlength: [500, "Description cannot be more than 500 characters"],
  },
  category: {
    type: String,
    required: [true, "Please add a category"],
    enum: [
      "Fast Food",
      "Italian",
      "Japanese",
      "Chinese",
      "Mexican",
      "Indian",
      "Thai",
      "American",
      "Asian",
      "Vegetarian",
      "Desserts",
      "Other",
    ],
  },
  address: {
    street: {
      type: String,
      required: [true, "Please add a street address"],
    },
    city: {
      type: String,
      required: [true, "Please add a city"],
    },
    state: {
      type: String,
      required: [true, "Please add a state"],
    },
    zipCode: {
      type: String,
      required: [true, "Please add a zip code"],
    },
    country: {
      type: String,
      required: [true, "Please add a country"],
      default: "USA",
    },
  },
  phone: {
    type: String,
    required: [true, "Please add a phone number"],
  },
  email: {
    type: String,
    required: [true, "Please add an email"],
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, "Please add a valid email"],
  },
  logo: String,
  coverImage: String,
  openingHours: {
    monday: { open: String, close: String },
    tuesday: { open: String, close: String },
    wednesday: { open: String, close: String },
    thursday: { open: String, close: String },
    friday: { open: String, close: String },
    saturday: { open: String, close: String },
    sunday: { open: String, close: String },
  },
  rating: {
    type: Number,
    min: 0,
    max: 5,
    default: 0,
  },
  reviewCount: {
    type: Number,
    default: 0,
  },
  status: {
    type: String,
    enum: ["active", "inactive", "pending"],
    default: "active",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Create model only if it doesn't exist (for Next.js hot reloading)
const Restaurant = mongoose.models.Restaurant || mongoose.model("Restaurant", RestaurantSchema)

export default Restaurant
