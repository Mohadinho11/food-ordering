import mongoose from "mongoose"

const ReviewSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  restaurant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Restaurant",
    required: true,
  },
  order: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Order",
  },
  rating: {
    type: Number,
    required: [true, "Please add a rating"],
    min: 1,
    max: 5,
  },
  comment: {
    type: String,
    maxlength: [500, "Comment cannot be more than 500 characters"],
  },
  images: [String],
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Prevent user from submitting more than one review per restaurant
ReviewSchema.index({ restaurant: 1, user: 1 }, { unique: true })

// Create model only if it doesn't exist (for Next.js hot reloading)
const Review = mongoose.models.Review || mongoose.model("Review", ReviewSchema)

export default Review
