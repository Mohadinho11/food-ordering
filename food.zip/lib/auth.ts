import type { NextRequest } from "next/server"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

interface DecodedToken {
  id: string
  role: string
}

interface AuthUser {
  userId: string
  email?: string
  role: string
}

interface AuthResult {
  success: boolean
  user?: AuthUser
  error?: string
  status?: number
}

export function generateToken(userId: string) {
  return jwt.sign({ id: userId }, JWT_SECRET, { expiresIn: "30d" })
}

export async function verifyAuth(request: NextRequest): Promise<AuthResult> {
  try {
    // Get token from authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return {
        success: false,
        error: "Not authorized to access this route",
        status: 401,
      }
    }

    // Get token
    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as DecodedToken

    return {
      success: true,
      user: {
        userId: decoded.id,
        role: decoded.role,
      },
    }
  } catch (error) {
    return {
      success: false,
      error: "Not authorized to access this route",
      status: 401,
    }
  }
}
