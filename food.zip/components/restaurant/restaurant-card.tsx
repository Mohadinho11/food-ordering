"use client"

import type React from "react"

import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Star, Clock, DollarSign, MapPin, Heart } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { toast } from "@/hooks/use-toast"
import { useState } from "react"

interface RestaurantCardProps {
  restaurant: {
    id: string
    name: string
    image: string
    cuisine: string
    rating: number
    deliveryTime: string
    deliveryFee: string
    minOrder: string
    distance: string
    isNew?: boolean
    isFeatured?: boolean
  }
}

export function RestaurantCard({ restaurant }: RestaurantCardProps) {
  const router = useRouter()
  const [isFavorite, setIsFavorite] = useState(false)

  const handleOrderNow = (e: React.MouseEvent) => {
    e.preventDefault() // Prevent the Link navigation
    toast({
      title: "Order initiated",
      description: `Starting order from ${restaurant.name}`,
    })
    router.push(`/restaurants/${restaurant.id}/menu`)
  }

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault() // Prevent the Link navigation
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: isFavorite
        ? `${restaurant.name} has been removed from your favorites`
        : `${restaurant.name} has been added to your favorites`,
      variant: isFavorite ? "destructive" : "default",
    })
  }

  // Map cuisine types to appropriate images
  const getRestaurantImage = () => {
    const cuisineMap: Record<string, string> = {
      American: "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?q=80&w=2069&auto=format&fit=crop",
      Italian: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop",
      Japanese: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=2070&auto=format&fit=crop",
      Mexican: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?q=80&w=2080&auto=format&fit=crop",
      Chinese: "https://images.unsplash.com/photo-1563245372-f21724e3856d?q=80&w=2069&auto=format&fit=crop",
      Thai: "https://images.unsplash.com/photo-1562565652-a0d8f0c59eb4?q=80&w=1932&auto=format&fit=crop",
      Indian: "https://images.unsplash.com/photo-1585937421612-70a008356c36?q=80&w=2036&auto=format&fit=crop",
      Salads: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=2070&auto=format&fit=crop",
    }

    return (
      cuisineMap[restaurant.cuisine] ||
      "https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2070&auto=format&fit=crop"
    )
  }

  return (
    <Link href={`/restaurants/${restaurant.id}`} aria-label={`View ${restaurant.name} restaurant details`}>
      <motion.div
        className="restaurant-card group"
        whileHover={{ y: -5 }}
        transition={{ duration: 0.2 }}
        tabIndex={0}
        role="article"
        aria-labelledby={`restaurant-${restaurant.id}-name`}
      >
        <div className="relative h-48 w-full overflow-hidden rounded-t-xl">
          <Image
            src={getRestaurantImage() || "/placeholder.svg"}
            alt={restaurant.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

          {restaurant.isNew && <Badge className="absolute top-3 left-3 bg-primary text-white border-none">New</Badge>}
          {restaurant.isFeatured && (
            <Badge className="absolute top-3 right-3 bg-food-accent text-food-dark border-none">Featured</Badge>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="absolute top-3 right-3 bg-white/20 hover:bg-white/40 text-white rounded-full backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            onClick={toggleFavorite}
            aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
            tabIndex={0}
          >
            <Heart className={`h-5 w-5 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
            <span className="sr-only">{isFavorite ? "Remove from favorites" : "Add to favorites"}</span>
          </Button>
        </div>

        <div className="p-4 flex flex-col flex-grow">
          <div className="flex justify-between items-start mb-2">
            <h3 id={`restaurant-${restaurant.id}-name`} className="font-bold text-lg line-clamp-1">
              {restaurant.name}
            </h3>
            <div className="flex items-center gap-1 bg-food-primary/10 text-food-primary px-2 py-0.5 rounded-full">
              <Star className="h-3.5 w-3.5 fill-food-primary" />
              <span className="text-sm font-medium">{restaurant.rating}</span>
            </div>
          </div>

          <p className="text-muted-foreground text-sm mb-3">{restaurant.cuisine}</p>

          <div className="grid grid-cols-2 gap-2 text-sm mb-3">
            <div className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
              <span>{restaurant.deliveryTime}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <DollarSign className="h-3.5 w-3.5 text-muted-foreground" />
              <span>Min: {restaurant.minOrder}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
              <span>{restaurant.distance}</span>
            </div>
            <div className="flex items-center gap-1.5 text-food-secondary font-medium">
              <span>Fee: {restaurant.deliveryFee}</span>
            </div>
          </div>

          <div className="mt-auto pt-3 border-t">
            <button
              onClick={handleOrderNow}
              className="text-sm font-medium text-food-primary flex items-center justify-center py-1.5 bg-food-primary/5 rounded-full transition-colors group-hover:bg-food-primary group-hover:text-white w-full hover:shadow-md active:scale-95"
              tabIndex={0}
              aria-label={`Order now from ${restaurant.name}`}
            >
              Order Now
            </button>
          </div>
        </div>
      </motion.div>
    </Link>
  )
}
