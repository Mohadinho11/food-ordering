"use client"

import type React from "react"

import Image from "next/image"
import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Plus, Minus, ShoppingBag, Heart, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { toast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface MenuItemProps {
  item: {
    id: string
    name: string
    description: string
    price: number
    image: string
    category: string
    isPopular?: boolean
    isVegetarian?: boolean
  }
}

export function MenuItemCard({ item }: MenuItemProps) {
  const [quantity, setQuantity] = useState(0)
  const [isHovered, setIsHovered] = useState(false)
  const [isFavorite, setIsFavorite] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isAddingToCart, setIsAddingToCart] = useState(false)

  // Get a real image based on the item name
  const getItemImage = () => {
    const foodMap: Record<string, string> = {
      "Classic Cheeseburger":
        "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
      "Bacon Deluxe Burger":
        "https://images.unsplash.com/photo-1553979459-d2229ba7433b?q=80&w=1968&auto=format&fit=crop",
      "Veggie Burger": "https://images.unsplash.com/photo-1520072959219-c595dc870360?q=80&w=2070&auto=format&fit=crop",
      "French Fries": "https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?q=80&w=1925&auto=format&fit=crop",
      "Onion Rings": "https://images.unsplash.com/photo-1639024471283-03518883512d?q=80&w=1974&auto=format&fit=crop",
      "Chocolate Milkshake":
        "https://images.unsplash.com/photo-1572490122747-3968b75cc699?q=80&w=1974&auto=format&fit=crop",
      "Soft Drink": "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=2070&auto=format&fit=crop",
      "Chocolate Brownie":
        "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?q=80&w=1930&auto=format&fit=crop",
      "Caesar Salad": "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?q=80&w=2070&auto=format&fit=crop",
      "Margherita Pizza":
        "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?q=80&w=1974&auto=format&fit=crop",
      "Iced Coffee": "https://images.unsplash.com/photo-1517701604599-bb29b565090c?q=80&w=1974&auto=format&fit=crop",
      "Garlic Bread": "https://images.unsplash.com/photo-1573140401455-cff6d6b4d3a2?q=80&w=1974&auto=format&fit=crop",
    }

    return (
      foodMap[item.name] || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=1780&auto=format&fit=crop"
    )
  }

  const increaseQuantity = () => {
    setQuantity((prev) => prev + 1)
    if (quantity === 0) {
      toast({
        title: "Item added",
        description: `${item.name} added to cart`,
      })
    } else {
      toast({
        title: "Quantity increased",
        description: `${item.name} quantity updated to ${quantity + 1}`,
      })
    }
  }

  const decreaseQuantity = () => {
    if (quantity > 0) {
      setQuantity((prev) => prev - 1)
      if (quantity === 1) {
        toast({
          title: "Item removed",
          description: `${item.name} removed from cart`,
          variant: "destructive",
        })
      } else {
        toast({
          title: "Quantity decreased",
          description: `${item.name} quantity updated to ${quantity - 1}`,
        })
      }
    }
  }

  const addToCart = () => {
    setIsAddingToCart(true)

    // Simulate API call
    setTimeout(() => {
      setIsAddingToCart(false)
      toast({
        title: "Added to cart",
        description: `${quantity}x ${item.name} added to your cart`,
      })
    }, 600)
  }

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: isFavorite
        ? `${item.name} has been removed from your favorites`
        : `${item.name} has been added to your favorites`,
      variant: isFavorite ? "destructive" : "default",
    })
  }

  return (
    <>
      <motion.div
        className="menu-item-card relative"
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        tabIndex={0}
        role="article"
        aria-labelledby={`menu-item-${item.id}-name`}
      >
        <div className="relative h-24 w-24 md:h-28 md:w-28 rounded-lg overflow-hidden shrink-0">
          <Image
            src={getItemImage() || "/placeholder.svg"}
            alt={item.name}
            fill
            className="object-cover transition-transform duration-500 hover:scale-110"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-1 right-1 h-6 w-6 bg-white/70 hover:bg-white/90 rounded-full"
            onClick={toggleFavorite}
            aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
            tabIndex={0}
          >
            <Heart className={`h-3 w-3 ${isFavorite ? "fill-red-500 text-red-500" : "text-gray-700"}`} />
            <span className="sr-only">{isFavorite ? "Remove from favorites" : "Add to favorites"}</span>
          </Button>
        </div>

        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-2">
              <h3 id={`menu-item-${item.id}-name`} className="font-bold">
                {item.name}
              </h3>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 rounded-full hover:bg-gray-100"
                onClick={() => setIsDialogOpen(true)}
                aria-label={`View details for ${item.name}`}
                tabIndex={0}
              >
                <Info className="h-3 w-3 text-gray-500" />
                <span className="sr-only">Item details</span>
              </Button>
            </div>
            <span className="font-bold text-food-primary">${item.price.toFixed(2)}</span>
          </div>

          <div className="flex items-center gap-2 mt-1">
            {item.isPopular && (
              <Badge className="bg-food-accent/10 text-food-accent hover:bg-food-accent/20 border-none">Popular</Badge>
            )}
            {item.isVegetarian && (
              <Badge className="bg-green-100 text-green-700 hover:bg-green-200 border-none">Vegetarian</Badge>
            )}
          </div>

          <p className="text-gray-600 text-sm mt-2 line-clamp-2">{item.description}</p>

          <div className="mt-4 flex items-center justify-between">
            <AnimatePresence initial={false}>
              {quantity > 0 ? (
                <motion.div
                  className="flex items-center gap-3"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.2 }}
                >
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8 rounded-full border-food-primary text-food-primary hover:bg-food-primary/10 active:scale-95 transition-transform"
                    onClick={decreaseQuantity}
                    aria-label="Decrease quantity"
                    tabIndex={0}
                  >
                    <Minus className="h-4 w-4" />
                    <span className="sr-only">Decrease quantity</span>
                  </Button>
                  <span className="font-medium w-4 text-center">{quantity}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8 rounded-full border-food-primary text-food-primary hover:bg-food-primary/10 active:scale-95 transition-transform"
                    onClick={increaseQuantity}
                    aria-label="Increase quantity"
                    tabIndex={0}
                  >
                    <Plus className="h-4 w-4" />
                    <span className="sr-only">Increase quantity</span>
                  </Button>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.2 }}
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-food-primary hover:bg-food-primary/10 hover:text-food-primary px-3 h-8 active:scale-95 transition-transform"
                    onClick={increaseQuantity}
                    aria-label={`Add ${item.name} to cart`}
                    tabIndex={0}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {quantity > 0 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.2 }}
                >
                  <Button
                    className="bg-food-primary hover:bg-food-primary/90 text-white h-8 px-3 active:scale-95 transition-transform"
                    onClick={addToCart}
                    disabled={isAddingToCart}
                    aria-label={`Add ${quantity} ${item.name} to cart`}
                    tabIndex={0}
                  >
                    {isAddingToCart ? (
                      <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-1"></div>
                    ) : (
                      <ShoppingBag className="h-4 w-4 mr-1" />
                    )}
                    Add to Cart
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{item.name}</DialogTitle>
            <DialogDescription>Item details and nutritional information</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="relative h-48 w-full rounded-lg overflow-hidden">
              <Image src={getItemImage() || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Description</h3>
              <p className="text-sm text-gray-600">{item.description}</p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Nutritional Information</h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Calories</span>
                  <span className="font-medium">450 kcal</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Protein</span>
                  <span className="font-medium">22g</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Carbs</span>
                  <span className="font-medium">35g</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Fat</span>
                  <span className="font-medium">18g</span>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="font-bold text-lg">${item.price.toFixed(2)}</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="rounded-full" onClick={toggleFavorite}>
                  <Heart className={`h-4 w-4 mr-1 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                  {isFavorite ? "Saved" : "Save"}
                </Button>
                <Button
                  size="sm"
                  className="rounded-full bg-food-primary hover:bg-food-primary/90"
                  onClick={() => {
                    increaseQuantity()
                    setIsDialogOpen(false)
                  }}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add to Cart
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
