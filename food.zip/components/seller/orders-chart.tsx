"use client"

import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  {
    name: "Jan",
    orders: 240,
  },
  {
    name: "Feb",
    orders: 198,
  },
  {
    name: "Mar",
    orders: 300,
  },
  {
    name: "Apr",
    orders: 250,
  },
  {
    name: "May",
    orders: 320,
  },
  {
    name: "Jun",
    orders: 290,
  },
  {
    name: "Jul",
    orders: 380,
  },
  {
    name: "Aug",
    orders: 420,
  },
  {
    name: "Sep",
    orders: 400,
  },
  {
    name: "Oct",
    orders: 450,
  },
  {
    name: "Nov",
    orders: 430,
  },
  {
    name: "Dec",
    orders: 500,
  },
]

export function OrdersChart() {
  return (
    <ChartContainer
      config={{
        orders: {
          label: "Orders",
          color: "hsl(var(--secondary))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 10,
            left: 10,
            bottom: 0,
          }}
        >
          <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line
            type="monotone"
            dataKey="orders"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-orders)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-orders)",
            }}
          />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}
