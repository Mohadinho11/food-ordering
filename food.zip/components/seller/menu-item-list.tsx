"use client"

import { useState } from "react"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Edit, MoreVertical, Trash2, Eye, BarChart2, Copy } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

// Get a real image based on the item name
const getItemImage = (name: string) => {
  const foodMap: Record<string, string> = {
    "Classic Cheeseburger":
      "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
    "Bacon Deluxe Burger": "https://images.unsplash.com/photo-1553979459-d2229ba7433b?q=80&w=1968&auto=format&fit=crop",
    "Veggie Burger": "https://images.unsplash.com/photo-1520072959219-c595dc870360?q=80&w=2070&auto=format&fit=crop",
    "French Fries": "https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?q=80&w=1925&auto=format&fit=crop",
    "Onion Rings": "https://images.unsplash.com/photo-1639024471283-03518883512d?q=80&w=1974&auto=format&fit=crop",
    "Chocolate Milkshake":
      "https://images.unsplash.com/photo-1572490122747-3968b75cc699?q=80&w=1974&auto=format&fit=crop",
    "Soft Drink": "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=2070&auto=format&fit=crop",
    "Chocolate Brownie":
      "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?q=80&w=1930&auto=format&fit=crop",
    "Caesar Salad": "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?q=80&w=2070&auto=format&fit=crop",
    "Margherita Pizza": "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?q=80&w=1974&auto=format&fit=crop",
    "Iced Coffee": "https://images.unsplash.com/photo-1517701604599-bb29b565090c?q=80&w=1974&auto=format&fit=crop",
    "Garlic Bread": "https://images.unsplash.com/photo-1573140401455-cff6d6b4d3a2?q=80&w=1974&auto=format&fit=crop",
  }

  return foodMap[name] || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=1780&auto=format&fit=crop"
}

// Sample menu items data
const menuItemsData = {
  all: [
    {
      id: 1,
      name: "Classic Cheeseburger",
      description: "Juicy beef patty with cheddar cheese, lettuce, tomato, and special sauce",
      price: 9.99,
      image: getItemImage("Classic Cheeseburger"),
      category: "main",
      isAvailable: true,
      isVegetarian: false,
      isPopular: true,
    },
    {
      id: 2,
      name: "Margherita Pizza",
      description: "Traditional pizza with tomato sauce, mozzarella, and fresh basil",
      price: 12.99,
      image: getItemImage("Margherita Pizza"),
      category: "main",
      isAvailable: true,
      isVegetarian: true,
      isPopular: true,
    },
    {
      id: 3,
      name: "Caesar Salad",
      description: "Crisp romaine lettuce with Caesar dressing, croutons, and parmesan",
      price: 8.99,
      image: getItemImage("Caesar Salad"),
      category: "appetizers",
      isAvailable: true,
      isVegetarian: true,
      isPopular: false,
    },
    {
      id: 4,
      name: "Chocolate Brownie",
      description: "Warm chocolate brownie served with vanilla ice cream",
      price: 6.99,
      image: getItemImage("Chocolate Brownie"),
      category: "desserts",
      isAvailable: true,
      isVegetarian: true,
      isPopular: true,
    },
    {
      id: 5,
      name: "Iced Coffee",
      description: "Cold brewed coffee served over ice with cream and sugar",
      price: 3.99,
      image: getItemImage("Iced Coffee"),
      category: "drinks",
      isAvailable: true,
      isVegetarian: true,
      isPopular: false,
    },
  ],
  appetizers: [
    {
      id: 3,
      name: "Caesar Salad",
      description: "Crisp romaine lettuce with Caesar dressing, croutons, and parmesan",
      price: 8.99,
      image: getItemImage("Caesar Salad"),
      category: "appetizers",
      isAvailable: true,
      isVegetarian: true,
      isPopular: false,
    },
    {
      id: 6,
      name: "Garlic Bread",
      description: "Toasted bread with garlic butter and herbs",
      price: 4.99,
      image: getItemImage("Garlic Bread"),
      category: "appetizers",
      isAvailable: true,
      isVegetarian: true,
      isPopular: false,
    },
  ],
  main: [
    {
      id: 1,
      name: "Classic Cheeseburger",
      description: "Juicy beef patty with cheddar cheese, lettuce, tomato, and special sauce",
      price: 9.99,
      image: getItemImage("Classic Cheeseburger"),
      category: "main",
      isAvailable: true,
      isVegetarian: false,
      isPopular: true,
    },
    {
      id: 2,
      name: "Margherita Pizza",
      description: "Traditional pizza with tomato sauce, mozzarella, and fresh basil",
      price: 12.99,
      image: getItemImage("Margherita Pizza"),
      category: "main",
      isAvailable: true,
      isVegetarian: true,
      isPopular: true,
    },
  ],
  desserts: [
    {
      id: 4,
      name: "Chocolate Brownie",
      description: "Warm chocolate brownie served with vanilla ice cream",
      price: 6.99,
      image: getItemImage("Chocolate Brownie"),
      category: "desserts",
      isAvailable: true,
      isVegetarian: true,
      isPopular: true,
    },
  ],
  drinks: [
    {
      id: 5,
      name: "Iced Coffee",
      description: "Cold brewed coffee served over ice with cream and sugar",
      price: 3.99,
      image: getItemImage("Iced Coffee"),
      category: "drinks",
      isAvailable: true,
      isVegetarian: true,
      isPopular: false,
    },
  ],
}

interface MenuItemListProps {
  category?: string
}

export function MenuItemList({ category = "all" }: MenuItemListProps) {
  const [menuItems, setMenuItems] = useState(menuItemsData[category as keyof typeof menuItemsData])
  const [selectedItem, setSelectedItem] = useState<any>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)

  // Form state for editing
  const [editForm, setEditForm] = useState({
    name: "",
    description: "",
    price: "",
    isVegetarian: false,
    isPopular: false,
  })

  const toggleAvailability = (id: number) => {
    setIsUpdating(true)

    // Simulate API call
    setTimeout(() => {
      setMenuItems(menuItems.map((item) => (item.id === id ? { ...item, isAvailable: !item.isAvailable } : item)))
      setIsUpdating(false)

      const item = menuItems.find((item) => item.id === id)
      const newStatus = item?.isAvailable ? "unavailable" : "available"

      toast({
        title: "Item availability updated",
        description: `${item?.name} is now ${newStatus}`,
      })
    }, 600)
  }

  const viewItem = (item: any) => {
    setSelectedItem(item)
    setIsViewDialogOpen(true)
  }

  const editItem = (item: any) => {
    setSelectedItem(item)
    setEditForm({
      name: item.name,
      description: item.description,
      price: item.price.toString(),
      isVegetarian: item.isVegetarian,
      isPopular: item.isPopular,
    })
    setIsEditDialogOpen(true)
  }

  const saveEditedItem = () => {
    setIsUpdating(true)

    // Simulate API call
    setTimeout(() => {
      const updatedItem = {
        ...selectedItem,
        name: editForm.name,
        description: editForm.description,
        price: Number.parseFloat(editForm.price),
        isVegetarian: editForm.isVegetarian,
        isPopular: editForm.isPopular,
      }

      setMenuItems(menuItems.map((item) => (item.id === selectedItem.id ? updatedItem : item)))
      setIsUpdating(false)
      setIsEditDialogOpen(false)

      toast({
        title: "Item updated",
        description: `${updatedItem.name} has been updated successfully`,
      })
    }, 1000)
  }

  const confirmDelete = (item: any) => {
    setSelectedItem(item)
    setIsDeleteDialogOpen(true)
  }

  const deleteItem = () => {
    setIsDeleteDialogOpen(false)

    // Simulate API call
    toast({
      title: "Deleting item...",
      description: "Please wait while we process your request",
    })

    setTimeout(() => {
      setMenuItems(menuItems.filter((item) => item.id !== selectedItem.id))

      toast({
        title: "Item deleted",
        description: `${selectedItem.name} has been removed from the menu`,
        variant: "destructive",
      })
    }, 1000)
  }

  const duplicateItem = (item: any) => {
    const newItem = {
      ...item,
      id: Math.max(...menuItems.map((item) => item.id)) + 1,
      name: `${item.name} (Copy)`,
    }

    setMenuItems([...menuItems, newItem])

    toast({
      title: "Item duplicated",
      description: `${item.name} has been duplicated`,
    })
  }

  const viewItemStats = (item: any) => {
    toast({
      title: "Item statistics",
      description: `Viewing sales statistics for ${item.name}`,
    })
    // In a real app, this would open a statistics page or modal
  }

  return (
    <div className="space-y-4">
      {menuItems.map((item) => (
        <div
          key={item.id}
          className="flex items-center justify-between p-4 border rounded-lg hover:shadow-md transition-shadow"
        >
          <div className="flex items-center gap-4">
            <div className="relative h-20 w-20 rounded-md overflow-hidden">
              <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-medium">{item.name}</h3>
                {item.isPopular && <Badge variant="secondary">Popular</Badge>}
                {item.isVegetarian && (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    Vegetarian
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
              <p className="text-sm font-medium mt-1">${item.price.toFixed(2)}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Switch
                checked={item.isAvailable}
                onCheckedChange={() => toggleAvailability(item.id)}
                aria-label="Toggle availability"
                disabled={isUpdating}
              />
              <span className="text-sm font-medium">{item.isAvailable ? "Available" : "Unavailable"}</span>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">More</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => viewItem(item)}>
                  <Eye className="h-4 w-4 mr-2" />
                  View item
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => editItem(item)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit item
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => duplicateItem(item)}>
                  <Copy className="h-4 w-4 mr-2" />
                  Duplicate
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => viewItemStats(item)}>
                  <BarChart2 className="h-4 w-4 mr-2" />
                  View stats
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive" onClick={() => confirmDelete(item)}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete item
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}

      {/* View Item Dialog */}
      {selectedItem && (
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{selectedItem.name}</DialogTitle>
              <DialogDescription>Item details and information</DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-4">
              <div className="relative h-48 w-full rounded-lg overflow-hidden">
                <Image
                  src={selectedItem.image || "/placeholder.svg"}
                  alt={selectedItem.name}
                  fill
                  className="object-cover"
                />
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold">Description</h3>
                <p className="text-sm text-gray-600">{selectedItem.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <h3 className="font-semibold text-sm">Price</h3>
                  <p className="font-medium">${selectedItem.price.toFixed(2)}</p>
                </div>
                <div className="space-y-1">
                  <h3 className="font-semibold text-sm">Category</h3>
                  <p className="capitalize">{selectedItem.category}</p>
                </div>
                <div className="space-y-1">
                  <h3 className="font-semibold text-sm">Status</h3>
                  <Badge variant={selectedItem.isAvailable ? "default" : "outline"}>
                    {selectedItem.isAvailable ? "Available" : "Unavailable"}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <h3 className="font-semibold text-sm">Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedItem.isVegetarian && (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Vegetarian
                      </Badge>
                    )}
                    {selectedItem.isPopular && <Badge variant="secondary">Popular</Badge>}
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter className="flex justify-between sm:justify-between">
              <Button
                variant="outline"
                onClick={() => {
                  setIsViewDialogOpen(false)
                  editItem(selectedItem)
                }}
              >
                <Edit className="h-4 w-4 mr-2" />
                Edit Item
              </Button>
              <Button
                variant={selectedItem.isAvailable ? "destructive" : "default"}
                onClick={() => {
                  toggleAvailability(selectedItem.id)
                  setIsViewDialogOpen(false)
                }}
              >
                {selectedItem.isAvailable ? "Mark Unavailable" : "Mark Available"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Item Dialog */}
      {selectedItem && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Menu Item</DialogTitle>
              <DialogDescription>Make changes to the menu item details</DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input
                  id="name"
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  Description
                </Label>
                <Textarea
                  id="description"
                  value={editForm.description}
                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                  className="col-span-3"
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="price" className="text-right">
                  Price
                </Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={editForm.price}
                  onChange={(e) => setEditForm({ ...editForm, price: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">Options</Label>
                <div className="col-span-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <Switch
                      id="isVegetarian"
                      checked={editForm.isVegetarian}
                      onCheckedChange={(checked) => setEditForm({ ...editForm, isVegetarian: checked })}
                    />
                    <Label htmlFor="isVegetarian">Vegetarian</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="isPopular"
                      checked={editForm.isPopular}
                      onCheckedChange={(checked) => setEditForm({ ...editForm, isPopular: checked })}
                    />
                    <Label htmlFor="isPopular">Mark as Popular</Label>
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={saveEditedItem} disabled={isUpdating}>
                {isUpdating ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Menu Item</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedItem?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={deleteItem}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
