"use client"

import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  {
    date: "Jan",
    sales: 4000,
    orders: 240,
  },
  {
    date: "Feb",
    sales: 3000,
    orders: 198,
  },
  {
    date: "Mar",
    sales: 5000,
    orders: 300,
  },
  {
    date: "Apr",
    sales: 4000,
    orders: 250,
  },
  {
    date: "May",
    sales: 6000,
    orders: 320,
  },
  {
    date: "Jun",
    sales: 5500,
    orders: 290,
  },
  {
    date: "Jul",
    sales: 7000,
    orders: 380,
  },
  {
    date: "Aug",
    sales: 8000,
    orders: 420,
  },
  {
    date: "Sep",
    sales: 7500,
    orders: 400,
  },
  {
    date: "Oct",
    sales: 9000,
    orders: 450,
  },
  {
    date: "Nov",
    sales: 8500,
    orders: 430,
  },
  {
    date: "Dec",
    sales: 10000,
    orders: 500,
  },
]

export function SellerOverviewChart() {
  return (
    <ChartContainer
      config={{
        sales: {
          label: "Sales",
          color: "hsl(var(--primary))",
        },
        orders: {
          label: "Orders",
          color: "hsl(var(--secondary))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 10,
            left: 10,
            bottom: 0,
          }}
        >
          <XAxis dataKey="date" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `$${value}`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line
            type="monotone"
            dataKey="sales"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-sales)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-sales)",
            }}
          />
          <Line
            type="monotone"
            dataKey="orders"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-orders)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-orders)",
            }}
          />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}
