"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Eye, MoreVertical, Printer, Phone, MapPin, AlertTriangle, Check, Clock } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

// Sample orders data
const ordersData = {
  all: [
    {
      id: "ORD-7352",
      customer: {
        name: "John Smith",
        image: "https://randomuser.me/api/portraits/men/32.jpg",
        phone: "+1 (555) 123-4567",
        address: "123 Main St, Anytown, USA",
      },
      items: ["Chicken Burger", "Fries", "Coke"],
      total: "$24.50",
      status: "pending",
      date: "2023-05-15T14:30:00",
      timeAgo: "2 minutes ago",
    },
    {
      id: "ORD-7351",
      customer: {
        name: "Sarah Johnson",
        image: "https://randomuser.me/api/portraits/women/44.jpg",
        phone: "+1 (555) 987-6543",
        address: "456 Oak Ave, Somewhere, USA",
      },
      items: ["Margherita Pizza", "Garlic Bread"],
      total: "$18.99",
      status: "preparing",
      date: "2023-05-15T14:15:00",
      timeAgo: "15 minutes ago",
    },
    {
      id: "ORD-7350",
      customer: {
        name: "Michael Brown",
        image: "https://randomuser.me/api/portraits/men/22.jpg",
        phone: "+1 (555) 456-7890",
        address: "789 Pine St, Nowhere, USA",
      },
      items: ["Caesar Salad", "Iced Tea"],
      total: "$12.99",
      status: "ready",
      date: "2023-05-15T13:45:00",
      timeAgo: "45 minutes ago",
    },
    {
      id: "ORD-7349",
      customer: {
        name: "Emily Davis",
        image: "https://randomuser.me/api/portraits/women/67.jpg",
        phone: "+1 (555) 234-5678",
        address: "321 Elm St, Elsewhere, USA",
      },
      items: ["Chocolate Brownie", "Coffee"],
      total: "$8.50",
      status: "delivered",
      date: "2023-05-15T13:00:00",
      timeAgo: "1 hour ago",
    },
    {
      id: "ORD-7348",
      customer: {
        name: "David Wilson",
        image: "https://randomuser.me/api/portraits/men/54.jpg",
        phone: "+1 (555) 876-5432",
        address: "654 Maple Ave, Anywhere, USA",
      },
      items: ["Veggie Wrap", "Smoothie"],
      total: "$14.75",
      status: "delivered",
      date: "2023-05-15T12:00:00",
      timeAgo: "2 hours ago",
    },
  ],
  pending: [
    {
      id: "ORD-7352",
      customer: {
        name: "John Smith",
        image: "https://randomuser.me/api/portraits/men/32.jpg",
        phone: "+1 (555) 123-4567",
        address: "123 Main St, Anytown, USA",
      },
      items: ["Chicken Burger", "Fries", "Coke"],
      total: "$24.50",
      status: "pending",
      date: "2023-05-15T14:30:00",
      timeAgo: "2 minutes ago",
    },
  ],
  preparing: [
    {
      id: "ORD-7351",
      customer: {
        name: "Sarah Johnson",
        image: "https://randomuser.me/api/portraits/women/44.jpg",
        phone: "+1 (555) 987-6543",
        address: "456 Oak Ave, Somewhere, USA",
      },
      items: ["Margherita Pizza", "Garlic Bread"],
      total: "$18.99",
      status: "preparing",
      date: "2023-05-15T14:15:00",
      timeAgo: "15 minutes ago",
    },
  ],
  ready: [
    {
      id: "ORD-7350",
      customer: {
        name: "Michael Brown",
        image: "https://randomuser.me/api/portraits/men/22.jpg",
        phone: "+1 (555) 456-7890",
        address: "789 Pine St, Nowhere, USA",
      },
      items: ["Caesar Salad", "Iced Tea"],
      total: "$12.99",
      status: "ready",
      date: "2023-05-15T13:45:00",
      timeAgo: "45 minutes ago",
    },
  ],
  delivered: [
    {
      id: "ORD-7349",
      customer: {
        name: "Emily Davis",
        image: "https://randomuser.me/api/portraits/women/67.jpg",
        phone: "+1 (555) 234-5678",
        address: "321 Elm St, Elsewhere, USA",
      },
      items: ["Chocolate Brownie", "Coffee"],
      total: "$8.50",
      status: "delivered",
      date: "2023-05-15T13:00:00",
      timeAgo: "1 hour ago",
    },
    {
      id: "ORD-7348",
      customer: {
        name: "David Wilson",
        image: "https://randomuser.me/api/portraits/men/54.jpg",
        phone: "+1 (555) 876-5432",
        address: "654 Maple Ave, Anywhere, USA",
      },
      items: ["Veggie Wrap", "Smoothie"],
      total: "$14.75",
      status: "delivered",
      date: "2023-05-15T12:00:00",
      timeAgo: "2 hours ago",
    },
  ],
}

interface OrderListProps {
  status?: string
}

export function OrderList({ status = "all" }: OrderListProps) {
  const [orders, setOrders] = useState(ordersData[status as keyof typeof ordersData])
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false)
  const [isStatusUpdating, setIsStatusUpdating] = useState(false)
  const [isPrinting, setIsPrinting] = useState(false)

  const updateOrderStatus = (id: string, newStatus: string) => {
    setIsStatusUpdating(true)

    // Simulate API call
    setTimeout(() => {
      setOrders(orders.map((order) => (order.id === id ? { ...order, status: newStatus } : order)))
      setIsStatusUpdating(false)
      toast({
        title: "Order status updated",
        description: `Order ${id} status changed to ${newStatus}`,
      })
    }, 600)
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "outline"
      case "preparing":
        return "default"
      case "ready":
        return "secondary"
      case "delivered":
        return "outline"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  const viewOrderDetails = (order: any) => {
    setSelectedOrder(order)
    setIsDetailsOpen(true)
  }

  const printReceipt = (id: string) => {
    setIsPrinting(true)

    // Simulate printing process
    setTimeout(() => {
      setIsPrinting(false)
      toast({
        title: "Receipt printed",
        description: `Receipt for order ${id} has been sent to printer`,
      })
    }, 1500)
  }

  const cancelOrder = (id: string) => {
    // Close the cancel dialog
    setIsCancelDialogOpen(false)

    // Simulate API call
    toast({
      title: "Cancelling order...",
      description: "Please wait while we process your request",
    })

    setTimeout(() => {
      setOrders(orders.map((order) => (order.id === id ? { ...order, status: "cancelled" } : order)))
      toast({
        title: "Order cancelled",
        description: `Order ${id} has been cancelled`,
        variant: "destructive",
      })
    }, 1000)
  }

  const callCustomer = (phone: string) => {
    // In a real app, this would use a phone API or show the number
    toast({
      title: "Calling customer",
      description: `Dialing ${phone}`,
    })
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div
          key={order.id}
          className="flex items-center justify-between p-4 border rounded-lg hover:shadow-md transition-shadow"
        >
          <div className="flex items-center gap-4">
            <Avatar>
              <AvatarImage src={order.customer.image} alt={order.customer.name} />
              <AvatarFallback>{order.customer.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium">{order.id}</p>
                <Badge variant={getStatusBadgeVariant(order.status)}>{order.status}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{order.customer.name}</p>
              <p className="text-sm text-muted-foreground">{order.items.join(", ")}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium">{order.total}</p>
              <p className="text-sm text-muted-foreground">{order.timeAgo}</p>
            </div>
            <Select
              defaultValue={order.status}
              onValueChange={(value) => updateOrderStatus(order.id, value)}
              disabled={order.status === "cancelled" || order.status === "delivered" || isStatusUpdating}
            >
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="preparing">Preparing</SelectItem>
                <SelectItem value="ready">Ready</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">More</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => viewOrderDetails(order)}>
                  <Eye className="h-4 w-4 mr-2" />
                  View details
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => printReceipt(order.id)} disabled={isPrinting}>
                  <Printer className="h-4 w-4 mr-2" />
                  Print receipt
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => callCustomer(order.customer.phone)}>
                  <Phone className="h-4 w-4 mr-2" />
                  Call customer
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive"
                  onClick={() => {
                    setSelectedOrder(order)
                    setIsCancelDialogOpen(true)
                  }}
                  disabled={order.status === "cancelled" || order.status === "delivered"}
                >
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Cancel order
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}

      {/* Order Details Dialog */}
      {selectedOrder && (
        <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Order Details</DialogTitle>
              <DialogDescription>
                Order {selectedOrder.id} - {selectedOrder.timeAgo}
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={selectedOrder.customer.image} alt={selectedOrder.customer.name} />
                  <AvatarFallback>{selectedOrder.customer.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-medium">{selectedOrder.customer.name}</h3>
                  <p className="text-sm text-muted-foreground">{selectedOrder.customer.phone}</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                  <p className="text-sm">{selectedOrder.customer.address}</p>
                </div>
                <div className="flex items-start gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                  <p className="text-sm">Ordered {selectedOrder.timeAgo}</p>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Order Items</h3>
                <ul className="space-y-1">
                  {selectedOrder.items.map((item: string, index: number) => (
                    <li key={index} className="text-sm flex justify-between">
                      <span>{item}</span>
                      <span className="font-medium">${(Math.random() * 10 + 5).toFixed(2)}</span>
                    </li>
                  ))}
                </ul>
                <div className="border-t pt-2 mt-2 flex justify-between font-medium">
                  <span>Total</span>
                  <span>{selectedOrder.total}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Status</h3>
                <div className="flex items-center gap-2">
                  <Badge variant={getStatusBadgeVariant(selectedOrder.status)}>{selectedOrder.status}</Badge>
                  {selectedOrder.status === "pending" && (
                    <span className="text-xs text-muted-foreground">Waiting for confirmation</span>
                  )}
                  {selectedOrder.status === "preparing" && (
                    <span className="text-xs text-muted-foreground">In the kitchen</span>
                  )}
                  {selectedOrder.status === "ready" && (
                    <span className="text-xs text-muted-foreground">Ready for pickup/delivery</span>
                  )}
                </div>
              </div>
            </div>

            <DialogFooter className="flex justify-between sm:justify-between">
              <Button variant="outline" onClick={() => callCustomer(selectedOrder.customer.phone)}>
                <Phone className="h-4 w-4 mr-2" />
                Call Customer
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => printReceipt(selectedOrder.id)} disabled={isPrinting}>
                  {isPrinting ? (
                    <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin mr-2"></div>
                  ) : (
                    <Printer className="h-4 w-4 mr-2" />
                  )}
                  Print
                </Button>
                {selectedOrder.status !== "cancelled" && selectedOrder.status !== "delivered" && (
                  <Button
                    variant="default"
                    onClick={() => {
                      const nextStatus =
                        {
                          pending: "preparing",
                          preparing: "ready",
                          ready: "delivered",
                        }[selectedOrder.status] || "delivered"

                      updateOrderStatus(selectedOrder.id, nextStatus)
                      setIsDetailsOpen(false)
                    }}
                  >
                    <Check className="h-4 w-4 mr-2" />
                    {selectedOrder.status === "ready" ? "Mark Delivered" : "Update Status"}
                  </Button>
                )}
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Cancel Order Confirmation Dialog */}
      <AlertDialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Order</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to cancel order {selectedOrder?.id}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>No, keep order</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => cancelOrder(selectedOrder?.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Yes, cancel order
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
