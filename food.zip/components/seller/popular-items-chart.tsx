"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  {
    name: "Chicken Burger",
    orders: 124,
  },
  {
    name: "Margherita Pizza",
    orders: 98,
  },
  {
    name: "Caesar Salad",
    orders: 87,
  },
  {
    name: "Chocolate Brownie",
    orders: 65,
  },
  {
    name: "Garlic Bread",
    orders: 54,
  },
  {
    name: "Iced Coffee",
    orders: 48,
  },
  {
    name: "Veggie Wrap",
    orders: 42,
  },
]

export function PopularItemsChart() {
  return (
    <ChartContainer
      config={{
        orders: {
          label: "Orders",
          color: "hsl(var(--accent))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          layout="vertical"
          margin={{
            top: 5,
            right: 10,
            left: 80,
            bottom: 0,
          }}
        >
          <XAxis type="number" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis type="category" dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Bar
            dataKey="orders"
            radius={[0, 4, 4, 0]}
            style={{
              fill: "var(--color-orders)",
              opacity: 0.8,
            }}
          />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}
