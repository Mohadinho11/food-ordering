"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { BarChart3, ChefHat, ClipboardList, Home, LogOut, Settings, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function SellerNav() {
  const pathname = usePathname()
  const router = useRouter()

  const navItems = [
    {
      name: "Dashboard",
      href: "/seller",
      icon: Home,
    },
    {
      name: "Menu",
      href: "/seller/menu",
      icon: ChefHat,
    },
    {
      name: "Orders",
      href: "/seller/orders",
      icon: ClipboardList,
    },
    {
      name: "Analytics",
      href: "/seller/analytics",
      icon: BarChart3,
    },
    {
      name: "Settings",
      href: "/seller/settings",
      icon: Settings,
    },
  ]

  const handleLogout = () => {
    // In a real app, you would handle logout logic here
    // For example: clear auth tokens, call logout API, etc.
    console.log("Logging out...")
    router.push("/login")
  }

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-screen sticky top-0 overflow-y-auto">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <ShoppingBag className="h-8 w-8 text-brand-primary" />
          <h1 className="text-xl font-bold">FoodFlex</h1>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const isActive = pathname === item.href

            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  isActive ? "bg-brand-primary/10 text-brand-primary" : "text-gray-700 hover:bg-gray-100"
                }`}
              >
                <item.icon className={`h-5 w-5 ${isActive ? "text-brand-primary" : "text-gray-500"}`} />
                {item.name}
              </Link>
            )
          })}
        </nav>
      </div>

      <div className="p-6 border-t border-gray-200 mt-auto">
        <Button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-100 w-full"
        >
          <LogOut className="h-5 w-5 text-gray-500" />
          Logout
        </Button>
      </div>
    </div>
  )
}
