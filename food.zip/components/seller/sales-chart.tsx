"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  {
    name: "Jan",
    total: 4000,
  },
  {
    name: "Feb",
    total: 3000,
  },
  {
    name: "Mar",
    total: 5000,
  },
  {
    name: "Apr",
    total: 4000,
  },
  {
    name: "May",
    total: 6000,
  },
  {
    name: "Jun",
    total: 5500,
  },
  {
    name: "Jul",
    total: 7000,
  },
  {
    name: "Aug",
    total: 8000,
  },
  {
    name: "Sep",
    total: 7500,
  },
  {
    name: "Oct",
    total: 9000,
  },
  {
    name: "Nov",
    total: 8500,
  },
  {
    name: "Dec",
    total: 10000,
  },
]

export function SalesChart() {
  return (
    <ChartContainer
      config={{
        total: {
          label: "Revenue",
          color: "hsl(var(--primary))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{
            top: 5,
            right: 10,
            left: 10,
            bottom: 0,
          }}
        >
          <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `$${value}`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Bar
            dataKey="total"
            radius={[4, 4, 0, 0]}
            style={{
              fill: "var(--color-total)",
              opacity: 0.8,
            }}
          />
        </BarChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}
