"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { MoreVertical } from "lucide-react"

const orders = [
  {
    id: "ORD-7352",
    customer: {
      name: "John Smith",
      image: "/placeholder.svg?height=32&width=32",
    },
    items: ["Chicken Burger", "Fries", "Coke"],
    total: "$24.50",
    status: "preparing",
    date: "2 minutes ago",
  },
  {
    id: "ORD-7351",
    customer: {
      name: "Sarah Johnson",
      image: "/placeholder.svg?height=32&width=32",
    },
    items: ["Margherita Pizza", "Garlic Bread"],
    total: "$18.99",
    status: "ready",
    date: "15 minutes ago",
  },
  {
    id: "ORD-7350",
    customer: {
      name: "Michael Brown",
      image: "/placeholder.svg?height=32&width=32",
    },
    items: ["Caesar Salad", "Iced Tea"],
    total: "$12.99",
    status: "delivered",
    date: "45 minutes ago",
  },
  {
    id: "ORD-7349",
    customer: {
      name: "Emily Davis",
      image: "/placeholder.svg?height=32&width=32",
    },
    items: ["Chocolate Brownie", "Coffee"],
    total: "$8.50",
    status: "delivered",
    date: "1 hour ago",
  },
  {
    id: "ORD-7348",
    customer: {
      name: "David Wilson",
      image: "/placeholder.svg?height=32&width=32",
    },
    items: ["Veggie Wrap", "Smoothie"],
    total: "$14.75",
    status: "delivered",
    date: "2 hours ago",
  },
]

export function RecentOrders() {
  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
          <div className="flex items-center gap-4">
            <Avatar>
              <AvatarImage src={order.customer.image} alt={order.customer.name} />
              <AvatarFallback>{order.customer.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium">{order.id}</p>
                <Badge
                  variant={
                    order.status === "preparing" ? "default" : order.status === "ready" ? "secondary" : "outline"
                  }
                >
                  {order.status}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{order.customer.name}</p>
              <p className="text-sm text-muted-foreground">{order.items.join(", ")}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium">{order.total}</p>
              <p className="text-sm text-muted-foreground">{order.date}</p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">More</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuItem>View details</DropdownMenuItem>
                <DropdownMenuItem>Update status</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">Cancel order</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}
    </div>
  )
}
