"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { ShoppingBag, Search, Menu, X, ChevronDown, LogIn, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useCart } from "@/contexts/cart-context"

interface NavItem {
  id: string
  label: string
  href: string
  children?: { id: string; label: string; href: string }[]
}

const navItems: NavItem[] = [
  { id: "nav_home", label: "Home", href: "/" },
  {
    id: "nav_restaurants",
    label: "Restaurants",
    href: "/restaurants",
    children: [
      { id: "nav_all_restaurants", label: "All Restaurants", href: "/restaurants" },
      { id: "nav_near_me", label: "Near Me", href: "/restaurants/near-me" },
      { id: "nav_top_rated", label: "Top Rated", href: "/restaurants/top-rated" },
    ],
  },
  { id: "nav_menu", label: "Menu", href: "/menu" },
  { id: "nav_about", label: "About", href: "/about" },
  { id: "nav_contact", label: "Contact", href: "/contact" },
]

// Sample notifications with unique IDs
const notifications = [
  {
    id: "notif_101",
    title: "Order Delivered",
    message: "Your order #ORD-7348 has been delivered",
    time: "5 minutes ago",
    read: false,
  },
  {
    id: "notif_102",
    title: "Special Offer",
    message: "Get 20% off on your next order with code FOOD20",
    time: "2 hours ago",
    read: false,
  },
  {
    id: "notif_103",
    title: "New Restaurant",
    message: "Check out our new partner restaurant 'Spice Garden'",
    time: "1 day ago",
    read: true,
  },
]

export function Header() {
  const pathname = usePathname()
  const router = useRouter()
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false) // Replace with actual auth state
  const [searchQuery, setSearchQuery] = useState("")
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false)
  const [unreadNotifications, setUnreadNotifications] = useState(notifications.filter((n) => !n.read).length)

  const { items, itemCount, subtotal, total, removeItem, updateQuantity } = useCart()

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false)
  }, [pathname])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      toast({
        title: "Search initiated",
        description: `Searching for "${searchQuery}"`,
      })
      // In a real app, this would navigate to search results page
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
      setIsSearchOpen(false)
      setSearchQuery("")
    }
  }

  const handleLogin = () => {
    // In a real app, this would navigate to login page
    setIsLoggedIn(true) // For demo purposes
    toast({
      title: "Logged in successfully",
      description: "Welcome back!",
    })
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    toast({
      title: "Logged out",
      description: "You have been logged out successfully",
    })
  }

  const handleCartClick = () => {
    setIsCartOpen(true)
  }

  const markAllNotificationsAsRead = () => {
    setUnreadNotifications(0)
    toast({
      title: "Notifications marked as read",
      description: "All notifications have been marked as read",
    })
  }

  const deliveryFee = items.length > 0 ? 2.99 : 0
  const tax = subtotal * 0.08 // 8% tax

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled ? "bg-white/95 backdrop-blur-md shadow-sm py-3" : "bg-transparent py-5",
      )}
    >
      <div className="container-custom">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2" aria-label="FoodFlex Home">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <ShoppingBag className="h-8 w-8 text-food-primary" />
            </motion.div>
            <motion.span
              className="text-xl font-bold font-heading"
              initial={{ x: -10, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              FoodFlex
            </motion.span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1" aria-label="Main Navigation">
            {navItems.map((item) => (
              <div key={item.id} className="relative group">
                {item.children ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        className={cn(
                          "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors",
                          pathname === item.href
                            ? "text-food-primary"
                            : "text-foreground/80 hover:text-food-primary hover:bg-food-primary/5",
                        )}
                        aria-expanded="false"
                        aria-haspopup="true"
                        id={`${item.id}-dropdown`}
                      >
                        {item.label}
                        <ChevronDown className="ml-1 h-4 w-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="center"
                      className="w-48 animate-scale-in"
                      aria-labelledby={`${item.id}-dropdown`}
                    >
                      {item.children.map((child) => (
                        <DropdownMenuItem key={child.id} asChild>
                          <Link href={child.href} className="w-full cursor-pointer">
                            {child.label}
                          </Link>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <Link
                    href={item.href}
                    className={cn(
                      "px-3 py-2 text-sm font-medium rounded-md transition-colors",
                      pathname === item.href
                        ? "text-food-primary"
                        : "text-foreground/80 hover:text-food-primary hover:bg-food-primary/5",
                    )}
                    aria-current={pathname === item.href ? "page" : undefined}
                  >
                    {item.label}
                  </Link>
                )}
              </div>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="text-foreground/80 hover:text-food-primary hover:bg-food-primary/5"
              aria-label="Search"
              aria-expanded={isSearchOpen}
            >
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>

            {isLoggedIn && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-foreground/80 hover:text-food-primary hover:bg-food-primary/5 relative"
                    aria-label="Notifications"
                  >
                    <Bell className="h-5 w-5" />
                    {unreadNotifications > 0 && (
                      <span className="absolute -top-1 -right-1 bg-food-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                        {unreadNotifications}
                      </span>
                    )}
                    <span className="sr-only">Notifications</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <div className="flex items-center justify-between p-4 border-b">
                    <h3 className="font-medium">Notifications</h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={markAllNotificationsAsRead}
                      disabled={unreadNotifications === 0}
                    >
                      Mark all as read
                    </Button>
                  </div>
                  <div className="max-h-[300px] overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center text-muted-foreground">No notifications</div>
                    ) : (
                      notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className={cn(
                            "p-4 border-b last:border-b-0 hover:bg-muted/50 cursor-pointer",
                            !notification.read && "bg-muted/20",
                          )}
                        >
                          <div className="flex justify-between items-start">
                            <h4 className="font-medium text-sm">{notification.title}</h4>
                            <span className="text-xs text-muted-foreground">{notification.time}</span>
                          </div>
                          <p className="text-sm mt-1">{notification.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>
            )}

            <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleCartClick}
                  className="text-foreground/80 hover:text-food-primary hover:bg-food-primary/5 relative"
                  aria-label="Shopping cart"
                >
                  <ShoppingBag className="h-5 w-5" />
                  {itemCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-food-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                      {itemCount}
                    </span>
                  )}
                  <span className="sr-only">Cart</span>
                </Button>
              </SheetTrigger>
              <SheetContent className="w-full sm:max-w-md">
                <SheetHeader>
                  <SheetTitle>Your Cart</SheetTitle>
                  <SheetDescription>
                    {items.length === 0 ? "Your cart is empty" : `${items.length} items in your cart`}
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 flex flex-col h-[calc(100vh-10rem)]">
                  {items.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full">
                      <ShoppingBag className="h-12 w-12 text-muted-foreground mb-4" />
                      <p className="text-muted-foreground">Your cart is empty</p>
                      <Button
                        variant="default"
                        className="mt-4"
                        onClick={() => {
                          setIsCartOpen(false)
                          router.push("/menu")
                        }}
                      >
                        Browse Menu
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div className="flex-1 overflow-y-auto pr-2">
                        {items.map((item) => (
                          <div key={item.id} className="flex gap-4 py-4 border-b">
                            <div className="relative h-16 w-16 rounded overflow-hidden shrink-0">
                              <img
                                src={item.image || "/placeholder.svg"}
                                alt={item.name}
                                className="object-cover h-full w-full"
                              />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between">
                                <div>
                                  <h4 className="font-medium text-sm">{item.name}</h4>
                                  <p className="text-xs text-muted-foreground">{item.restaurant}</p>
                                </div>
                                <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                              </div>
                              <div className="flex justify-between items-center mt-2">
                                <div className="flex items-center gap-2">
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-6 w-6 rounded-full"
                                    onClick={() => {
                                      if (item.quantity > 1) {
                                        // Decrease quantity
                                        updateQuantity(item.id, item.quantity - 1)
                                      } else {
                                        // Remove item
                                        removeItem(item.id)
                                      }
                                    }}
                                    aria-label="Decrease quantity"
                                  >
                                    <span className="sr-only">Decrease quantity</span>
                                    <span className="text-xs">-</span>
                                  </Button>
                                  <span className="text-sm">{item.quantity}</span>
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    className="h-6 w-6 rounded-full"
                                    onClick={() => {
                                      // Increase quantity
                                      updateQuantity(item.id, item.quantity + 1)
                                    }}
                                    aria-label="Increase quantity"
                                  >
                                    <span className="sr-only">Increase quantity</span>
                                    <span className="text-xs">+</span>
                                  </Button>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 px-2 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
                                  onClick={() => removeItem(item.id)}
                                  aria-label={`Remove ${item.name} from cart`}
                                >
                                  Remove
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="border-t pt-4 mt-auto">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Subtotal</span>
                            <span>${subtotal.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Delivery Fee</span>
                            <span>${deliveryFee.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Tax</span>
                            <span>${tax.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between font-medium text-lg pt-2 border-t">
                            <span>Total</span>
                            <span>${total.toFixed(2)}</span>
                          </div>
                        </div>
                        <Button
                          className="w-full mt-4"
                          size="lg"
                          onClick={() => {
                            setIsCartOpen(false)
                            router.push("/checkout")
                          }}
                        >
                          Checkout
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              </SheetContent>
            </Sheet>

            {isLoggedIn ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-foreground/80 hover:text-food-primary hover:bg-food-primary/5"
                    aria-label="User profile"
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="https://randomuser.me/api/portraits/men/32.jpg" alt="User" />
                      <AvatarFallback>JD</AvatarFallback>
                    </Avatar>
                    <span className="sr-only">Profile</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/profile">Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/orders">My Orders</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/favorites">Favorites</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/settings">Settings</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                variant="default"
                size="sm"
                className="rounded-full bg-food-primary hover:bg-food-primary/90"
                onClick={handleLogin}
              >
                <LogIn className="h-4 w-4 mr-1" />
                Login
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden space-x-2">
            {isLoggedIn && (
              <Button
                variant="ghost"
                size="icon"
                className="text-foreground/80 hover:text-food-primary hover:bg-food-primary/5 relative"
                onClick={() => setIsNotificationsOpen(true)}
                aria-label="Notifications"
              >
                <Bell className="h-5 w-5" />
                {unreadNotifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-food-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {unreadNotifications}
                  </span>
                )}
                <span className="sr-only">Notifications</span>
              </Button>
            )}

            <Button
              variant="ghost"
              size="icon"
              onClick={handleCartClick}
              className="text-foreground/80 hover:text-food-primary hover:bg-food-primary/5 relative"
              aria-label="Shopping cart"
            >
              <ShoppingBag className="h-5 w-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-food-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {itemCount}
                </span>
              )}
              <span className="sr-only">Cart</span>
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-foreground/80 hover:text-food-primary hover:bg-food-primary/5"
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              <span className="sr-only">{isMobileMenuOpen ? "Close menu" : "Menu"}</span>
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        <AnimatePresence>
          {isSearchOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="mt-4 overflow-hidden"
            >
              <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search for restaurants or dishes..."
                  className="pl-10 rounded-full border-food-primary/20 focus:border-food-primary"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                  aria-label="Search"
                />
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="md:hidden bg-white border-t mt-3"
            role="dialog"
            aria-modal="true"
            aria-label="Mobile navigation menu"
          >
            <div className="container-custom py-4">
              <div className="flex flex-col space-y-3">
                {isLoggedIn && (
                  <div className="flex items-center gap-3 p-3 bg-muted/20 rounded-lg">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src="https://randomuser.me/api/portraits/men/32.jpg" alt="User" />
                      <AvatarFallback>JD</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">John Doe</h3>
                      <p className="text-xs text-muted-foreground">john.doe@example.com</p>
                    </div>
                  </div>
                )}

                <form onSubmit={handleSearch} className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search for restaurants or dishes..."
                    className="pl-10 rounded-full border-food-primary/20 focus:border-food-primary"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    aria-label="Search"
                  />
                </form>

                <nav className="flex flex-col space-y-1 pt-2" aria-label="Mobile Navigation">
                  {navItems.map((item) => (
                    <div key={item.id}>
                      <Link
                        href={item.href}
                        className={cn(
                          "px-3 py-2 text-sm font-medium rounded-md transition-colors block",
                          pathname === item.href
                            ? "text-food-primary bg-food-primary/5"
                            : "text-foreground/80 hover:text-food-primary hover:bg-food-primary/5",
                        )}
                        aria-current={pathname === item.href ? "page" : undefined}
                      >
                        {item.label}
                      </Link>

                      {item.children && (
                        <div className="pl-4 mt-1 space-y-1 border-l border-muted ml-3">
                          {item.children.map((child) => (
                            <Link
                              key={child.id}
                              href={child.href}
                              className={cn(
                                "px-3 py-1.5 text-sm rounded-md transition-colors block",
                                pathname === child.href
                                  ? "text-food-primary"
                                  : "text-foreground/70 hover:text-food-primary hover:bg-food-primary/5",
                              )}
                              aria-current={pathname === child.href ? "page" : undefined}
                            >
                              {child.label}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </nav>

                {isLoggedIn ? (
                  <div className="space-y-1 pt-2">
                    <Link
                      href="/profile"
                      className="px-3 py-2 text-sm font-medium rounded-md transition-colors block text-foreground/80 hover:text-food-primary hover:bg-food-primary/5"
                    >
                      My Profile
                    </Link>
                    <Link
                      href="/orders"
                      className="px-3 py-2 text-sm font-medium rounded-md transition-colors block text-foreground/80 hover:text-food-primary hover:bg-food-primary/5"
                    >
                      My Orders
                    </Link>
                    <Link
                      href="/favorites"
                      className="px-3 py-2 text-sm font-medium rounded-md transition-colors block text-foreground/80 hover:text-food-primary hover:bg-food-primary/5"
                    >
                      Favorites
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-3 py-2 text-sm font-medium rounded-md transition-colors block text-destructive hover:bg-destructive/10"
                    >
                      Logout
                    </button>
                  </div>
                ) : (
                  <div className="pt-2">
                    <Button
                      variant="default"
                      className="w-full rounded-full bg-food-primary hover:bg-food-primary/90"
                      onClick={handleLogin}
                    >
                      <LogIn className="h-4 w-4 mr-2" />
                      Login / Sign Up
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Notifications Sheet */}
      <Sheet open={isNotificationsOpen} onOpenChange={setIsNotificationsOpen}>
        <SheetContent side="right">
          <SheetHeader>
            <SheetTitle>Notifications</SheetTitle>
            <SheetDescription>
              {notifications.length === 0 ? "No notifications" : `You have ${unreadNotifications} unread notifications`}
            </SheetDescription>
          </SheetHeader>
          <div className="mt-6 flex flex-col h-[calc(100vh-10rem)]">
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full">
                <Bell className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No notifications</p>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto pr-2">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={cn(
                        "p-4 border-b last:border-b-0 hover:bg-muted/50 cursor-pointer",
                        !notification.read && "bg-muted/20",
                      )}
                    >
                      <div className="flex justify-between items-start">
                        <h4 className="font-medium text-sm">{notification.title}</h4>
                        <span className="text-xs text-muted-foreground">{notification.time}</span>
                      </div>
                      <p className="text-sm mt-1">{notification.message}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-auto pt-4">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={markAllNotificationsAsRead}
                    disabled={unreadNotifications === 0}
                  >
                    Mark all as read
                  </Button>
                </div>
              </>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </header>
  )
}
