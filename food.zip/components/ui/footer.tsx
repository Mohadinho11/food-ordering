import Link from "next/link"
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function Footer() {
  return (
    <footer className="bg-food-dark text-white">
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Column 1: Logo and About */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-white rounded-full p-1.5">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-6 w-6 text-food-primary"
                >
                  <path d="M3 2h18v10H3z" />
                  <path d="M3 12v10h18V12" />
                  <path d="M12 2v20" />
                  <path d="M3 7h18" />
                  <path d="M3 17h18" />
                </svg>
              </div>
              <span className="text-xl font-bold font-heading">FoodFlex</span>
            </Link>
            <p className="text-gray-400 text-sm">
              Delicious food delivered to your doorstep. Discover the best restaurants in your area and enjoy a seamless
              ordering experience.
            </p>
            <div className="flex space-x-3">
              <a href="#" className="text-gray-400 hover:text-food-primary transition-colors">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-food-primary transition-colors">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-food-primary transition-colors">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-food-primary transition-colors">
                <Youtube className="h-5 w-5" />
                <span className="sr-only">YouTube</span>
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/restaurants" className="text-gray-400 hover:text-food-primary transition-colors">
                  Restaurants
                </Link>
              </li>
              <li>
                <Link href="/cuisines" className="text-gray-400 hover:text-food-primary transition-colors">
                  Cuisines
                </Link>
              </li>
              <li>
                <Link href="/deals" className="text-gray-400 hover:text-food-primary transition-colors">
                  Special Offers
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-food-primary transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-food-primary transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-gray-400 hover:text-food-primary transition-colors">
                  Careers
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Contact */}
          <div className="space-y-4">
            <h4 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-food-primary shrink-0 mt-0.5" />
                <span className="text-gray-400">123 Food Street, Cuisine City, FC 12345</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-food-primary shrink-0" />
                <a href="tel:+11234567890" className="text-gray-400 hover:text-food-primary transition-colors">
                  +1 (123) 456-7890
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-food-primary shrink-0" />
                <a href="mailto:info@foodflex.com" className="text-gray-400 hover:text-food-primary transition-colors">
                  info@foodflex.com
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Newsletter */}
          <div className="space-y-4">
            <h4 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2">Newsletter</h4>
            <p className="text-gray-400 text-sm">
              Subscribe to our newsletter for the latest updates, offers, and delicious deals.
            </p>
            <div className="flex flex-col space-y-2">
              <Input
                type="email"
                placeholder="Your email address"
                className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 focus:border-food-primary"
              />
              <Button className="bg-food-primary hover:bg-food-primary/90 text-white rounded-md">Subscribe</Button>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">&copy; {new Date().getFullYear()} FoodFlex. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link href="/terms" className="text-gray-500 hover:text-food-primary text-sm transition-colors">
              Terms of Service
            </Link>
            <Link href="/privacy" className="text-gray-500 hover:text-food-primary text-sm transition-colors">
              Privacy Policy
            </Link>
            <Link href="/faq" className="text-gray-500 hover:text-food-primary text-sm transition-colors">
              FAQ
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
