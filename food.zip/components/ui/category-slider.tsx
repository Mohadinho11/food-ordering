"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Category {
  id: string
  name: string
  icon: string
  count: number
}

interface CategorySliderProps {
  categories: Category[]
}

export function CategorySlider({ categories }: CategorySliderProps) {
  const [scrollPosition, setScrollPosition] = useState(0)
  const [maxScroll, setMaxScroll] = useState(0)
  const sliderRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const updateMaxScroll = () => {
      if (sliderRef.current) {
        setMaxScroll(sliderRef.current.scrollWidth - sliderRef.current.clientWidth)
      }
    }

    updateMaxScroll()
    window.addEventListener("resize", updateMaxScroll)

    return () => {
      window.removeEventListener("resize", updateMaxScroll)
    }
  }, [categories])

  const scroll = (direction: "left" | "right") => {
    if (sliderRef.current) {
      const scrollAmount = 300
      const newPosition =
        direction === "left"
          ? Math.max(0, scrollPosition - scrollAmount)
          : Math.min(maxScroll, scrollPosition + scrollAmount)

      sliderRef.current.scrollTo({
        left: newPosition,
        behavior: "smooth",
      })

      setScrollPosition(newPosition)
    }
  }

  const handleScroll = () => {
    if (sliderRef.current) {
      setScrollPosition(sliderRef.current.scrollLeft)
    }
  }

  return (
    <div className="relative">
      <div
        ref={sliderRef}
        className="flex overflow-x-auto scrollbar-hide py-4 px-1 -mx-1 snap-x"
        onScroll={handleScroll}
      >
        {categories.map((category) => (
          <Link
            key={category.id}
            href={`/cuisines/${category.id}`}
            className="snap-start shrink-0 first:ml-0 last:mr-0 mx-2"
          >
            <div className="flex flex-col items-center gap-2 w-28 p-4 bg-white rounded-xl shadow-card hover:shadow-hover transition-all hover:-translate-y-1">
              <div className="text-3xl">{category.icon}</div>
              <h3 className="font-medium text-sm">{category.name}</h3>
              <span className="text-xs text-muted-foreground">{category.count} places</span>
            </div>
          </Link>
        ))}
      </div>

      {scrollPosition > 0 && (
        <Button
          variant="outline"
          size="icon"
          className="absolute left-0 top-1/2 -translate-y-1/2 bg-white shadow-md hover:bg-gray-50"
          onClick={() => scroll("left")}
        >
          <ChevronLeft className="h-4 w-4" />
          <span className="sr-only">Scroll left</span>
        </Button>
      )}

      {scrollPosition < maxScroll && (
        <Button
          variant="outline"
          size="icon"
          className="absolute right-0 top-1/2 -translate-y-1/2 bg-white shadow-md hover:bg-gray-50"
          onClick={() => scroll("right")}
        >
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Scroll right</span>
        </Button>
      )}
    </div>
  )
}
