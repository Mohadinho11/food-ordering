"use client"

import * as React from "react"
import {
  Tooltip as RechartsTooltip,
  type TooltipProps,
  Legend as RechartsPrimitiveLegend,
  type LegendProps as RechartsPrimitiveLegendProps,
} from "recharts"
import { cn } from "@/lib/utils"

// Define chart configuration type
interface ChartConfig {
  [key: string]: {
    label: string
    color: string
  }
}

// Create a context to share chart configuration
const ChartContext = React.createContext<{ config: ChartConfig }>({
  config: {},
})

// Hook to use chart context
export const useChart = () => {
  const context = React.useContext(ChartContext)
  if (!context) {
    throw new Error("useChart must be used within a ChartContainer")
  }
  return context
}

interface ChartContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  config: ChartConfig
}

export function ChartContainer({ config, className, children, ...props }: ChartContainerProps) {
  return (
    <ChartContext.Provider value={{ config }}>
      <div
        className={cn("h-80", className)}
        style={
          {
            "--color-sales": config.sales?.color,
            "--color-orders": config.orders?.color,
            "--color-total": config.total?.color,
            "--color-fcf": config.fcf?.color,
            "--color-pv": config.pv?.color,
          } as React.CSSProperties
        }
        {...props}
      >
        {children}
      </div>
    </ChartContext.Provider>
  )
}

// ChartTooltip component
export function ChartTooltip(props: React.ComponentProps<typeof RechartsTooltip>) {
  return <RechartsTooltip {...props} />
}

interface ChartTooltipContentProps extends React.ComponentPropsWithoutRef<"div"> {
  className?: string
}

export function ChartTooltipContent({ className, ...props }: ChartTooltipContentProps) {
  const { active, payload, label } = props as unknown as TooltipProps<number, string> & {
    payload?: Array<{
      name: string
      value: number
      payload: {
        [key: string]: number | string
      }
    }>
  }

  if (!active || !payload?.length) {
    return null
  }

  return (
    <div className="rounded-lg border bg-background p-2 shadow-md">
      <div className="grid grid-cols-2 gap-2">
        <div className="flex flex-col">
          <span className="text-[0.70rem] uppercase text-muted-foreground">{label}</span>
        </div>
        {payload.map((item) => (
          <div key={item.name} className="flex flex-col">
            <span className="font-bold text-[0.70rem] uppercase text-muted-foreground">{item.name}</span>
            <span className="font-bold">
              {item.name.toLowerCase() === "sales" ||
              item.name.toLowerCase() === "revenue" ||
              item.name.toLowerCase() === "total" ||
              item.name.toLowerCase() === "fcf" ||
              item.name.toLowerCase() === "pv"
                ? `$${item.value}`
                : item.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

const ChartLegend = RechartsPrimitiveLegend

const ChartLegendContent = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> &
    Pick<RechartsPrimitiveLegendProps, "payload" | "verticalAlign"> & {
      hideIcon?: boolean
      nameKey?: string
    }
>(({ className, hideIcon = false, payload, verticalAlign = "bottom", nameKey }, ref) => {
  const { config } = useChart()

  if (!payload?.length) {
    return null
  }

  return (
    <div
      ref={ref}
      className={cn("flex items-center justify-center gap-4", verticalAlign === "top" ? "pb-3" : "pt-3", className)}
    >
      {payload.map((item) => {
        const key = `${nameKey || item.dataKey || "value"}`
        const itemConfig = config[key]

        return (
          <div
            key={item.value}
            className={cn("flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3 [&>svg]:text-muted-foreground")}
          >
            <div
              className="h-2 w-2 shrink-0 rounded-[2px]"
              style={{
                backgroundColor: item.color,
              }}
            />
            {itemConfig?.label}
          </div>
        )
      })}
    </div>
  )
})
ChartLegendContent.displayName = "ChartLegendContent"

export { ChartLegend, ChartLegendContent }
