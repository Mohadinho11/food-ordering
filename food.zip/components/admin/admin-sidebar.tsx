"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { BarChart3, Users, Store, ShoppingBag, Utensils, Settings, LogOut, Home } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { useAdminAuth } from "@/components/admin/admin-auth-provider"
import { toast } from "@/hooks/use-toast"

export default function AdminSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { user, logout } = useAdminAuth()

  const navItems = [
    {
      name: "Dashboard",
      href: "/admin",
      icon: BarChart3,
    },
    {
      name: "Users",
      href: "/admin/users",
      icon: Users,
    },
    {
      name: "Restaurants",
      href: "/admin/restaurants",
      icon: Store,
    },
    {
      name: "Orders",
      href: "/admin/orders",
      icon: ShoppingBag,
    },
    {
      name: "Menu Items",
      href: "/admin/menu-items",
      icon: Utensils,
    },
    {
      name: "Settings",
      href: "/admin/settings",
      icon: Settings,
    },
  ]

  const handleLogout = async () => {
    try {
      await logout()
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of the admin panel",
      })
      router.push("/admin/login")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to log out. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleGoToSite = () => {
    router.push("/")
  }

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-screen sticky top-0 overflow-y-auto">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <ShoppingBag className="h-8 w-8 text-primary" />
          <h1 className="text-xl font-bold">FoodFlex Admin</h1>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const isActive = pathname === item.href

            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors",
                  isActive ? "bg-primary/10 text-primary" : "text-gray-700 hover:bg-gray-100",
                )}
              >
                <item.icon className={cn("h-5 w-5", isActive ? "text-primary" : "text-gray-500")} />
                {item.name}
              </Link>
            )
          })}
        </nav>
      </div>

      <div className="p-6 border-t border-gray-200 mt-auto">
        <div className="space-y-2">
          <Button variant="outline" className="w-full justify-start" onClick={handleGoToSite}>
            <Home className="h-5 w-5 mr-2 text-gray-500" />
            Go to Website
          </Button>
          <Button
            variant="outline"
            className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  )
}
