"use client"

import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  {
    date: "Jan",
    users: 240,
    orders: 120,
    revenue: 4800,
  },
  {
    date: "Feb",
    users: 280,
    orders: 150,
    revenue: 6000,
  },
  {
    date: "Mar",
    users: 320,
    orders: 180,
    revenue: 7200,
  },
  {
    date: "Apr",
    users: 350,
    orders: 200,
    revenue: 8000,
  },
  {
    date: "May",
    users: 400,
    orders: 220,
    revenue: 8800,
  },
  {
    date: "Jun",
    users: 450,
    orders: 250,
    revenue: 10000,
  },
  {
    date: "Jul",
    users: 500,
    orders: 280,
    revenue: 11200,
  },
  {
    date: "Aug",
    users: 550,
    orders: 300,
    revenue: 12000,
  },
  {
    date: "Sep",
    users: 600,
    orders: 320,
    revenue: 12800,
  },
  {
    date: "Oct",
    users: 650,
    orders: 350,
    revenue: 14000,
  },
  {
    date: "Nov",
    users: 700,
    orders: 380,
    revenue: 15200,
  },
  {
    date: "Dec",
    users: 750,
    orders: 400,
    revenue: 16000,
  },
]

export function AdminDashboardChart() {
  return (
    <ChartContainer
      config={{
        users: {
          label: "Users",
          color: "hsl(var(--primary))",
        },
        orders: {
          label: "Orders",
          color: "hsl(var(--secondary))",
        },
        revenue: {
          label: "Revenue ($)",
          color: "hsl(var(--accent))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 10,
            left: 10,
            bottom: 0,
          }}
        >
          <XAxis dataKey="date" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line
            type="monotone"
            dataKey="users"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-users)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-users)",
            }}
          />
          <Line
            type="monotone"
            dataKey="orders"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-orders)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-orders)",
            }}
          />
          <Line
            type="monotone"
            dataKey="revenue"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-revenue)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-revenue)",
            }}
          />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}
