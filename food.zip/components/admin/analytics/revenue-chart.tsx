"use client"

import { useState } from "react"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Sample data - in a real app, this would come from an API
const dailyData = [
  { date: "Mon", revenue: 1420, orders: 38 },
  { date: "Tue", revenue: 1620, orders: 42 },
  { date: "Wed", revenue: 1740, orders: 45 },
  { date: "Thu", revenue: 2120, orders: 52 },
  { date: "Fri", revenue: 2860, orders: 71 },
  { date: "Sat", revenue: 3210, orders: 88 },
  { date: "Sun", revenue: 2890, orders: 74 },
]

const weeklyData = [
  { date: "Week 1", revenue: 12500, orders: 320 },
  { date: "Week 2", revenue: 14200, orders: 350 },
  { date: "Week 3", revenue: 15800, orders: 380 },
  { date: "Week 4", revenue: 16700, orders: 410 },
]

const monthlyData = [
  { date: "Jan", revenue: 48000, orders: 1250 },
  { date: "Feb", revenue: 52000, orders: 1380 },
  { date: "Mar", revenue: 61000, orders: 1520 },
  { date: "Apr", revenue: 64000, orders: 1600 },
  { date: "May", revenue: 68000, orders: 1750 },
  { date: "Jun", revenue: 72000, orders: 1820 },
  { date: "Jul", revenue: 74000, orders: 1880 },
  { date: "Aug", revenue: 78000, orders: 1950 },
  { date: "Sep", revenue: 82000, orders: 2050 },
  { date: "Oct", revenue: 84000, orders: 2120 },
  { date: "Nov", revenue: 88000, orders: 2200 },
  { date: "Dec", revenue: 92000, orders: 2350 },
]

export function RevenueChart() {
  const [period, setPeriod] = useState("monthly")

  const data = {
    daily: dailyData,
    weekly: weeklyData,
    monthly: monthlyData,
  }[period]

  return (
    <Card className="col-span-4">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-1">
          <CardTitle>Revenue Overview</CardTitle>
          <CardDescription>View revenue trends over time</CardDescription>
        </div>
        <Tabs defaultValue={period} onValueChange={setPeriod}>
          <TabsList>
            <TabsTrigger value="daily">Daily</TabsTrigger>
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent className="pt-4 h-[350px]">
        <ChartContainer
          config={{
            revenue: {
              label: "Revenue",
              color: "hsl(var(--primary))",
            },
            orders: {
              label: "Orders",
              color: "hsl(var(--secondary))",
            },
          }}
          className="h-full"
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{
                top: 5,
                right: 10,
                left: 10,
                bottom: 0,
              }}
            >
              <XAxis dataKey="date" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `$${value}`}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Line
                type="monotone"
                dataKey="revenue"
                strokeWidth={2}
                activeDot={{
                  r: 6,
                  style: { fill: "var(--color-revenue)", opacity: 0.8 },
                }}
                style={{
                  stroke: "var(--color-revenue)",
                }}
              />
              <Line
                type="monotone"
                dataKey="orders"
                strokeWidth={2}
                activeDot={{
                  r: 6,
                  style: { fill: "var(--color-orders)", opacity: 0.8 },
                }}
                style={{
                  stroke: "var(--color-orders)",
                }}
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
