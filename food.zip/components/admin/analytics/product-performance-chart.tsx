"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { useState } from "react"

// Sample data - in a real app, this would come from an API
const productData = [
  {
    name: "Classic Cheeseburger",
    sales: 124,
    revenue: 1240,
  },
  {
    name: "Margherita Pizza",
    sales: 98,
    revenue: 1176,
  },
  {
    name: "Caesar Salad",
    sales: 87,
    revenue: 696,
  },
  {
    name: "Chocolate Brownie",
    sales: 65,
    revenue: 325,
  },
  {
    name: "Garlic Bread",
    sales: 54,
    revenue: 270,
  },
  {
    name: "Iced Coffee",
    sales: 48,
    revenue: 192,
  },
  {
    name: "Veggie Wrap",
    sales: 42,
    revenue: 462,
  },
]

export function ProductPerformanceChart() {
  const [metric, setMetric] = useState("revenue")

  return (
    <Card className="col-span-3">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-1">
          <CardTitle>Product Performance</CardTitle>
          <CardDescription>
            Top performing products by {metric === "revenue" ? "revenue" : "sales volume"}
          </CardDescription>
        </div>
        <Select defaultValue={metric} onValueChange={setMetric}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Select metric" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="revenue">Revenue</SelectItem>
            <SelectItem value="sales">Sales Volume</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="pt-4 h-[350px]">
        <ChartContainer
          config={{
            [metric]: {
              label: metric === "revenue" ? "Revenue" : "Sales",
              color: "hsl(var(--primary))",
            },
          }}
          className="h-full"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={productData}
              layout="vertical"
              margin={{
                top: 5,
                right: 10,
                left: 80,
                bottom: 0,
              }}
            >
              <XAxis
                type="number"
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => (metric === "revenue" ? `$${value}` : value.toString())}
              />
              <YAxis
                type="category"
                dataKey="name"
                stroke="#888888"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                width={80}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar
                dataKey={metric}
                radius={[0, 4, 4, 0]}
                style={{
                  fill: "var(--color-" + metric + ")",
                  opacity: 0.8,
                }}
              />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
