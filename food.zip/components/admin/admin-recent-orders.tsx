"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Eye, MoreVertical, Printer, AlertTriangle } from "lucide-react"
import { toast } from "@/hooks/use-toast"

// Sample orders data
const recentOrders = [
  {
    id: "ORD-7352",
    customer: {
      name: "John Smith",
      image: "https://randomuser.me/api/portraits/men/32.jpg",
    },
    restaurant: "Burger Palace",
    items: ["Chicken Burger", "Fries", "Coke"],
    total: "$24.50",
    status: "pending",
    date: "2023-05-15T14:30:00",
    timeAgo: "2 minutes ago",
  },
  {
    id: "ORD-7351",
    customer: {
      name: "Sarah Johnson",
      image: "https://randomuser.me/api/portraits/women/44.jpg",
    },
    restaurant: "Pizza Heaven",
    items: ["Margherita Pizza", "Garlic Bread"],
    total: "$18.99",
    status: "preparing",
    date: "2023-05-15T14:15:00",
    timeAgo: "15 minutes ago",
  },
  {
    id: "ORD-7350",
    customer: {
      name: "Michael Brown",
      image: "https://randomuser.me/api/portraits/men/22.jpg",
    },
    restaurant: "Sushi World",
    items: ["California Roll", "Miso Soup"],
    total: "$32.99",
    status: "ready",
    date: "2023-05-15T13:45:00",
    timeAgo: "45 minutes ago",
  },
  {
    id: "ORD-7349",
    customer: {
      name: "Emily Davis",
      image: "https://randomuser.me/api/portraits/women/67.jpg",
    },
    restaurant: "Taco Fiesta",
    items: ["Beef Tacos (3)", "Guacamole"],
    total: "$16.50",
    status: "delivered",
    date: "2023-05-15T13:00:00",
    timeAgo: "1 hour ago",
  },
  {
    id: "ORD-7348",
    customer: {
      name: "David Wilson",
      image: "https://randomuser.me/api/portraits/men/54.jpg",
    },
    restaurant: "Thai Spice",
    items: ["Pad Thai", "Spring Rolls"],
    total: "$22.75",
    status: "delivered",
    date: "2023-05-15T12:00:00",
    timeAgo: "2 hours ago",
  },
]

export function AdminRecentOrders() {
  const [orders, setOrders] = useState(recentOrders)

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "outline"
      case "preparing":
        return "default"
      case "ready":
        return "secondary"
      case "delivered":
        return "outline"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  const viewOrderDetails = (id: string) => {
    toast({
      title: "View order details",
      description: `Viewing details for order ${id}`,
    })
  }

  const printReceipt = (id: string) => {
    toast({
      title: "Print receipt",
      description: `Printing receipt for order ${id}`,
    })
  }

  const cancelOrder = (id: string) => {
    setOrders(orders.map((order) => (order.id === id ? { ...order, status: "cancelled" } : order)))

    toast({
      title: "Order cancelled",
      description: `Order ${id} has been cancelled`,
      variant: "destructive",
    })
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
          <div className="flex items-center gap-4">
            <Avatar>
              <AvatarImage src={order.customer.image} alt={order.customer.name} />
              <AvatarFallback>{order.customer.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium">{order.id}</p>
                <Badge variant={getStatusBadgeVariant(order.status)}>{order.status}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{order.customer.name}</p>
              <p className="text-sm text-muted-foreground">{order.restaurant}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium">{order.total}</p>
              <p className="text-sm text-muted-foreground">{order.timeAgo}</p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">More</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => viewOrderDetails(order.id)}>
                  <Eye className="h-4 w-4 mr-2" />
                  View details
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => printReceipt(order.id)}>
                  <Printer className="h-4 w-4 mr-2" />
                  Print receipt
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive"
                  onClick={() => cancelOrder(order.id)}
                  disabled={order.status === "cancelled" || order.status === "delivered"}
                >
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Cancel order
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}
    </div>
  )
}
