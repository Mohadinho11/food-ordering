"use client"

import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Skeleton } from "@/components/ui/skeleton"

interface RevenueChartProps {
  isLoading?: boolean
  interval?: "daily" | "weekly" | "monthly"
}

export function RevenueChart({ isLoading = false, interval = "overview" }: RevenueChartProps) {
  // Sample data - in a real app, this would come from an API
  const data = {
    overview: [
      { date: "Jan", revenue: 4800, orders: 120, products: 45 },
      { date: "Feb", revenue: 6000, orders: 150, products: 48 },
      { date: "Mar", revenue: 7200, orders: 180, products: 52 },
      { date: "Apr", revenue: 8000, orders: 200, products: 55 },
      { date: "May", revenue: 8800, orders: 220, products: 58 },
      { date: "Jun", revenue: 10000, orders: 250, products: 60 },
      { date: "Jul", revenue: 11200, orders: 280, products: 62 },
      { date: "Aug", revenue: 12000, orders: 300, products: 65 },
      { date: "Sep", revenue: 12800, orders: 320, products: 68 },
      { date: "Oct", revenue: 14000, orders: 350, products: 70 },
      { date: "Nov", revenue: 15200, orders: 380, products: 72 },
      { date: "Dec", revenue: 16000, orders: 400, products: 75 },
    ],
    daily: [
      { date: "Mon", revenue: 1200, orders: 30, products: 15 },
      { date: "Tue", revenue: 1500, orders: 35, products: 18 },
      { date: "Wed", revenue: 1800, orders: 40, products: 20 },
      { date: "Thu", revenue: 1600, orders: 38, products: 19 },
      { date: "Fri", revenue: 2000, orders: 45, products: 22 },
      { date: "Sat", revenue: 2200, orders: 50, products: 25 },
      { date: "Sun", revenue: 1900, orders: 42, products: 21 },
    ],
    weekly: [
      { date: "Week 1", revenue: 5200, orders: 130, products: 45 },
      { date: "Week 2", revenue: 6100, orders: 145, products: 48 },
      { date: "Week 3", revenue: 5800, orders: 140, products: 47 },
      { date: "Week 4", revenue: 6500, orders: 155, products: 50 },
    ],
    monthly: [
      { date: "Jan", revenue: 4800, orders: 120, products: 45 },
      { date: "Feb", revenue: 6000, orders: 150, products: 48 },
      { date: "Mar", revenue: 7200, orders: 180, products: 52 },
      { date: "Apr", revenue: 8000, orders: 200, products: 55 },
      { date: "May", revenue: 8800, orders: 220, products: 58 },
      { date: "Jun", revenue: 10000, orders: 250, products: 60 },
    ],
  }

  const chartData = data[interval] || data.overview

  if (isLoading) {
    return <Skeleton className="h-[300px] w-full" />
  }

  return (
    <ChartContainer
      config={{
        revenue: {
          label: "Revenue",
          color: "hsl(var(--primary))",
        },
        orders: {
          label: "Orders",
          color: "hsl(var(--secondary))",
        },
        products: {
          label: "Products",
          color: "hsl(var(--accent))",
        },
      }}
      className="h-[300px]"
    >
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={chartData}
          margin={{
            top: 5,
            right: 10,
            left: 10,
            bottom: 0,
          }}
        >
          <XAxis dataKey="date" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis
            stroke="#888888"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `$${value}`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Line
            type="monotone"
            dataKey="revenue"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-revenue)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-revenue)",
            }}
          />
          <Line
            type="monotone"
            dataKey="orders"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-orders)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-orders)",
            }}
          />
          <Line
            type="monotone"
            dataKey="products"
            strokeWidth={2}
            activeDot={{
              r: 6,
              style: { fill: "var(--color-products)", opacity: 0.8 },
            }}
            style={{
              stroke: "var(--color-products)",
            }}
          />
        </LineChart>
      </ResponsiveContainer>
    </ChartContainer>
  )
}
