"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Eye, MoreVertical, Printer, AlertTriangle } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import Link from "next/link"

interface RecentOrdersProps {
  isLoading?: boolean
}

export function RecentOrders({ isLoading = false }: RecentOrdersProps) {
  // Sample orders data - in a real app, this would come from an API
  const [orders, setOrders] = useState([
    {
      id: "ORD-7352",
      customer: {
        name: "John Smith",
        email: "john.smith@example.com",
        image: "https://randomuser.me/api/portraits/men/32.jpg",
      },
      amount: 124.5,
      status: "pending",
      date: "2023-05-15T14:30:00",
      formattedDate: "May 15, 2023",
      timeAgo: "2 minutes ago",
    },
    {
      id: "ORD-7351",
      customer: {
        name: "Sarah Johnson",
        email: "sarah.johnson@example.com",
        image: "https://randomuser.me/api/portraits/women/44.jpg",
      },
      amount: 98.99,
      status: "processing",
      date: "2023-05-15T14:15:00",
      formattedDate: "May 15, 2023",
      timeAgo: "15 minutes ago",
    },
    {
      id: "ORD-7350",
      customer: {
        name: "Michael Brown",
        email: "michael.brown@example.com",
        image: "https://randomuser.me/api/portraits/men/22.jpg",
      },
      amount: 212.99,
      status: "completed",
      date: "2023-05-15T13:45:00",
      formattedDate: "May 15, 2023",
      timeAgo: "45 minutes ago",
    },
    {
      id: "ORD-7349",
      customer: {
        name: "Emily Davis",
        email: "emily.davis@example.com",
        image: "https://randomuser.me/api/portraits/women/67.jpg",
      },
      amount: 59.5,
      status: "completed",
      date: "2023-05-15T13:00:00",
      formattedDate: "May 15, 2023",
      timeAgo: "1 hour ago",
    },
    {
      id: "ORD-7348",
      customer: {
        name: "David Wilson",
        email: "david.wilson@example.com",
        image: "https://randomuser.me/api/portraits/men/54.jpg",
      },
      amount: 149.75,
      status: "cancelled",
      date: "2023-05-15T12:00:00",
      formattedDate: "May 15, 2023",
      timeAgo: "2 hours ago",
    },
  ])

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "outline"
      case "processing":
        return "default"
      case "completed":
        return "success"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center gap-4 p-4 border rounded-lg">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div className="space-y-2 flex-1">
              <Skeleton className="h-4 w-[200px]" />
              <Skeleton className="h-4 w-[150px]" />
            </div>
            <Skeleton className="h-8 w-[100px]" />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div
          key={order.id}
          className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
        >
          <div className="flex items-center gap-4">
            <Avatar>
              <AvatarImage src={order.customer.image || "/placeholder.svg"} alt={order.customer.name} />
              <AvatarFallback>{order.customer.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <p className="font-medium">{order.id}</p>
                <Badge variant={getStatusBadgeVariant(order.status)}>{order.status}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">{order.customer.name}</p>
              <p className="text-sm text-muted-foreground">{order.timeAgo}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium">${order.amount.toFixed(2)}</p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">More</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuItem asChild>
                  <Link href={`/admin/orders/${order.id}`}>
                    <Eye className="h-4 w-4 mr-2" />
                    View details
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() =>
                    toast({ title: "Printing receipt", description: `Printing receipt for order ${order.id}` })
                  }
                >
                  <Printer className="h-4 w-4 mr-2" />
                  Print receipt
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive"
                  onClick={() =>
                    toast({
                      title: "Cancel order",
                      description: `Are you sure you want to cancel order ${order.id}?`,
                      variant: "destructive",
                    })
                  }
                  disabled={order.status === "cancelled" || order.status === "completed"}
                >
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Cancel order
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}
      <div className="text-center pt-2">
        <Button variant="outline" asChild>
          <Link href="/admin/orders">View All Orders</Link>
        </Button>
      </div>
    </div>
  )
}
