"use client"

import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import Link from "next/link"
import { Button } from "@/components/ui/button"

interface TopProductsProps {
  isLoading?: boolean
}

export function TopProducts({ isLoading = false }: TopProductsProps) {
  // Sample top products data - in a real app, this would come from an API
  const topProducts = [
    {
      id: "prod-1",
      name: "Smartphone X Pro",
      sales: 124,
      revenue: "$124,000",
      percentageOfTotal: 85,
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "prod-2",
      name: "Wireless Earbuds",
      sales: 98,
      revenue: "$9,800",
      percentageOfTotal: 78,
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "prod-3",
      name: "Smart Watch Series 5",
      sales: 87,
      revenue: "$26,100",
      percentageOfTotal: 75,
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "prod-4",
      name: "Laptop Pro 16",
      sales: 65,
      revenue: "$129,935",
      percentageOfTotal: 66,
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "prod-5",
      name: "Bluetooth Speaker",
      sales: 54,
      revenue: "$5,400",
      percentageOfTotal: 56,
      image: "/placeholder.svg?height=40&width=40",
    },
  ]

  if (isLoading) {
    return (
      <div className="space-y-6">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="space-y-2">
            <div className="flex justify-between">
              <Skeleton className="h-4 w-[150px]" />
              <Skeleton className="h-4 w-[50px]" />
            </div>
            <Skeleton className="h-2 w-full" />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {topProducts.map((product) => (
        <div key={product.id} className="space-y-1">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <img
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                className="h-8 w-8 rounded object-cover"
              />
              <div>
                <p className="text-sm font-medium leading-none">{product.name}</p>
                <p className="text-xs text-muted-foreground">{product.sales} sales</p>
              </div>
            </div>
            <p className="font-medium">{product.revenue}</p>
          </div>
          <Progress value={product.percentageOfTotal} className="h-1" />
        </div>
      ))}
      <div className="text-center pt-2">
        <Button variant="outline" asChild>
          <Link href="/admin/products">View All Products</Link>
        </Button>
      </div>
    </div>
  )
}
