"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

// Sample top restaurants data
const topRestaurantsData = [
  {
    id: "1",
    name: "Burger Palace",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
    orders: 324,
    revenue: "$5,240",
    rating: 4.8,
    percentageOfTotal: 85,
  },
  {
    id: "2",
    name: "Pizza Heaven",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop",
    orders: 298,
    revenue: "$4,176",
    rating: 4.6,
    percentageOfTotal: 78,
  },
  {
    id: "3",
    name: "Sushi World",
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=2070&auto=format&fit=crop",
    orders: 287,
    revenue: "$4,696",
    rating: 4.9,
    percentageOfTotal: 75,
  },
  {
    id: "4",
    name: "Taco Fiesta",
    image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?q=80&w=2080&auto=format&fit=crop",
    orders: 254,
    revenue: "$3,270",
    rating: 4.7,
    percentageOfTotal: 66,
  },
  {
    id: "5",
    name: "Thai Spice",
    image: "https://images.unsplash.com/photo-1562565652-a0d8f0c59eb4?q=80&w=1932&auto=format&fit=crop",
    orders: 214,
    revenue: "$2,970",
    rating: 4.5,
    percentageOfTotal: 56,
  },
]

export function AdminTopRestaurants() {
  const [topRestaurants] = useState(topRestaurantsData)

  return (
    <div className="space-y-6">
      {topRestaurants.map((restaurant) => (
        <div key={restaurant.id} className="flex items-center gap-4">
          <Avatar className="h-10 w-10">
            <AvatarImage src={restaurant.image} alt={restaurant.name} />
            <AvatarFallback>{restaurant.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium leading-none">{restaurant.name}</p>
              <p className="text-sm font-medium">{restaurant.revenue}</p>
            </div>
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <div className="flex items-center gap-2">
                <span>{restaurant.orders} orders</span>
                <span>•</span>
                <span>{restaurant.rating} rating</span>
              </div>
              <span>{restaurant.percentageOfTotal}%</span>
            </div>
            <Progress value={restaurant.percentageOfTotal} className="h-1 mt-2" />
          </div>
        </div>
      ))}
    </div>
  )
}
