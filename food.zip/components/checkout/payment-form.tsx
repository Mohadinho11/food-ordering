"use client"

import type React from "react"

import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { CreditCard, Wallet, DollarSign } from "lucide-react"

interface CardInfo {
  cardNumber: string
  cardName: string
  expiryDate: string
  cvv: string
}

interface PaymentFormProps {
  paymentMethod: string
  onPaymentMethodChange: (value: string) => void
  cardInfo: CardInfo
  onCardInfoChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}

export function PaymentForm({ paymentMethod, onPaymentMethodChange, cardInfo, onCardInfoChange }: PaymentFormProps) {
  return (
    <div className="space-y-6">
      <RadioGroup value={paymentMethod} onValueChange={onPaymentMethodChange} className="space-y-3">
        <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-muted/50 transition-colors">
          <RadioGroupItem value="credit_card" id="credit_card" />
          <Label htmlFor="credit_card" className="flex items-center gap-2 cursor-pointer flex-1">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary">
              <CreditCard className="h-4 w-4" />
            </div>
            <div>Credit/Debit Card</div>
          </Label>
        </div>

        <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-muted/50 transition-colors">
          <RadioGroupItem value="wallet" id="wallet" />
          <Label htmlFor="wallet" className="flex items-center gap-2 cursor-pointer flex-1">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-secondary/10 text-secondary">
              <Wallet className="h-4 w-4" />
            </div>
            <div>Digital Wallet</div>
          </Label>
        </div>

        <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-muted/50 transition-colors">
          <RadioGroupItem value="cash" id="cash" />
          <Label htmlFor="cash" className="flex items-center gap-2 cursor-pointer flex-1">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/10 text-accent">
              <DollarSign className="h-4 w-4" />
            </div>
            <div>Cash on Delivery</div>
          </Label>
        </div>
      </RadioGroup>

      {paymentMethod === "credit_card" && (
        <div className="space-y-4 pt-4 border-t">
          <div className="space-y-2">
            <Label htmlFor="cardNumber">Card Number *</Label>
            <Input
              id="cardNumber"
              name="cardNumber"
              value={cardInfo.cardNumber}
              onChange={onCardInfoChange}
              placeholder="1234 5678 9012 3456"
              maxLength={19}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cardName">Name on Card *</Label>
            <Input
              id="cardName"
              name="cardName"
              value={cardInfo.cardName}
              onChange={onCardInfoChange}
              placeholder="John Doe"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="expiryDate">Expiry Date *</Label>
              <Input
                id="expiryDate"
                name="expiryDate"
                value={cardInfo.expiryDate}
                onChange={onCardInfoChange}
                placeholder="MM/YY"
                maxLength={5}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cvv">CVV *</Label>
              <Input
                id="cvv"
                name="cvv"
                value={cardInfo.cvv}
                onChange={onCardInfoChange}
                placeholder="123"
                maxLength={4}
                required
              />
            </div>
          </div>
        </div>
      )}

      {paymentMethod === "wallet" && (
        <div className="pt-4 border-t">
          <p className="text-sm text-muted-foreground">
            You'll be redirected to complete payment after placing your order.
          </p>
        </div>
      )}

      {paymentMethod === "cash" && (
        <div className="pt-4 border-t">
          <p className="text-sm text-muted-foreground">Please have the exact amount ready for the delivery person.</p>
        </div>
      )}
    </div>
  )
}
