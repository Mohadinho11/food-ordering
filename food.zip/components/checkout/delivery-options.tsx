"use client"

import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Clock, Zap, Calendar } from "lucide-react"

interface DeliveryOptionsProps {
  selectedOption: string
  onChange: (value: string) => void
}

export function DeliveryOptions({ selectedOption, onChange }: DeliveryOptionsProps) {
  return (
    <RadioGroup value={selectedOption} onValueChange={onChange} className="space-y-3">
      <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-muted/50 transition-colors">
        <RadioGroupItem value="standard" id="standard" />
        <Label htmlFor="standard" className="flex items-center gap-2 cursor-pointer flex-1">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary">
            <Clock className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <div className="font-medium">Standard Delivery</div>
            <div className="text-sm text-muted-foreground">Delivery in 30-45 minutes</div>
          </div>
          <div className="font-medium">Free</div>
        </Label>
      </div>

      <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-muted/50 transition-colors">
        <RadioGroupItem value="express" id="express" />
        <Label htmlFor="express" className="flex items-center gap-2 cursor-pointer flex-1">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-secondary/10 text-secondary">
            <Zap className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <div className="font-medium">Express Delivery</div>
            <div className="text-sm text-muted-foreground">Delivery in 15-25 minutes</div>
          </div>
          <div className="font-medium">+$2.99</div>
        </Label>
      </div>

      <div className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-muted/50 transition-colors">
        <RadioGroupItem value="scheduled" id="scheduled" />
        <Label htmlFor="scheduled" className="flex items-center gap-2 cursor-pointer flex-1">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/10 text-accent">
            <Calendar className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <div className="font-medium">Scheduled Delivery</div>
            <div className="text-sm text-muted-foreground">Choose a specific time</div>
          </div>
          <div className="font-medium">+$1.99</div>
        </Label>
      </div>
    </RadioGroup>
  )
}
