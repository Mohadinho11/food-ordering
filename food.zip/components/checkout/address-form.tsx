"use client"

import type React from "react"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface DeliveryInfo {
  fullName: string
  phone: string
  address: string
  city: string
  state: string
  zipCode: string
  deliveryInstructions: string
}

interface AddressFormProps {
  deliveryInfo: DeliveryInfo
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void
}

export function AddressForm({ deliveryInfo, onChange }: AddressFormProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <Label htmlFor="fullName">Full Name *</Label>
        <Input
          id="fullName"
          name="fullName"
          value={deliveryInfo.fullName}
          onChange={onChange}
          placeholder="John Doe"
          required
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="phone">Phone Number *</Label>
        <Input
          id="phone"
          name="phone"
          value={deliveryInfo.phone}
          onChange={onChange}
          placeholder="(123) 456-7890"
          required
        />
      </div>
      <div className="space-y-2 md:col-span-2">
        <Label htmlFor="address">Address *</Label>
        <Input
          id="address"
          name="address"
          value={deliveryInfo.address}
          onChange={onChange}
          placeholder="123 Main St, Apt 4B"
          required
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="city">City *</Label>
        <Input id="city" name="city" value={deliveryInfo.city} onChange={onChange} placeholder="New York" required />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="state">State *</Label>
          <Input id="state" name="state" value={deliveryInfo.state} onChange={onChange} placeholder="NY" required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="zipCode">Zip Code *</Label>
          <Input
            id="zipCode"
            name="zipCode"
            value={deliveryInfo.zipCode}
            onChange={onChange}
            placeholder="10001"
            required
          />
        </div>
      </div>
      <div className="space-y-2 md:col-span-2">
        <Label htmlFor="deliveryInstructions">Delivery Instructions (Optional)</Label>
        <Textarea
          id="deliveryInstructions"
          name="deliveryInstructions"
          value={deliveryInfo.deliveryInstructions}
          onChange={onChange}
          placeholder="E.g., Ring doorbell, leave at door, etc."
          rows={3}
        />
      </div>
    </div>
  )
}
