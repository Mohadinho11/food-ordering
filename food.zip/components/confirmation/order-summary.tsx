import { Separator } from "@/components/ui/separator"

interface OrderSummaryProps {
  items: Array<{
    id: string
    name: string
    price: number
    quantity: number
  }>
  subtotal: number
  discount: number
  deliveryFee: number
  tax: number
  total: number
}

export function OrderSummary({ items, subtotal, discount, deliveryFee, tax, total }: OrderSummaryProps) {
  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-lg">Order Summary</h3>

      <div className="space-y-2">
        {items.map((item) => (
          <div key={item.id} className="flex justify-between text-sm">
            <span>
              {item.quantity}x {item.name}
            </span>
            <span>${(item.price * item.quantity).toFixed(2)}</span>
          </div>
        ))}
      </div>

      <Separator />

      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-600">Subtotal</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>

        {discount > 0 && (
          <div className="flex justify-between text-green-600">
            <span>Discount</span>
            <span>-${discount.toFixed(2)}</span>
          </div>
        )}

        <div className="flex justify-between">
          <span className="text-gray-600">Delivery Fee</span>
          <span>${deliveryFee.toFixed(2)}</span>
        </div>

        <div className="flex justify-between">
          <span className="text-gray-600">Tax</span>
          <span>${tax.toFixed(2)}</span>
        </div>
      </div>

      <Separator />

      <div className="flex justify-between font-bold">
        <span>Total</span>
        <span className="text-food-primary">${total.toFixed(2)}</span>
      </div>
    </div>
  )
}
