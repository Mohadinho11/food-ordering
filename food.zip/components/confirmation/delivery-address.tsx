import { MapPin, Phone, User } from "lucide-react"

interface DeliveryAddressProps {
  deliveryInfo: {
    fullName: string
    phone: string
    address: string
    city: string
    state: string
    zipCode: string
    deliveryInstructions?: string
    deliveryOption: string
  }
}

export function DeliveryAddress({ deliveryInfo }: DeliveryAddressProps) {
  const getDeliveryOptionText = (option: string) => {
    switch (option) {
      case "express":
        return "Express Delivery (15-25 min)"
      case "scheduled":
        return "Scheduled Delivery"
      default:
        return "Standard Delivery (30-45 min)"
    }
  }

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-lg">Delivery Address</h3>

      <div className="space-y-3 text-sm">
        <div className="flex items-start gap-2">
          <User className="h-4 w-4 text-gray-500 mt-0.5 shrink-0" />
          <span>{deliveryInfo.fullName}</span>
        </div>

        <div className="flex items-start gap-2">
          <Phone className="h-4 w-4 text-gray-500 mt-0.5 shrink-0" />
          <span>{deliveryInfo.phone}</span>
        </div>

        <div className="flex items-start gap-2">
          <MapPin className="h-4 w-4 text-gray-500 mt-0.5 shrink-0" />
          <div>
            <p>{deliveryInfo.address}</p>
            <p>
              {deliveryInfo.city}, {deliveryInfo.state} {deliveryInfo.zipCode}
            </p>
          </div>
        </div>

        {deliveryInfo.deliveryInstructions && (
          <div className="pt-2">
            <p className="font-medium">Instructions:</p>
            <p className="text-gray-600">{deliveryInfo.deliveryInstructions}</p>
          </div>
        )}

        <div className="pt-2">
          <p className="font-medium">Delivery Type:</p>
          <p className="text-gray-600">{getDeliveryOptionText(deliveryInfo.deliveryOption)}</p>
        </div>
      </div>
    </div>
  )
}
