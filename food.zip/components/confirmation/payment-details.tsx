import { CreditCard, Wallet, DollarSign } from "lucide-react"

interface PaymentDetailsProps {
  paymentMethod: string
  cardInfo: {
    cardNumber: string
    cardName: string
  } | null
}

export function PaymentDetails({ paymentMethod, cardInfo }: PaymentDetailsProps) {
  const getPaymentIcon = () => {
    switch (paymentMethod) {
      case "credit_card":
        return <CreditCard className="h-4 w-4 text-gray-500 mt-0.5" />
      case "wallet":
        return <Wallet className="h-4 w-4 text-gray-500 mt-0.5" />
      case "cash":
        return <DollarSign className="h-4 w-4 text-gray-500 mt-0.5" />
      default:
        return <CreditCard className="h-4 w-4 text-gray-500 mt-0.5" />
    }
  }

  const getPaymentMethodText = () => {
    switch (paymentMethod) {
      case "credit_card":
        return "Credit/Debit Card"
      case "wallet":
        return "Digital Wallet"
      case "cash":
        return "Cash on Delivery"
      default:
        return "Credit/Debit Card"
    }
  }

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-lg">Payment Details</h3>

      <div className="space-y-3 text-sm">
        <div className="flex items-start gap-2">
          {getPaymentIcon()}
          <div>
            <p className="font-medium">{getPaymentMethodText()}</p>
            {paymentMethod === "credit_card" && cardInfo && (
              <div className="text-gray-600">
                <p>Card ending in {cardInfo.cardNumber.slice(-4)}</p>
                <p>{cardInfo.cardName}</p>
              </div>
            )}
            {paymentMethod === "cash" && <p className="text-gray-600">Please have the exact amount ready</p>}
          </div>
        </div>
      </div>
    </div>
  )
}
