"use client"

import { useState } from "react"
import Image from "next/image"
import { X, Heart, Plus, Minus, ShoppingBag, Leaf, Wheat, AlertTriangle } from "lucide-react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/hooks/use-toast"

interface MenuItem {
  id: string
  name: string
  description: string
  price: number
  image: string
  category: string
  isVegetarian?: boolean
  isVegan?: boolean
  isGlutenFree?: boolean
  isPopular?: boolean
  rating?: number
  ingredients?: string[]
  nutritionalInfo?: {
    calories: number
    protein: number
    carbs: number
    fat: number
  }
  allergens?: string[]
  spicyLevel?: number
}

interface MenuItemDetailProps {
  item: MenuItem
  isOpen: boolean
  onClose: () => void
}

export function MenuItemDetail({ item, isOpen, onClose }: MenuItemDetailProps) {
  const [quantity, setQuantity] = useState(1)
  const [isFavorite, setIsFavorite] = useState(false)
  const [activeTab, setActiveTab] = useState("description")

  const increaseQuantity = () => {
    setQuantity((prev) => prev + 1)
  }

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity((prev) => prev - 1)
    }
  }

  const handleAddToCart = () => {
    toast({
      title: "Added to cart",
      description: `${quantity}x ${item.name} has been added to your cart`,
    })
    onClose()
  }

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: isFavorite
        ? `${item.name} has been removed from your favorites`
        : `${item.name} has been added to your favorites`,
      variant: isFavorite ? "destructive" : "default",
    })
  }

  // Default values for missing data
  const ingredients = item.ingredients || ["Premium ingredients", "Fresh produce", "Carefully selected spices"]

  const nutritionalInfo = item.nutritionalInfo || {
    calories: 450,
    protein: 22,
    carbs: 35,
    fat: 18,
  }

  const allergens = item.allergens || ["May contain allergens"]

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden">
        <div className="relative h-64 w-full">
          <Image
            src={item.image || "/placeholder.svg"}
            alt={item.name}
            fill
            className="object-cover"
            sizes="(max-width: 600px) 100vw, 600px"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 h-8 w-8 rounded-full bg-black/50 hover:bg-black/70 text-white"
            onClick={onClose}
            aria-label="Close dialog"
          >
            <X className="h-4 w-4" />
          </Button>

          <div className="absolute top-2 left-2 flex flex-wrap gap-1">
            {item.isPopular && <Badge className="bg-food-accent text-food-dark border-none">Popular</Badge>}
            {item.isVegetarian && <Badge className="bg-green-100 text-green-700 border-none">Vegetarian</Badge>}
            {item.isVegan && <Badge className="bg-green-100 text-green-800 border-none">Vegan</Badge>}
            {item.isGlutenFree && <Badge className="bg-yellow-100 text-yellow-800 border-none">Gluten Free</Badge>}
          </div>
        </div>

        <div className="p-6">
          <div className="flex justify-between items-start">
            <h2 className="text-2xl font-bold">{item.name}</h2>
            <span className="text-xl font-bold text-food-primary">${item.price.toFixed(2)}</span>
          </div>

          {item.rating && (
            <div className="flex items-center mt-1">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(item.rating || 0)
                        ? "text-yellow-400 fill-yellow-400"
                        : "text-gray-300 fill-gray-300"
                    }`}
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                  >
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                ))}
              </div>
              <span className="text-sm text-gray-600 ml-1">{item.rating.toFixed(1)}</span>
            </div>
          )}

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
              <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="pt-4">
              <p className="text-gray-600">{item.description}</p>

              {item.spicyLevel && item.spicyLevel > 0 && (
                <div className="mt-4 flex items-center">
                  <span className="text-sm font-medium mr-2">Spice Level:</span>
                  <div className="flex">
                    {[...Array(3)].map((_, i) => (
                      <svg
                        key={i}
                        className={`w-5 h-5 ${
                          i < item.spicyLevel! ? "text-red-500 fill-red-500" : "text-gray-300 fill-gray-300"
                        }`}
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                      >
                        <path d="M12 18.5c-3.5 0-6.5-2.5-6.5-6.5 0-4 3-7.5 6.5-11 3.5 3.5 6.5 7 6.5 11 0 4-3 6.5-6.5 6.5z" />
                      </svg>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                {item.isVegetarian && (
                  <div className="flex items-center text-sm text-green-700">
                    <Leaf className="h-4 w-4 mr-1" />
                    <span>Vegetarian</span>
                  </div>
                )}

                {item.isGlutenFree && (
                  <div className="flex items-center text-sm text-yellow-700">
                    <Wheat className="h-4 w-4 mr-1" />
                    <span>Gluten Free</span>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="ingredients" className="pt-4">
              <ul className="list-disc pl-5 space-y-1 text-gray-600">
                {ingredients.map((ingredient, index) => (
                  <li key={index}>{ingredient}</li>
                ))}
              </ul>

              {allergens.length > 0 && (
                <div className="mt-4 p-3 bg-yellow-50 rounded-md flex items-start">
                  <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-sm">Allergen Information</p>
                    <ul className="list-disc pl-5 mt-1 text-sm text-gray-600">
                      {allergens.map((allergen, index) => (
                        <li key={index}>{allergen}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="nutrition" className="pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-500">Calories</p>
                  <p className="text-lg font-bold">{nutritionalInfo.calories} kcal</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-500">Protein</p>
                  <p className="text-lg font-bold">{nutritionalInfo.protein}g</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-500">Carbs</p>
                  <p className="text-lg font-bold">{nutritionalInfo.carbs}g</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-500">Fat</p>
                  <p className="text-lg font-bold">{nutritionalInfo.fat}g</p>
                </div>
              </div>

              <p className="text-xs text-gray-500 mt-4">
                * Nutritional information is approximate and may vary based on preparation method and serving size.
              </p>
            </TabsContent>
          </Tabs>

          <div className="mt-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 rounded-full border-gray-300"
                onClick={decreaseQuantity}
                disabled={quantity <= 1}
                aria-label="Decrease quantity"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="font-medium text-lg w-6 text-center">{quantity}</span>
              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 rounded-full border-gray-300"
                onClick={increaseQuantity}
                aria-label="Increase quantity"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                className={`h-10 w-10 rounded-full ${
                  isFavorite ? "bg-red-50 border-red-200 text-red-500" : "border-gray-300"
                }`}
                onClick={toggleFavorite}
                aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
              >
                <Heart className={`h-4 w-4 ${isFavorite ? "fill-red-500" : ""}`} />
              </Button>

              <Button className="bg-food-primary hover:bg-food-primary/90 text-white px-6" onClick={handleAddToCart}>
                <ShoppingBag className="h-4 w-4 mr-2" />
                Add to Cart
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
