"use client"

import { MenuItem } from "@/components/menu/menu-item"
import { FadeIn } from "@/components/animations/fade-in"

interface MenuItemData {
  id: string
  name: string
  description: string
  price: number
  image: string
  category: string
  restaurant: string
  restaurantId: string
  isVegetarian?: boolean
  isVegan?: boolean
  isGlutenFree?: boolean
  isPopular?: boolean
  rating?: number
}

interface MenuItemsGridProps {
  items: MenuItemData[]
}

export function MenuItemsGrid({ items }: MenuItemsGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {items.map((item, index) => (
        <MenuItem key={item.id} item={item} index={index} />
      ))}
    </div>
  )
}
