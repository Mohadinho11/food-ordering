"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Heart, Plus, Minus, ShoppingBag, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useCart } from "@/contexts/cart-context"
import { toast } from "@/hooks/use-toast"

interface MenuItemProps {
  item: {
    id: string
    name: string
    description: string
    price: number
    image: string
    category: string
    isVegetarian?: boolean
    isVegan?: boolean
    isGlutenFree?: boolean
    isPopular?: boolean
    rating?: number
    restaurant: string
    restaurantId: string
  }
  index: number
}

export function MenuItem({ item, index }: MenuItemProps) {
  const [quantity, setQuantity] = useState(1)
  const [isFavorite, setIsFavorite] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("details")
  const { addItem } = useCart()

  const increaseQuantity = () => {
    setQuantity((prev) => prev + 1)
  }

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity((prev) => prev - 1)
    }
  }

  const handleAddToCart = () => {
    addItem(
      {
        id: item.id,
        name: item.name,
        price: item.price,
        image: item.image,
        restaurant: item.restaurant,
        restaurantId: item.restaurantId,
      },
      quantity,
    )

    setIsDialogOpen(false)
    setQuantity(1)
  }

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: isFavorite
        ? `${item.name} has been removed from your favorites`
        : `${item.name} has been added to your favorites`,
      variant: isFavorite ? "destructive" : "default",
    })
  }

  return (
    <>
      <motion.div
        className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition-shadow"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: index * 0.05 }}
        onClick={() => setIsDialogOpen(true)}
        whileHover={{ y: -5 }}
        role="button"
        tabIndex={0}
        aria-label={`View details for ${item.name}`}
      >
        <div className="flex flex-col md:flex-row">
          <div className="relative h-48 md:h-auto md:w-1/3 md:min-h-[160px]">
            <Image
              src={item.image || "/placeholder.svg"}
              alt={item.name}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 33vw"
            />
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 h-8 w-8 bg-white/70 hover:bg-white/90 rounded-full"
              onClick={toggleFavorite}
              aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
            >
              <Heart className={`h-4 w-4 ${isFavorite ? "fill-red-500 text-red-500" : "text-gray-700"}`} />
            </Button>
            {item.isPopular && (
              <Badge className="absolute top-2 left-2 bg-food-accent text-food-dark border-none">Popular</Badge>
            )}
          </div>

          <div className="p-4 flex flex-col flex-1">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-lg">{item.name}</h3>
                <p className="text-sm text-muted-foreground">{item.restaurant}</p>
              </div>
              <span className="font-bold text-food-primary">${item.price.toFixed(2)}</span>
            </div>

            <div className="flex flex-wrap gap-1 mt-2">
              {item.isVegetarian && (
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  Vegetarian
                </Badge>
              )}
              {item.isVegan && (
                <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                  Vegan
                </Badge>
              )}
              {item.isGlutenFree && (
                <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                  Gluten Free
                </Badge>
              )}
            </div>

            <p className="text-sm text-gray-600 mt-2 line-clamp-2">{item.description}</p>

            <div className="mt-4 flex justify-between items-center">
              <Button
                variant="ghost"
                size="sm"
                className="text-food-primary hover:bg-food-primary/10 hover:text-food-primary"
                onClick={(e) => {
                  e.stopPropagation()
                  setIsDialogOpen(true)
                }}
              >
                <Info className="h-4 w-4 mr-1" />
                Details
              </Button>

              <Button
                size="sm"
                className="bg-food-primary hover:bg-food-primary/90 text-white"
                onClick={(e) => {
                  e.stopPropagation()
                  handleAddToCart()
                }}
              >
                <ShoppingBag className="h-4 w-4 mr-1" />
                Add to Cart
              </Button>
            </div>
          </div>
        </div>
      </motion.div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{item.name}</DialogTitle>
            <DialogDescription>From {item.restaurant}</DialogDescription>
          </DialogHeader>

          <div className="relative h-48 w-full rounded-lg overflow-hidden mb-4">
            <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
              <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="space-y-4">
              <p className="text-sm text-gray-600">{item.description}</p>
              <div className="flex flex-wrap gap-2">
                {item.isVegetarian && (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    Vegetarian
                  </Badge>
                )}
                {item.isVegan && (
                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                    Vegan
                  </Badge>
                )}
                {item.isGlutenFree && (
                  <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                    Gluten Free
                  </Badge>
                )}
                {item.isPopular && <Badge className="bg-food-accent text-food-dark border-none">Popular</Badge>}
              </div>
            </TabsContent>
            <TabsContent value="nutrition" className="space-y-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Calories</span>
                  <span className="font-medium">450 kcal</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Protein</span>
                  <span className="font-medium">22g</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Carbs</span>
                  <span className="font-medium">35g</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Fat</span>
                  <span className="font-medium">18g</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Sodium</span>
                  <span className="font-medium">720mg</span>
                </div>
                <div className="flex justify-between border-b pb-1">
                  <span className="text-gray-600">Fiber</span>
                  <span className="font-medium">3g</span>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="ingredients" className="space-y-4">
              <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                <li>Premium beef patty</li>
                <li>Cheddar cheese</li>
                <li>Fresh lettuce</li>
                <li>Tomato slices</li>
                <li>Red onion</li>
                <li>Special sauce</li>
                <li>Sesame seed bun</li>
              </ul>
              <div className="text-sm font-medium mt-4">Allergens:</div>
              <div className="text-sm text-gray-600">Contains: Gluten, Dairy, Eggs</div>
            </TabsContent>
          </Tabs>

          <div className="flex items-center justify-between mt-4">
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8 rounded-full"
                onClick={decreaseQuantity}
                disabled={quantity <= 1}
                aria-label="Decrease quantity"
              >
                <Minus className="h-3 w-3" />
              </Button>
              <span className="font-medium w-4 text-center">{quantity}</span>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8 rounded-full"
                onClick={increaseQuantity}
                aria-label="Increase quantity"
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <Button className="bg-food-primary hover:bg-food-primary/90 text-white" onClick={handleAddToCart}>
              <ShoppingBag className="h-4 w-4 mr-2" />
              Add to Cart - ${(item.price * quantity).toFixed(2)}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
