"use client"

import { useState } from "react"
import { ChevronDown, SlidersHorizontal, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Slider } from "@/components/ui/slider"
import { useMobile } from "@/hooks/use-mobile"

interface MenuFiltersProps {
  dietaryFilters: {
    vegetarian: boolean
    vegan: boolean
    glutenFree: boolean
  }
  onDietaryFilterChange: (filter: keyof typeof dietaryFilters) => void
  priceRange: number[]
  onPriceRangeChange: (range: [number, number]) => void
  sortOption: string
  onSortChange: (option: string) => void
  onClearFilters: () => void
}

export function MenuFilters({
  dietaryFilters,
  onDietaryFilterChange,
  priceRange,
  onPriceRangeChange,
  sortOption,
  onSortChange,
  onClearFilters,
}: MenuFiltersProps) {
  const isMobile = useMobile()
  const [isOpen, setIsOpen] = useState(false)

  const handlePriceChange = (value: number[]) => {
    onPriceRangeChange(value as [number, number])
  }

  const FilterContent = () => (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">Filters</h3>
          <Button variant="ghost" size="sm" onClick={onClearFilters} className="h-8 text-muted-foreground">
            Clear All
          </Button>
        </div>

        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-3">Sort By</h4>
            <RadioGroup value={sortOption} onValueChange={onSortChange} className="space-y-2">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="recommended" id="recommended" />
                <Label htmlFor="recommended">Recommended</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="price-low-high" id="price-low-high" />
                <Label htmlFor="price-low-high">Price: Low to High</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="price-high-low" id="price-high-low" />
                <Label htmlFor="price-high-low">Price: High to Low</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="rating" id="rating" />
                <Label htmlFor="rating">Rating</Label>
              </div>
            </RadioGroup>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-3">Dietary Preferences</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="vegetarian"
                  checked={dietaryFilters.vegetarian}
                  onCheckedChange={() => onDietaryFilterChange("vegetarian")}
                />
                <Label htmlFor="vegetarian">Vegetarian</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="vegan"
                  checked={dietaryFilters.vegan}
                  onCheckedChange={() => onDietaryFilterChange("vegan")}
                />
                <Label htmlFor="vegan">Vegan</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="glutenFree"
                  checked={dietaryFilters.glutenFree}
                  onCheckedChange={() => onDietaryFilterChange("glutenFree")}
                />
                <Label htmlFor="glutenFree">Gluten Free</Label>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium">Price Range</h4>
              <span className="text-sm text-muted-foreground">
                ${priceRange[0]} - ${priceRange[1]}
              </span>
            </div>
            <Slider
              defaultValue={priceRange}
              min={0}
              max={20}
              step={1}
              value={priceRange}
              onValueChange={handlePriceChange}
              className="my-6"
            />
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <>
      {isMobile ? (
        <>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="w-full flex items-center justify-between">
                <div className="flex items-center">
                  <SlidersHorizontal className="mr-2 h-4 w-4" />
                  Filters
                </div>
                <ChevronDown className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-[80vh]">
              <SheetHeader>
                <SheetTitle>Filters</SheetTitle>
              </SheetHeader>
              <div className="mt-4 overflow-y-auto h-[calc(100%-4rem)]">
                <FilterContent />
              </div>
            </SheetContent>
          </Sheet>

          {/* Show active filters */}
          <div className="flex flex-wrap gap-2 mt-4">
            {dietaryFilters.vegetarian && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs rounded-full"
                onClick={() => onDietaryFilterChange("vegetarian")}
              >
                Vegetarian
                <X className="ml-1 h-3 w-3" />
              </Button>
            )}
            {dietaryFilters.vegan && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs rounded-full"
                onClick={() => onDietaryFilterChange("vegan")}
              >
                Vegan
                <X className="ml-1 h-3 w-3" />
              </Button>
            )}
            {dietaryFilters.glutenFree && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs rounded-full"
                onClick={() => onDietaryFilterChange("glutenFree")}
              >
                Gluten Free
                <X className="ml-1 h-3 w-3" />
              </Button>
            )}
            {(priceRange[0] > 0 || priceRange[1] < 20) && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs rounded-full"
                onClick={() => onPriceRangeChange([0, 20])}
              >
                ${priceRange[0]} - ${priceRange[1]}
                <X className="ml-1 h-3 w-3" />
              </Button>
            )}
            {sortOption !== "recommended" && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs rounded-full"
                onClick={() => onSortChange("recommended")}
              >
                {sortOption === "price-low-high"
                  ? "Price: Low to High"
                  : sortOption === "price-high-low"
                    ? "Price: High to Low"
                    : "Rating"}
                <X className="ml-1 h-3 w-3" />
              </Button>
            )}
          </div>
        </>
      ) : (
        <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
          <FilterContent />
        </div>
      )}
    </>
  )
}
