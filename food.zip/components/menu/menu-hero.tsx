import Image from "next/image"
import { FadeIn } from "@/components/animations/fade-in"

export function MenuHero() {
  return (
    <div className="relative h-[300px] md:h-[400px] overflow-hidden">
      <Image
        src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2070&auto=format&fit=crop"
        alt="Delicious food spread"
        fill
        className="object-cover"
        priority
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>

      <div className="absolute inset-0 flex items-center justify-center">
        <FadeIn className="text-center text-white">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">Our Menu</h1>
          <p className="text-lg md:text-xl max-w-2xl mx-auto">
            Explore our wide selection of delicious dishes prepared with the freshest ingredients
          </p>
        </FadeIn>
      </div>
    </div>
  )
}
