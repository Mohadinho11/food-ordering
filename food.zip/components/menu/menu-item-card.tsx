"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Heart, Plus, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { toast } from "@/hooks/use-toast"

interface MenuItem {
  id: string
  name: string
  description: string
  price: number
  image: string
  category: string
  isVegetarian?: boolean
  isVegan?: boolean
  isGlutenFree?: boolean
  isPopular?: boolean
  rating?: number
}

interface MenuItemCardProps {
  item: MenuItem
  onClick: () => void
}

export function MenuItemCard({ item, onClick }: MenuItemCardProps) {
  const [isFavorite, setIsFavorite] = useState(false)
  const [isHovered, setIsHovered] = useState(false)

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation()
    toast({
      title: "Added to cart",
      description: `${item.name} has been added to your cart`,
    })
  }

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: isFavorite
        ? `${item.name} has been removed from your favorites`
        : `${item.name} has been added to your favorites`,
      variant: isFavorite ? "destructive" : "default",
    })
  }

  return (
    <motion.div
      className="bg-white rounded-xl shadow-sm overflow-hidden cursor-pointer"
      whileHover={{ y: -5, boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)" }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      role="button"
      aria-label={`View details for ${item.name}`}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault()
          onClick()
        }
      }}
    >
      <div className="relative h-48 w-full">
        <Image
          src={item.image || "/placeholder.svg"}
          alt={item.name}
          fill
          className="object-cover transition-transform duration-500 hover:scale-110"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

        <div className="absolute top-2 right-2 flex flex-col gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full bg-white/80 hover:bg-white shadow-sm"
            onClick={toggleFavorite}
            aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
          >
            <Heart className={`h-4 w-4 ${isFavorite ? "fill-red-500 text-red-500" : "text-gray-700"}`} />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full bg-white/80 hover:bg-white shadow-sm"
            onClick={(e) => {
              e.stopPropagation()
              onClick()
            }}
            aria-label={`View details for ${item.name}`}
          >
            <Info className="h-4 w-4 text-gray-700" />
          </Button>
        </div>

        <div className="absolute top-2 left-2 flex flex-wrap gap-1">
          {item.isPopular && <Badge className="bg-food-accent text-food-dark border-none">Popular</Badge>}
          {item.isVegetarian && <Badge className="bg-green-100 text-green-700 border-none">Vegetarian</Badge>}
          {item.isVegan && <Badge className="bg-green-100 text-green-800 border-none">Vegan</Badge>}
          {item.isGlutenFree && <Badge className="bg-yellow-100 text-yellow-800 border-none">Gluten Free</Badge>}
        </div>
      </div>

      <div className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="font-bold text-lg line-clamp-1">{item.name}</h3>
          <span className="font-bold text-food-primary">${item.price.toFixed(2)}</span>
        </div>

        <p className="text-gray-600 text-sm mt-1 line-clamp-2">{item.description}</p>

        <div className="mt-4 flex justify-between items-center">
          <div className="flex items-center">
            {item.rating && (
              <div className="flex items-center">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <svg
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(item.rating || 0)
                          ? "text-yellow-400 fill-yellow-400"
                          : "text-gray-300 fill-gray-300"
                      }`}
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                    >
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                    </svg>
                  ))}
                </div>
                <span className="text-xs text-gray-600 ml-1">{item.rating.toFixed(1)}</span>
              </div>
            )}
          </div>

          <Button
            size="sm"
            className="rounded-full bg-food-primary hover:bg-food-primary/90 text-white"
            onClick={handleAddToCart}
          >
            <Plus className="h-4 w-4 mr-1" />
            Add
          </Button>
        </div>
      </div>
    </motion.div>
  )
}
