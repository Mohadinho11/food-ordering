"use client"

import { MenuItem } from "@/components/menu/menu-item"
import { useState } from "react"
import { FadeIn } from "@/components/animations/fade-in"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

interface MenuItemsListProps {
  items: any[]
  title?: string
}

export function MenuItemsList({ items, title }: MenuItemsListProps) {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredItems = items.filter(
    (item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-2xl font-bold">{title}</h2>

        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search menu items..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {filteredItems.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <p className="text-lg font-medium">No items found</p>
          <p className="text-muted-foreground">Try a different search term</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredItems.map((item, index) => (
            <FadeIn key={item.id} delay={0.05 * (index % 5)}>
              <MenuItem item={item} index={index} />
            </FadeIn>
          ))}
        </div>
      )}
    </div>
  )
}
