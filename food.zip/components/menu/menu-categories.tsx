"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface Category {
  id: string
  name: string
  count: number
}

interface MenuCategoriesProps {
  categories: Category[]
  selectedCategory: string
  onCategoryChange: (category: string) => void
}

export function MenuCategories({ categories, selectedCategory, onCategoryChange }: MenuCategoriesProps) {
  return (
    <div className="overflow-x-auto pb-2 hide-scrollbar">
      <div className="flex space-x-2 min-w-max">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            className={cn(
              "px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap",
              selectedCategory === category.id
                ? "bg-food-primary text-white"
                : "bg-white text-gray-700 hover:bg-gray-100",
            )}
            aria-current={selectedCategory === category.id ? "page" : undefined}
          >
            {category.name}
            <span className="ml-1 text-xs opacity-70">({category.count})</span>
            {selectedCategory === category.id && (
              <motion.div
                layoutId="categoryIndicator"
                className="absolute inset-0 rounded-full bg-food-primary -z-10"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              />
            )}
          </button>
        ))}
      </div>
    </div>
  )
}
