"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Image from "next/image"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { FadeIn } from "@/components/animations/fade-in"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MenuItem } from "@/components/menu/menu-item" // Changed from MenuItemsList to MenuItem
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Search, SlidersHorizontal } from "lucide-react"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

// Sample menu data - in a real app, this would come from an API
const menuItems = [
  {
    id: "item-1",
    name: "Classic Cheeseburger",
    description: "Juicy beef patty with cheddar cheese, lettuce, tomato, onion, and special sauce on a toasted bun",
    price: 9.99,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
    category: "burgers",
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: false,
    isPopular: true,
    rating: 4.8,
    restaurant: "Burger Palace",
    restaurantId: "rest-1",
  },
  {
    id: "item-2",
    name: "Margherita Pizza",
    description: "Traditional pizza with tomato sauce, fresh mozzarella, and basil on a thin, crispy crust",
    price: 12.99,
    image: "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?q=80&w=1974&auto=format&fit=crop",
    category: "pizza",
    isVegetarian: true,
    isVegan: false,
    isGlutenFree: false,
    isPopular: true,
    rating: 4.6,
    restaurant: "Pizza Heaven",
    restaurantId: "rest-2",
  },
  {
    id: "item-3",
    name: "California Roll",
    description: "Crab, avocado, and cucumber wrapped in seaweed and rice",
    price: 8.99,
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=2070&auto=format&fit=crop",
    category: "sushi",
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: true,
    isPopular: true,
    rating: 4.9,
    restaurant: "Sushi World",
    restaurantId: "rest-3",
  },
  {
    id: "item-4",
    name: "Beef Tacos",
    description: "Seasoned ground beef in corn tortillas with lettuce, cheese, and salsa",
    price: 3.99,
    image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?q=80&w=2080&auto=format&fit=crop",
    category: "mexican",
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: true,
    isPopular: false,
    rating: 4.7,
    restaurant: "Taco Fiesta",
    restaurantId: "rest-4",
  },
  {
    id: "item-5",
    name: "Pad Thai",
    description: "Stir-fried rice noodles with eggs, tofu, bean sprouts, and peanuts",
    price: 12.99,
    image: "https://images.unsplash.com/photo-1562565652-a0d8f0c59eb4?q=80&w=1932&auto=format&fit=crop",
    category: "asian",
    isVegetarian: true,
    isVegan: false,
    isGlutenFree: true,
    isPopular: true,
    rating: 4.5,
    restaurant: "Thai Spice",
    restaurantId: "rest-5",
  },
  {
    id: "item-6",
    name: "Caesar Salad",
    description: "Crisp romaine lettuce with Caesar dressing, croutons, and parmesan cheese",
    price: 8.99,
    image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?q=80&w=2070&auto=format&fit=crop",
    category: "salads",
    isVegetarian: true,
    isVegan: false,
    isGlutenFree: false,
    isPopular: false,
    rating: 4.3,
    restaurant: "Healthy Greens",
    restaurantId: "rest-8",
  },
  {
    id: "item-7",
    name: "Chocolate Brownie",
    description: "Warm chocolate brownie served with vanilla ice cream and chocolate sauce",
    price: 6.99,
    image: "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?q=80&w=1930&auto=format&fit=crop",
    category: "desserts",
    isVegetarian: true,
    isVegan: false,
    isGlutenFree: false,
    isPopular: true,
    rating: 4.9,
    restaurant: "Burger Palace",
    restaurantId: "rest-1",
  },
  {
    id: "item-8",
    name: "Chicken Curry",
    description: "Tender chicken in a rich curry sauce with aromatic spices, served with rice",
    price: 14.99,
    image: "https://images.unsplash.com/photo-1585937421612-70a008356c36?q=80&w=2036&auto=format&fit=crop",
    category: "indian",
    isVegetarian: false,
    isVegan: false,
    isGlutenFree: true,
    isPopular: true,
    rating: 4.7,
    restaurant: "Indian Delight",
    restaurantId: "rest-6",
  },
]

// Categories
const categories = [
  { id: "all", name: "All Items" },
  { id: "burgers", name: "Burgers" },
  { id: "pizza", name: "Pizza" },
  { id: "sushi", name: "Sushi" },
  { id: "mexican", name: "Mexican" },
  { id: "asian", name: "Asian" },
  { id: "indian", name: "Indian" },
  { id: "salads", name: "Salads" },
  { id: "desserts", name: "Desserts" },
]

export default function MenuPage() {
  const searchParams = useSearchParams()
  const initialCategory = searchParams.get("category") || "all"

  const [selectedCategory, setSelectedCategory] = useState(initialCategory)
  const [searchQuery, setSearchQuery] = useState("")
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false)
  const [filters, setFilters] = useState({
    vegetarian: false,
    vegan: false,
    glutenFree: false,
    popular: false,
  })
  const [priceRange, setPriceRange] = useState([0, 20])
  const [sortOption, setSortOption] = useState("recommended")
  const [filteredItems, setFilteredItems] = useState(menuItems)

  // Apply filters whenever filter criteria change
  useEffect(() => {
    let filtered = [...menuItems]

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter((item) => item.category === selectedCategory)
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (item) =>
          item.name.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query) ||
          item.restaurant.toLowerCase().includes(query),
      )
    }

    // Apply dietary filters
    if (filters.vegetarian) {
      filtered = filtered.filter((item) => item.isVegetarian)
    }
    if (filters.vegan) {
      filtered = filtered.filter((item) => item.isVegan)
    }
    if (filters.glutenFree) {
      filtered = filtered.filter((item) => item.isGlutenFree)
    }
    if (filters.popular) {
      filtered = filtered.filter((item) => item.isPopular)
    }

    // Filter by price range
    filtered = filtered.filter((item) => item.price >= priceRange[0] && item.price <= priceRange[1])

    // Sort items
    switch (sortOption) {
      case "price-low-high":
        filtered.sort((a, b) => a.price - b.price)
        break
      case "price-high-low":
        filtered.sort((a, b) => b.price - a.price)
        break
      case "rating":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "recommended":
      default:
        // Keep the default order or apply a recommendation algorithm
        filtered.sort((a, b) => (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0))
        break
    }

    setFilteredItems(filtered)
  }, [selectedCategory, searchQuery, filters, priceRange, sortOption])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Search is already handled by the useEffect
  }

  const handleFilterChange = (filter: keyof typeof filters) => {
    setFilters((prev) => ({
      ...prev,
      [filter]: !prev[filter],
    }))
  }

  const handleClearFilters = () => {
    setSearchQuery("")
    setFilters({
      vegetarian: false,
      vegan: false,
      glutenFree: false,
      popular: false,
    })
    setPriceRange([0, 20])
    setSortOption("recommended")
  }

  const FilterContent = () => (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">Filters</h3>
          <Button variant="ghost" size="sm" onClick={handleClearFilters} className="h-8 text-muted-foreground">
            Clear All
          </Button>
        </div>

        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-3">Sort By</h4>
            <div className="space-y-2">
              {[
                { id: "recommended", label: "Recommended" },
                { id: "rating", label: "Highest Rated" },
                { id: "price-low-high", label: "Price: Low to High" },
                { id: "price-high-low", label: "Price: High to Low" },
              ].map((option) => (
                <div key={option.id} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id={option.id}
                    checked={sortOption === option.id}
                    onChange={() => setSortOption(option.id)}
                    className="h-4 w-4 text-primary"
                  />
                  <Label htmlFor={option.id}>{option.label}</Label>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t pt-4">
            <h4 className="font-medium mb-3">Dietary Preferences</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="vegetarian"
                  checked={filters.vegetarian}
                  onCheckedChange={() => handleFilterChange("vegetarian")}
                />
                <Label htmlFor="vegetarian">Vegetarian</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="vegan" checked={filters.vegan} onCheckedChange={() => handleFilterChange("vegan")} />
                <Label htmlFor="vegan">Vegan</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="glutenFree"
                  checked={filters.glutenFree}
                  onCheckedChange={() => handleFilterChange("glutenFree")}
                />
                <Label htmlFor="glutenFree">Gluten Free</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="popular"
                  checked={filters.popular}
                  onCheckedChange={() => handleFilterChange("popular")}
                />
                <Label htmlFor="popular">Popular Items</Label>
              </div>
            </div>
          </div>

          <div className="border-t pt-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium">Price Range</h4>
              <span className="text-sm text-muted-foreground">
                ${priceRange[0]} - ${priceRange[1]}
              </span>
            </div>
            <Slider
              defaultValue={priceRange}
              min={0}
              max={20}
              step={1}
              value={priceRange}
              onValueChange={(value) => setPriceRange(value as [number, number])}
              className="my-6"
            />
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16">
        {/* Hero Section */}
        <div className="relative h-[300px] overflow-hidden">
          <Image
            src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2070&auto=format&fit=crop"
            alt="Delicious food spread"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>

          <div className="absolute inset-0 flex items-center justify-center">
            <FadeIn className="text-center text-white">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">Our Menu</h1>
              <p className="text-lg md:text-xl max-w-2xl mx-auto">
                Explore our wide selection of delicious dishes prepared with the freshest ingredients
              </p>
            </FadeIn>
          </div>
        </div>

        <div className="container-custom py-8">
          <FadeIn>
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-8">
              <form onSubmit={handleSearch} className="w-full md:max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search for dishes, restaurants..."
                    className="pl-10 rounded-full"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </form>

              <Sheet open={isFilterSheetOpen} onOpenChange={setIsFilterSheetOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="md:hidden flex items-center gap-2">
                    <SlidersHorizontal className="h-4 w-4" />
                    Filters & Sort
                  </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-[80vh]">
                  <SheetHeader>
                    <SheetTitle>Filters & Sort</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 overflow-y-auto h-[calc(100%-4rem)]">
                    <FilterContent />
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </FadeIn>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Filters - Desktop */}
            <FadeIn delay={0.1} className="hidden lg:block">
              <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
                <FilterContent />
              </div>
            </FadeIn>

            {/* Menu Content */}
            <FadeIn delay={0.2} className="lg:col-span-3">
              <Tabs
                defaultValue={selectedCategory}
                value={selectedCategory}
                onValueChange={setSelectedCategory}
                className="w-full"
              >
                <div className="overflow-x-auto pb-2">
                  <TabsList className="bg-muted/50 p-1">
                    {categories.map((category) => (
                      <TabsTrigger
                        key={category.id}
                        value={category.id}
                        className="data-[state=active]:bg-white data-[state=active]:text-food-primary"
                      >
                        {category.name}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </div>

                {categories.map((category) => (
                  <TabsContent key={category.id} value={category.id} className="mt-6">
                    <div className="bg-white rounded-xl shadow-sm p-6">
                      <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-bold">{category.name}</h2>
                        <p className="text-muted-foreground">{filteredItems.length} items</p>
                      </div>

                      {filteredItems.length === 0 ? (
                        <div className="text-center py-12">
                          <h3 className="text-lg font-medium mb-2">No items found</h3>
                          <p className="text-muted-foreground mb-4">Try adjusting your filters or search criteria</p>
                          <Button onClick={handleClearFilters} variant="outline">
                            Clear all filters
                          </Button>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {filteredItems.map((item, index) => (
                            <MenuItem key={item.id} item={item} index={index} />
                          ))}
                        </div>
                      )}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </FadeIn>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
