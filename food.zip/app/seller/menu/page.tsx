import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MenuItemList } from "@/components/seller/menu-item-list"
import { Plus } from "lucide-react"

export default function MenuPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Menu Management</h1>
          <p className="text-muted-foreground">Manage your restaurant's menu items</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Add Menu Item
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <Input placeholder="Search menu items..." className="max-w-sm" />
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Items</TabsTrigger>
          <TabsTrigger value="appetizers">Appetizers</TabsTrigger>
          <TabsTrigger value="main">Main Courses</TabsTrigger>
          <TabsTrigger value="desserts">Desserts</TabsTrigger>
          <TabsTrigger value="drinks">Drinks</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Menu Items</CardTitle>
              <CardDescription>View and manage all your restaurant's menu items</CardDescription>
            </CardHeader>
            <CardContent>
              <MenuItemList />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="appetizers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Appetizers</CardTitle>
              <CardDescription>View and manage your appetizer menu items</CardDescription>
            </CardHeader>
            <CardContent>
              <MenuItemList category="appetizers" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="main" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Main Courses</CardTitle>
              <CardDescription>View and manage your main course menu items</CardDescription>
            </CardHeader>
            <CardContent>
              <MenuItemList category="main" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="desserts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Desserts</CardTitle>
              <CardDescription>View and manage your dessert menu items</CardDescription>
            </CardHeader>
            <CardContent>
              <MenuItemList category="desserts" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="drinks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Drinks</CardTitle>
              <CardDescription>View and manage your drink menu items</CardDescription>
            </CardHeader>
            <CardContent>
              <MenuItemList category="drinks" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
