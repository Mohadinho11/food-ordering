import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SalesChart } from "@/components/seller/sales-chart"
import { OrdersChart } from "@/components/seller/orders-chart"
import { PopularItemsChart } from "@/components/seller/popular-items-chart"

export default function AnalyticsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
        <p className="text-muted-foreground">Track your restaurant's performance and sales</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col gap-1">
              <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
              <h3 className="text-3xl font-bold">$12,548</h3>
              <p className="text-sm text-green-500">+12.5% from last month</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col gap-1">
              <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
              <h3 className="text-3xl font-bold">324</h3>
              <p className="text-sm text-green-500">+8.2% from last month</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col gap-1">
              <p className="text-sm font-medium text-muted-foreground">Average Order Value</p>
              <h3 className="text-3xl font-bold">$38.72</h3>
              <p className="text-sm text-green-500">+3.1% from last month</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col gap-1">
              <p className="text-sm font-medium text-muted-foreground">New Customers</p>
              <h3 className="text-3xl font-bold">156</h3>
              <p className="text-sm text-green-500">+18.3% from last month</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="sales" className="space-y-4">
        <TabsList>
          <TabsTrigger value="sales">Sales</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="items">Popular Items</TabsTrigger>
        </TabsList>
        <TabsContent value="sales" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sales Overview</CardTitle>
              <CardDescription>View your restaurant's sales performance over time</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SalesChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Orders Overview</CardTitle>
              <CardDescription>View your restaurant's order volume over time</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <OrdersChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="items" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Popular Items</CardTitle>
              <CardDescription>View your restaurant's most popular menu items</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <PopularItemsChart />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Sales by Time of Day</CardTitle>
            <CardDescription>View your restaurant's sales performance by time of day</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { time: "Morning (6am-11am)", sales: "$1,245", percentage: "15%" },
                { time: "Lunch (11am-2pm)", sales: "$3,648", percentage: "42%" },
                { time: "Afternoon (2pm-5pm)", sales: "$982", percentage: "12%" },
                { time: "Dinner (5pm-9pm)", sales: "$2,456", percentage: "28%" },
                { time: "Late Night (9pm-12am)", sales: "$217", percentage: "3%" },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">{item.time}</p>
                    <p className="text-sm text-muted-foreground">{item.sales}</p>
                  </div>
                  <div className="font-medium">{item.percentage}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sales by Category</CardTitle>
            <CardDescription>View your restaurant's sales performance by category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { category: "Main Courses", sales: "$5,245", percentage: "48%" },
                { category: "Appetizers", sales: "$1,648", percentage: "15%" },
                { category: "Desserts", sales: "$1,982", percentage: "18%" },
                { category: "Drinks", sales: "$1,456", percentage: "13%" },
                { category: "Sides", sales: "$617", percentage: "6%" },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">{item.category}</p>
                    <p className="text-sm text-muted-foreground">{item.sales}</p>
                  </div>
                  <div className="font-medium">{item.percentage}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
