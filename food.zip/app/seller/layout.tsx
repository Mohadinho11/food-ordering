import type React from "react"
import { Inter, Poppins } from "next/font/google"
import SellerNav from "@/components/seller/seller-nav"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
})

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-poppins",
  display: "swap",
})

export default function SellerLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className={`${inter.variable} ${poppins.variable} min-h-screen bg-gray-50 flex`}>
      <SellerNav />
      <div className="flex-1 p-8">
        <main>{children}</main>
      </div>
    </div>
  )
}
