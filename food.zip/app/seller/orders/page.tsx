import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { OrderList } from "@/components/seller/order-list"

export default function OrdersPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Order Management</h1>
        <p className="text-muted-foreground">View and manage your restaurant's orders</p>
      </div>

      <div className="flex items-center gap-4">
        <Input placeholder="Search orders..." className="max-w-sm" />
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Orders</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="preparing">Preparing</TabsTrigger>
          <TabsTrigger value="ready">Ready</TabsTrigger>
          <TabsTrigger value="delivered">Delivered</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Orders</CardTitle>
              <CardDescription>View and manage all your restaurant's orders</CardDescription>
            </CardHeader>
            <CardContent>
              <OrderList />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Orders</CardTitle>
              <CardDescription>View and manage pending orders</CardDescription>
            </CardHeader>
            <CardContent>
              <OrderList status="pending" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="preparing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Preparing Orders</CardTitle>
              <CardDescription>View and manage orders being prepared</CardDescription>
            </CardHeader>
            <CardContent>
              <OrderList status="preparing" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="ready" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Ready Orders</CardTitle>
              <CardDescription>View and manage orders ready for pickup or delivery</CardDescription>
            </CardHeader>
            <CardContent>
              <OrderList status="ready" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="delivered" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Delivered Orders</CardTitle>
              <CardDescription>View and manage delivered orders</CardDescription>
            </CardHeader>
            <CardContent>
              <OrderList status="delivered" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
