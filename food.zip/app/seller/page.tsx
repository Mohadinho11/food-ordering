import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DollarSign, ShoppingCart, Users, Utensils } from "lucide-react"
import { SellerOverviewChart } from "@/components/seller/seller-overview-chart"
import { RecentOrders } from "@/components/seller/recent-orders"

export default function SellerDashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's an overview of your restaurant.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
              <DollarSign className="h-5 w-5 text-brand-primary" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">$12,548</h3>
              <p className="text-sm text-green-500">+12.5%</p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
              <ShoppingCart className="h-5 w-5 text-brand-secondary" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">324</h3>
              <p className="text-sm text-green-500">+8.2%</p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Menu Items</p>
              <Utensils className="h-5 w-5 text-brand-accent" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">48</h3>
              <p className="text-sm text-green-500">+4 new</p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Added this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Customers</p>
              <Users className="h-5 w-5 text-purple-500" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">1,205</h3>
              <p className="text-sm text-green-500">+18.3%</p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to last month</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sales Overview</CardTitle>
              <CardDescription>View your restaurant's performance over time</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SellerOverviewChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="daily" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Sales</CardTitle>
              <CardDescription>View your restaurant's daily performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SellerOverviewChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="weekly" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Weekly Sales</CardTitle>
              <CardDescription>View your restaurant's weekly performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SellerOverviewChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="monthly" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Sales</CardTitle>
              <CardDescription>View your restaurant's monthly performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SellerOverviewChart />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Your restaurant's most recent orders</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentOrders />
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Popular Items</CardTitle>
            <CardDescription>Your most ordered menu items</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "Chicken Burger", orders: 124, revenue: "$1,240" },
                { name: "Margherita Pizza", orders: 98, revenue: "$1,176" },
                { name: "Caesar Salad", orders: 87, revenue: "$696" },
                { name: "Chocolate Brownie", orders: 65, revenue: "$325" },
                { name: "Garlic Bread", orders: 54, revenue: "$270" },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">{item.name}</p>
                    <p className="text-sm text-muted-foreground">{item.orders} orders</p>
                  </div>
                  <div className="font-medium">{item.revenue}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
