"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Search, ShoppingBag } from "lucide-react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"

// Sample orders data with unique IDs
const initialOrders = [
  {
    id: "ORD-7352",
    restaurant: {
      id: "rest_101",
      name: "Burger Palace",
      image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
    },
    items: [
      { id: "item_1001", name: "Classic Cheeseburger", quantity: 1, price: 9.99 },
      { id: "item_1002", name: "French Fries", quantity: 1, price: 3.99 },
      { id: "item_1003", name: "Coke", quantity: 1, price: 2.49 },
    ],
    total: 16.47,
    status: "delivered",
    date: "2023-05-15T14:30:00",
    formattedDate: "May 15, 2023",
    timeAgo: "2 days ago",
  },
  {
    id: "ORD-7351",
    restaurant: {
      id: "rest_102",
      name: "Pizza Heaven",
      image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop",
    },
    items: [
      { id: "item_2001", name: "Margherita Pizza", quantity: 1, price: 12.99 },
      { id: "item_2002", name: "Garlic Bread", quantity: 1, price: 4.99 },
    ],
    total: 17.98,
    status: "delivered",
    date: "2023-05-10T14:15:00",
    formattedDate: "May 10, 2023",
    timeAgo: "1 week ago",
  },
  {
    id: "ORD-7350",
    restaurant: {
      id: "rest_103",
      name: "Sushi World",
      image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=2070&auto=format&fit=crop",
    },
    items: [
      { id: "item_3001", name: "California Roll", quantity: 2, price: 8.99 },
      { id: "item_3002", name: "Miso Soup", quantity: 1, price: 3.99 },
    ],
    total: 21.97,
    status: "out_for_delivery",
    date: "2023-05-18T13:45:00",
    formattedDate: "May 18, 2023",
    timeAgo: "10 minutes ago",
  },
  {
    id: "ORD-7349",
    restaurant: {
      id: "rest_104",
      name: "Taco Fiesta",
      image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?q=80&w=2080&auto=format&fit=crop",
    },
    items: [
      { id: "item_4001", name: "Beef Tacos", quantity: 3, price: 3.99 },
      { id: "item_4002", name: "Guacamole", quantity: 1, price: 2.49 },
    ],
    total: 14.46,
    status: "preparing",
    date: "2023-05-18T13:00:00",
    formattedDate: "May 18, 2023",
    timeAgo: "55 minutes ago",
  },
]

export default function OrdersPage() {
  const [orders, setOrders] = useState(initialOrders)
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)

  // Filter orders based on search query and active tab
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.items.some((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesTab =
      activeTab === "all" ||
      (activeTab === "active" && ["pending", "preparing", "ready", "out_for_delivery"].includes(order.status)) ||
      (activeTab === "completed" && order.status === "delivered") ||
      (activeTab === "cancelled" && order.status === "cancelled")

    return matchesSearch && matchesTab
  })

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "outline"
      case "preparing":
        return "default"
      case "ready":
        return "secondary"
      case "out_for_delivery":
        return "warning"
      case "delivered":
        return "success"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending":
        return "Pending"
      case "preparing":
        return "Preparing"
      case "ready":
        return "Ready for pickup"
      case "out_for_delivery":
        return "Out for delivery"
      case "delivered":
        return "Delivered"
      case "cancelled":
        return "Cancelled"
      default:
        return status
    }
  }

  const viewOrderDetails = (order: any) => {
    setSelectedOrder(order)
    setIsDetailsOpen(true)
  }

  const reorderItems = (orderId: string) => {
    // In a real app, this would add the items to the cart
    const order = orders.find((o) => o.id === orderId)
    if (order) {
      // Add items to cart logic would go here
      window.location.href = "/cart"
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        <div className="container-custom max-w-4xl">
          <div className="flex items-center gap-2 mb-8">
            <Link href="/" className="text-primary hover:underline flex items-center">
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to Home
            </Link>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold">My Orders</h1>
              <p className="text-muted-foreground">View and track your order history</p>
            </div>

            <div className="w-full md:w-auto">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search orders..."
                  className="pl-8 w-full md:w-[250px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>

          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid grid-cols-3 w-full md:w-auto">
              <TabsTrigger value="all">All Orders</TabsTrigger>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6">
              {filteredOrders.length === 0 ? (
                <div className="text-center py-12">
                  <div className="mx-auto w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                    <ShoppingBag className="h-8 w-8 text-gray-400" />
                  </div>
                  <h2 className="text-xl font-bold mb-2">No orders found</h2>
                  <p className="text-muted-foreground mb-6">
                    {searchQuery ? "No orders match your search criteria" : "You haven't placed any orders yet"}
                  </p>
                  <Button asChild>
                    <Link href="/restaurants">Browse Restaurants</Link>
                  </Button>
                </div>
              ) : (
                filteredOrders.map((order) => (
                  <div
                    key={order.id}
                    className="bg-white rounded-xl shadow-sm border p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex gap-4">
                        <div className="relative h-16 w-16 rounded-md overflow-hidden shrink-0">
                          <Image
                            src={order.restaurant.image || "/placeholder.svg"}
                            alt={order.restaurant.name}
                            fill
                            className="object-cover"
                          />
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold">{order.restaurant.name}</h3>
                            <Badge variant={getStatusBadgeVariant(order.status)}>{getStatusText(order.status)}</Badge>
                          </div>

                          <p className="text-sm text-muted-foreground">
                            Order #{order.id} • {order.formattedDate} • {order.timeAgo}
                          </p>

                          <p className="text-sm mt-1">
                            {order.items.map((item) => `${item.quantity}x ${item.name}`).join(", ")}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-col md:items-end justify-between gap-2">
                        <p className="font-bold">${order.total.toFixed(2)}</p>

                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => viewOrderDetails(order)}>
                            View Details
                          </Button>

                          {order.status === "delivered" && (
                            <Button size="sm" onClick={() => reorderItems(order.id)}>
                              Reorder
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </TabsContent>

            <TabsContent value="active" className="space-y-6">
              {filteredOrders.length === 0 ? (
                <div className="text-center py-12">
                  <div className="mx-auto w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                    <ShoppingBag className="h-8 w-8 text-gray-400" />
                  </div>
                  <h2 className="text-xl font-bold mb-2">No active orders</h2>
                  <p className="text-muted-foreground mb-6">You don't have any active orders at the moment</p>
                  <Button asChild>
                    <Link href="/restaurants">Browse Restaurants</Link>
                  </Button>
                </div>
              ) : (
                filteredOrders.map((order) => (
                  <div
                    key={order.id}
                    className="bg-white rounded-xl shadow-sm border p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex gap-4">
                        <div className="relative h-16 w-16 rounded-md overflow-hidden shrink-0">
                          <Image
                            src={order.restaurant.image || "/placeholder.svg"}
                            alt={order.restaurant.name}
                            fill
                            className="object-cover"
                          />
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold">{order.restaurant.name}</h3>
                            <Badge variant={getStatusBadgeVariant(order.status)}>{getStatusText(order.status)}</Badge>
                          </div>

                          <p className="text-sm text-muted-foreground">
                            Order #{order.id} • {order.formattedDate} • {order.timeAgo}
                          </p>

                          <p className="text-sm mt-1">
                            {order.items.map((item) => `${item.quantity}x ${item.name}`).join(", ")}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-col md:items-end justify-between gap-2">
                        <p className="font-bold">${order.total.toFixed(2)}</p>

                        <Button variant="outline" size="sm" onClick={() => viewOrderDetails(order)}>
                          Track Order
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </TabsContent>

            <TabsContent value="completed" className="space-y-6">
              {filteredOrders.length === 0 ? (
                <div className="text-center py-12">
                  <div className="mx-auto w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                    <ShoppingBag className="h-8 w-8 text-gray-400" />
                  </div>
                  <h2 className="text-xl font-bold mb-2">No completed orders</h2>
                  <p className="text-muted-foreground mb-6">You don't have any completed orders yet</p>
                  <Button asChild>
                    <Link href="/restaurants">Browse Restaurants</Link>
                  </Button>
                </div>
              ) : (
                filteredOrders.map((order) => (
                  <div
                    key={order.id}
                    className="bg-white rounded-xl shadow-sm border p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex gap-4">
                        <div className="relative h-16 w-16 rounded-md overflow-hidden shrink-0">
                          <Image
                            src={order.restaurant.image || "/placeholder.svg"}
                            alt={order.restaurant.name}
                            fill
                            className="object-cover"
                          />
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold">{order.restaurant.name}</h3>
                            <Badge variant={getStatusBadgeVariant(order.status)}>{getStatusText(order.status)}</Badge>
                          </div>

                          <p className="text-sm text-muted-foreground">
                            Order #{order.id} • {order.formattedDate} • {order.timeAgo}
                          </p>

                          <p className="text-sm mt-1">
                            {order.items.map((item) => `${item.quantity}x ${item.name}`).join(", ")}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-col md:items-end justify-between gap-2">
                        <p className="font-bold">${order.total.toFixed(2)}</p>

                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => viewOrderDetails(order)}>
                            View Details
                          </Button>

                          <Button size="sm" onClick={() => reorderItems(order.id)}>
                            Reorder
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Order Details Dialog */}
      {selectedOrder && (
        <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Order Details</DialogTitle>
              <DialogDescription>
                Order #{selectedOrder.id} • {selectedOrder.formattedDate}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="relative h-12 w-12 rounded-md overflow-hidden shrink-0">
                  <Image
                    src={selectedOrder.restaurant.image || "/placeholder.svg"}
                    alt={selectedOrder.restaurant.name}
                    fill
                    className="object-cover"
                  />
                </div>

                <div>
                  <h3 className="font-bold">{selectedOrder.restaurant.name}</h3>
                  <p className="text-sm text-muted-foreground">{selectedOrder.timeAgo}</p>
                </div>

                <Badge variant={getStatusBadgeVariant(selectedOrder.status)} className="ml-auto">
                  {getStatusText(selectedOrder.status)}
                </Badge>
              </div>

              <Separator />

              <div>
                <h3 className="font-medium mb-2">Order Items</h3>
                <div className="space-y-2">
                  {selectedOrder.items.map((item: any) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>
                        {item.quantity}x {item.name}
                      </span>
                      <span>${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${(selectedOrder.total * 0.9).toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Delivery Fee</span>
                  <span>$2.99</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tax</span>
                  <span>${(selectedOrder.total * 0.1).toFixed(2)}</span>
                </div>

                <div className="flex justify-between font-medium pt-2">
                  <span>Total</span>
                  <span>${selectedOrder.total.toFixed(2)}</span>
                </div>
              </div>

              {selectedOrder.status === "delivered" && (
                <div className="pt-2">
                  <Button
                    className="w-full"
                    onClick={() => {
                      reorderItems(selectedOrder.id)
                      setIsDetailsOpen(false)
                    }}
                  >
                    Reorder
                  </Button>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>
                Close
              </Button>

              {["pending", "preparing", "ready", "out_for_delivery"].includes(selectedOrder.status) && (
                <Link href={`/track-order/${selectedOrder.id}`} passHref>
                  <Button>Track Order</Button>
                </Link>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      <Footer />
    </div>
  )
}
