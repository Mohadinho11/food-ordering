"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Check, Clock, MapPin, Phone, User } from "lucide-react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"

// Sample order data
const orderData = {
  id: "ORD-7350",
  restaurant: {
    id: "rest_103",
    name: "Sushi World",
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=2070&auto=format&fit=crop",
    phone: "(555) 123-4567",
    address: "123 Sushi Lane, Foodville, CA 12345",
  },
  items: [
    { id: "item_3001", name: "California Roll", quantity: 2, price: 8.99 },
    { id: "item_3002", name: "Miso Soup", quantity: 1, price: 3.99 },
  ],
  total: 21.97,
  status: "out_for_delivery",
  date: "2023-05-18T13:45:00",
  formattedDate: "May 18, 2023",
  timeAgo: "10 minutes ago",
  estimatedDelivery: "2023-05-18T14:30:00",
  formattedEstimatedDelivery: "2:30 PM",
  deliveryAddress: {
    street: "456 Customer Ave",
    city: "Foodville",
    state: "CA",
    zipCode: "12345",
  },
  driver: {
    name: "Michael Johnson",
    phone: "(555) 987-6543",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
  },
  statusHistory: [
    { status: "pending", timestamp: "2023-05-18T13:30:00", formattedTime: "1:30 PM" },
    { status: "confirmed", timestamp: "2023-05-18T13:35:00", formattedTime: "1:35 PM" },
    { status: "preparing", timestamp: "2023-05-18T13:40:00", formattedTime: "1:40 PM" },
    { status: "ready", timestamp: "2023-05-18T14:00:00", formattedTime: "2:00 PM" },
    { status: "out_for_delivery", timestamp: "2023-05-18T14:10:00", formattedTime: "2:10 PM" },
  ],
}

export default function TrackOrderPage({ params }: { params: { id: string } }) {
  const [order, setOrder] = useState(orderData)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [isLoading, setIsLoading] = useState(true)

  // Simulate fetching order data
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Update current time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 60000)

    return () => clearInterval(timer)
  }, [])

  // Calculate delivery progress
  const calculateProgress = () => {
    const startTime = new Date(order.statusHistory[0].timestamp).getTime()
    const endTime = new Date(order.estimatedDelivery).getTime()
    const now = currentTime.getTime()

    const totalDuration = endTime - startTime
    const elapsed = now - startTime

    let progress = Math.min(Math.max((elapsed / totalDuration) * 100, 0), 100)

    // If order is delivered, set progress to 100%
    if (order.status === "delivered") {
      progress = 100
    }

    return progress
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending":
        return "Order Placed"
      case "confirmed":
        return "Order Confirmed"
      case "preparing":
        return "Preparing Your Order"
      case "ready":
        return "Ready for Pickup"
      case "out_for_delivery":
        return "Out for Delivery"
      case "delivered":
        return "Delivered"
      case "cancelled":
        return "Cancelled"
      default:
        return status
    }
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "outline"
      case "confirmed":
      case "preparing":
        return "default"
      case "ready":
        return "secondary"
      case "out_for_delivery":
        return "warning"
      case "delivered":
        return "success"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  const contactDriver = () => {
    toast({
      title: "Contacting driver",
      description: `Calling ${order.driver.name} at ${order.driver.phone}`,
    })
  }

  const contactRestaurant = () => {
    toast({
      title: "Contacting restaurant",
      description: `Calling ${order.restaurant.name} at ${order.restaurant.phone}`,
    })
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1 pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
            <p className="mt-4 text-lg">Loading order details...</p>
          </div>
        </main>

        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        <div className="container-custom max-w-4xl">
          <div className="flex items-center gap-2 mb-8">
            <Link href="/orders" className="text-primary hover:underline flex items-center">
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to Orders
            </Link>
          </div>

          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            {/* Order Header */}
            <div className="p-6 bg-primary/5">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-2xl font-bold">Tracking Order #{order.id}</h1>
                    <Badge variant={getStatusBadgeVariant(order.status)}>{getStatusText(order.status)}</Badge>
                  </div>
                  <p className="text-muted-foreground">
                    {order.formattedDate} • {order.timeAgo}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="outline" onClick={contactRestaurant}>
                    <Phone className="h-4 w-4 mr-2" />
                    Contact Restaurant
                  </Button>
                </div>
              </div>
            </div>

            {/* Order Progress */}
            <div className="p-6 border-b">
              <div className="mb-4">
                <div className="flex justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Estimated Delivery</span>
                  </div>
                  <span className="font-medium">{order.formattedEstimatedDelivery}</span>
                </div>

                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-primary h-2.5 rounded-full" style={{ width: `${calculateProgress()}%` }}></div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mt-6">
                {["pending", "confirmed", "preparing", "ready", "out_for_delivery"].map((status, index) => {
                  const statusEntry = order.statusHistory.find((s) => s.status === status)
                  const isCompleted = statusEntry !== undefined
                  const isCurrent = order.status === status

                  return (
                    <div key={status} className="flex flex-col items-center text-center">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                          isCompleted ? "bg-primary text-white" : "bg-gray-200 text-gray-400"
                        }`}
                      >
                        {isCompleted ? <Check className="h-5 w-5" /> : <span>{index + 1}</span>}
                      </div>
                      <p className={`text-sm font-medium ${isCurrent ? "text-primary" : ""}`}>
                        {getStatusText(status)}
                      </p>
                      {statusEntry && <p className="text-xs text-muted-foreground">{statusEntry.formattedTime}</p>}
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Driver Info (if out for delivery) */}
            {order.status === "out_for_delivery" && order.driver && (
              <div className="p-6 border-b">
                <h2 className="text-lg font-bold mb-4">Delivery Driver</h2>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="relative h-12 w-12 rounded-full overflow-hidden">
                      <Image
                        src={order.driver.image || "/placeholder.svg"}
                        alt={order.driver.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">{order.driver.name}</p>
                      <p className="text-sm text-muted-foreground">{order.driver.phone}</p>
                    </div>
                  </div>

                  <Button onClick={contactDriver}>
                    <Phone className="h-4 w-4 mr-2" />
                    Contact Driver
                  </Button>
                </div>
              </div>
            )}

            {/* Order Details */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h2 className="text-lg font-bold mb-4">Order Details</h2>

                <div className="flex items-center gap-3 mb-4">
                  <div className="relative h-12 w-12 rounded-md overflow-hidden">
                    <Image
                      src={order.restaurant.image || "/placeholder.svg"}
                      alt={order.restaurant.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <p className="font-medium">{order.restaurant.name}</p>
                    <p className="text-sm text-muted-foreground">{order.restaurant.address}</p>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  {order.items.map((item) => (
                    <div key={item.id} className="flex justify-between">
                      <span>
                        {item.quantity}x {item.name}
                      </span>
                      <span>${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                <Separator className="my-4" />

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>${(order.total * 0.9).toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Delivery Fee</span>
                    <span>$2.99</span>
                  </div>

                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Tax</span>
                    <span>${(order.total * 0.1).toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between font-medium pt-2">
                    <span>Total</span>
                    <span>${order.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-lg font-bold mb-4">Delivery Information</h2>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Delivery Address</p>
                      <p className="text-sm text-muted-foreground">{order.deliveryAddress.street}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.deliveryAddress.city}, {order.deliveryAddress.state} {order.deliveryAddress.zipCode}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Estimated Delivery Time</p>
                      <p className="text-sm text-muted-foreground">{order.formattedEstimatedDelivery}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <User className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Order Placed By</p>
                      <p className="text-sm text-muted-foreground">John Doe</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <Button variant="outline" className="w-full" asChild>
                    <Link href={`/restaurants/${order.restaurant.id}`}>View Restaurant</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
