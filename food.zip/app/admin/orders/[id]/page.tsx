"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Calendar, CreditCard, Download, Loader2, MapPin, Package, Printer, Truck, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import Link from "next/link"

export default function OrderDetailsPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { id } = params

  const [isLoading, setIsLoading] = useState(true)
  const [isUpdating, setIsUpdating] = useState(false)
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false)

  const [order, setOrder] = useState<any>(null)

  useEffect(() => {
    // Simulate API call to fetch order
    const fetchOrder = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Sample order data - in a real app, this would come from an API
        const sampleOrder = {
          id: id,
          customer: {
            id: "cust-1",
            name: "John Smith",
            email: "john.smith@example.com",
            phone: "+1 (555) 123-4567",
            image: "https://randomuser.me/api/portraits/men/32.jpg",
          },
          amount: 124.5,
          subtotal: 110.0,
          tax: 8.8,
          shipping: 5.7,
          items: [
            {
              id: "item-1",
              name: "Smartphone X Pro",
              price: 99.99,
              quantity: 1,
              image: "/placeholder.svg?height=80&width=80",
            },
            {
              id: "item-2",
              name: "Wireless Earbuds",
              price: 5.99,
              quantity: 1,
              image: "/placeholder.svg?height=80&width=80",
            },
            {
              id: "item-3",
              name: "Phone Case",
              price: 4.02,
              quantity: 1,
              image: "/placeholder.svg?height=80&width=80",
            },
          ],
          status: "processing",
          paymentStatus: "paid",
          paymentMethod: "credit_card",
          paymentDetails: {
            cardType: "Visa",
            lastFour: "4242",
          },
          shippingAddress: {
            street: "123 Main St",
            city: "Anytown",
            state: "CA",
            zipCode: "12345",
            country: "United States",
          },
          billingAddress: {
            street: "123 Main St",
            city: "Anytown",
            state: "CA",
            zipCode: "12345",
            country: "United States",
          },
          date: "2023-05-15T14:30:00",
          formattedDate: "May 15, 2023",
          timeAgo: "2 days ago",
          notes: "",
          statusHistory: [
            {
              status: "pending",
              timestamp: "2023-05-15T14:30:00",
              formattedTime: "May 15, 2023 2:30 PM",
            },
            {
              status: "processing",
              timestamp: "2023-05-15T15:45:00",
              formattedTime: "May 15, 2023 3:45 PM",
            },
          ],
        }

        setOrder(sampleOrder)
      } catch (error) {
        console.error("Error fetching order:", error)
        toast({
          title: "Error",
          description: "Failed to fetch order details. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchOrder()
  }, [id])

  const handleStatusChange = async (newStatus: string) => {
    setIsUpdating(true)

    try {
      // Simulate API call to update order status
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Update local state
      setOrder((prev) => ({
        ...prev,
        status: newStatus,
        statusHistory: [
          ...prev.statusHistory,
          {
            status: newStatus,
            timestamp: new Date().toISOString(),
            formattedTime: new Date().toLocaleString(),
          },
        ],
      }))

      toast({
        title: "Status Updated",
        description: `Order status has been updated to ${newStatus}.`,
      })
    } catch (error) {
      console.error("Error updating order status:", error)
      toast({
        title: "Error",
        description: "Failed to update order status. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsUpdating(false)
    }
  }

  const handleCancelOrder = async () => {
    setIsUpdating(true)
    setIsCancelDialogOpen(false)

    try {
      // Simulate API call to cancel order
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Update local state
      setOrder((prev) => ({
        ...prev,
        status: "cancelled",
        statusHistory: [
          ...prev.statusHistory,
          {
            status: "cancelled",
            timestamp: new Date().toISOString(),
            formattedTime: new Date().toLocaleString(),
          },
        ],
      }))

      toast({
        title: "Order Cancelled",
        description: `Order ${id} has been cancelled.`,
      })
    } catch (error) {
      console.error("Error cancelling order:", error)
      toast({
        title: "Error",
        description: "Failed to cancel order. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsUpdating(false)
    }
  }

  const handlePrintInvoice = () => {
    toast({
      title: "Printing Invoice",
      description: "The invoice is being prepared for printing.",
    })
    // In a real app, this would open a print dialog or generate a PDF
  }

  const handleDownloadInvoice = () => {
    toast({
      title: "Downloading Invoice",
      description: "The invoice is being downloaded.",
    })
    // In a real app, this would download a PDF
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "outline"
      case "processing":
        return "default"
      case "shipped":
        return "secondary"
      case "delivered":
        return "success"
      case "cancelled":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getPaymentStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "paid":
        return "success"
      case "pending":
        return "warning"
      case "refunded":
        return "destructive"
      default:
        return "outline"
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-200px)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!order) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-200px)]">
        <h2 className="text-2xl font-bold mb-2">Order Not Found</h2>
        <p className="text-muted-foreground mb-4">The order you are looking for does not exist or has been deleted.</p>
        <Button asChild>
          <Link href="/admin/orders">Back to Orders</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/orders">
                <ArrowLeft className="h-4 w-4" />
                <span className="sr-only">Back</span>
              </Link>
            </Button>
            <h1 className="text-3xl font-bold tracking-tight">Order {order.id}</h1>
          </div>
          <p className="text-muted-foreground">
            Placed on {order.formattedDate} • {order.timeAgo}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={handlePrintInvoice}>
            <Printer className="mr-2 h-4 w-4" />
            Print Invoice
          </Button>
          <Button variant="outline" onClick={handleDownloadInvoice}>
            <Download className="mr-2 h-4 w-4" />
            Download Invoice
          </Button>
          {order.status !== "cancelled" && order.status !== "delivered" && (
            <Button variant="destructive" onClick={() => setIsCancelDialogOpen(true)} disabled={isUpdating}>
              Cancel Order
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle>Order Status</CardTitle>
                <Badge variant={getStatusBadgeVariant(order.status)}>{order.status}</Badge>
              </div>
              <CardDescription>Current status and history of this order</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Update Status</p>
                  <p className="text-xs text-muted-foreground">Change the current status of this order</p>
                </div>
                <div className="flex items-center gap-2">
                  <Select
                    value={order.status}
                    onValueChange={handleStatusChange}
                    disabled={isUpdating || order.status === "cancelled" || order.status === "delivered"}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="shipped">Shipped</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Status History</h3>
                <div className="space-y-4">
                  {order.statusHistory.map((history: any, index: number) => (
                    <div key={index} className="flex items-start gap-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                          index === order.statusHistory.length - 1 ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                      >
                        {index === 0 && <Calendar className="h-4 w-4" />}
                        {index === 1 && <Package className="h-4 w-4" />}
                        {index === 2 && <Truck className="h-4 w-4" />}
                      </div>
                      <div className="space-y-1">
                        <p className="font-medium">{history.status}</p>
                        <p className="text-sm text-muted-foreground">{history.formattedTime}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Order Items</CardTitle>
              <CardDescription>Items included in this order</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {order.items.map((item: any) => (
                  <div key={item.id} className="flex items-center gap-4">
                    <div className="relative h-16 w-16 rounded overflow-hidden shrink-0">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="object-cover h-full w-full"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{item.name}</p>
                      <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                      <p className="text-sm text-muted-foreground">${item.price.toFixed(2)} each</p>
                    </div>
                  </div>
                ))}
              </div>

              <Separator className="my-4" />

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${order.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tax</span>
                  <span>${order.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>${order.shipping.toFixed(2)}</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between font-medium">
                  <span>Total</span>
                  <span>${order.amount.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Customer</CardTitle>
              <CardDescription>Customer information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3 mb-4">
                <div className="relative h-10 w-10 rounded-full overflow-hidden shrink-0">
                  <img
                    src={order.customer.image || "/placeholder.svg"}
                    alt={order.customer.name}
                    className="object-cover h-full w-full"
                  />
                </div>
                <div>
                  <p className="font-medium">{order.customer.name}</p>
                  <p className="text-sm text-muted-foreground">{order.customer.email}</p>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <User className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Contact Information</p>
                    <p className="text-sm text-muted-foreground">{order.customer.email}</p>
                    <p className="text-sm text-muted-foreground">{order.customer.phone}</p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" asChild className="w-full">
                <Link href={`/admin/customers/${order.customer.id}`}>View Customer</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment</CardTitle>
              <CardDescription>Payment details and status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <p className="font-medium">Status</p>
                <Badge variant={getPaymentStatusBadgeVariant(order.paymentStatus)}>{order.paymentStatus}</Badge>
              </div>

              <Separator className="my-4" />

              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <CreditCard className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Payment Method</p>
                    <p className="text-sm text-muted-foreground">
                      {order.paymentMethod === "credit_card" ? "Credit Card" : order.paymentMethod}
                    </p>
                    {order.paymentDetails && (
                      <p className="text-sm text-muted-foreground">
                        {order.paymentDetails.cardType} ending in {order.paymentDetails.lastFour}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Shipping</CardTitle>
              <CardDescription>Shipping address and details</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Shipping Address</p>
                    <p className="text-sm text-muted-foreground">{order.shippingAddress.street}</p>
                    <p className="text-sm text-muted-foreground">
                      {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}
                    </p>
                    <p className="text-sm text-muted-foreground">{order.shippingAddress.country}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Cancel Order Confirmation Dialog */}
      <AlertDialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Order</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to cancel this order? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>No, keep order</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleCancelOrder}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Yes, cancel order
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
