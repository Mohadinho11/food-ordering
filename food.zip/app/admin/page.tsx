import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, Store, ShoppingBag, DollarSign, ArrowUpRight, ArrowDownRight } from "lucide-react"
import { AdminDashboardChart } from "@/components/admin/admin-dashboard-chart"
import { AdminRecentOrders } from "@/components/admin/admin-recent-orders"
import { AdminTopRestaurants } from "@/components/admin/admin-top-restaurants"

export default function AdminDashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your platform's performance and metrics</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Users</p>
              <Users className="h-5 w-5 text-primary" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">2,845</h3>
              <p className="text-sm text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                +12.5%
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Restaurants</p>
              <Store className="h-5 w-5 text-secondary" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">156</h3>
              <p className="text-sm text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                +8.2%
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
              <ShoppingBag className="h-5 w-5 text-accent" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">1,248</h3>
              <p className="text-sm text-red-500 flex items-center">
                <ArrowDownRight className="h-3 w-3 mr-1" />
                -3.1%
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
              <DollarSign className="h-5 w-5 text-purple-500" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">$48,295</h3>
              <p className="text-sm text-green-500 flex items-center">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                +18.3%
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to last month</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Platform Performance</CardTitle>
              <CardDescription>View your platform's performance over time</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <AdminDashboardChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="daily" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Performance</CardTitle>
              <CardDescription>View your platform's daily performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <AdminDashboardChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="weekly" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Weekly Performance</CardTitle>
              <CardDescription>View your platform's weekly performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <AdminDashboardChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="monthly" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Performance</CardTitle>
              <CardDescription>View your platform's monthly performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <AdminDashboardChart />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Latest orders across the platform</CardDescription>
          </CardHeader>
          <CardContent>
            <AdminRecentOrders />
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Top Restaurants</CardTitle>
            <CardDescription>Best performing restaurants</CardDescription>
          </CardHeader>
          <CardContent>
            <AdminTopRestaurants />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
