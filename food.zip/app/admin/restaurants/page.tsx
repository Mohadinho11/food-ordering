"use client"

import { useState } from "react"
import { ArrowUpDown, Check, Eye, MoreHorizontal, Search, Store, Trash2, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import Image from "next/image"

// Sample restaurants data
const initialRestaurants = [
  {
    id: "1",
    name: "Burger Palace",
    owner: "Sarah Johnson",
    email: "info@burgerpalace.com",
    phone: "(555) 123-4567",
    cuisine: "American",
    status: "active",
    createdAt: "2023-01-15",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
    rating: 4.8,
  },
  {
    id: "2",
    name: "Pizza Heaven",
    owner: "David Wilson",
    email: "contact@pizzaheaven.com",
    phone: "(555) 987-6543",
    cuisine: "Italian",
    status: "active",
    createdAt: "2023-02-20",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop",
    rating: 4.6,
  },
  {
    id: "3",
    name: "Sushi World",
    owner: "Jennifer Anderson",
    email: "hello@sushiworld.com",
    phone: "(555) 456-7890",
    cuisine: "Japanese",
    status: "pending",
    createdAt: "2023-03-10",
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=2070&auto=format&fit=crop",
    rating: 4.9,
  },
  {
    id: "4",
    name: "Taco Fiesta",
    owner: "Robert Martinez",
    email: "hola@tacofiesta.com",
    phone: "(555) 234-5678",
    cuisine: "Mexican",
    status: "active",
    createdAt: "2023-01-05",
    image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?q=80&w=2080&auto=format&fit=crop",
    rating: 4.7,
  },
  {
    id: "5",
    name: "Thai Spice",
    owner: "Michael Brown",
    email: "info@thaispice.com",
    phone: "(555) 876-5432",
    cuisine: "Thai",
    status: "inactive",
    createdAt: "2023-04-18",
    image: "https://images.unsplash.com/photo-1562565652-a0d8f0c59eb4?q=80&w=1932&auto=format&fit=crop",
    rating: 4.5,
  },
]

export default function RestaurantsPage() {
  const [restaurants, setRestaurants] = useState(initialRestaurants)
  const [searchQuery, setSearchQuery] = useState("")
  const [cuisineFilter, setCuisineFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedRestaurant, setSelectedRestaurant] = useState<any>(null)

  // Filter restaurants based on search query, cuisine, and status
  const filteredRestaurants = restaurants.filter((restaurant) => {
    const matchesSearch =
      restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      restaurant.owner.toLowerCase().includes(searchQuery.toLowerCase()) ||
      restaurant.email.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCuisine = cuisineFilter === "all" || restaurant.cuisine === cuisineFilter
    const matchesStatus = statusFilter === "all" || restaurant.status === statusFilter

    return matchesSearch && matchesCuisine && matchesStatus
  })

  const handleApproveRestaurant = (id: string) => {
    setRestaurants(
      restaurants.map((restaurant) => (restaurant.id === id ? { ...restaurant, status: "active" } : restaurant)),
    )

    toast({
      title: "Restaurant approved",
      description: "The restaurant has been approved and is now active",
    })
  }

  const handleRejectRestaurant = (id: string) => {
    setRestaurants(
      restaurants.map((restaurant) => (restaurant.id === id ? { ...restaurant, status: "inactive" } : restaurant)),
    )

    toast({
      title: "Restaurant rejected",
      description: "The restaurant has been rejected",
      variant: "destructive",
    })
  }

  const handleDeleteRestaurant = () => {
    if (!selectedRestaurant) return

    setRestaurants(restaurants.filter((restaurant) => restaurant.id !== selectedRestaurant.id))
    setIsDeleteDialogOpen(false)

    toast({
      title: "Restaurant deleted",
      description: `${selectedRestaurant.name} has been deleted`,
      variant: "destructive",
    })
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "active":
        return "success"
      case "inactive":
        return "destructive"
      case "pending":
        return "warning"
      default:
        return "outline"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Restaurants</h1>
          <p className="text-muted-foreground">Manage restaurants and approvals</p>
        </div>
        <Button className="flex items-center gap-2">
          <Store className="h-4 w-4" />
          Add Restaurant
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="flex-1">
          <label htmlFor="search" className="text-sm font-medium">
            Search
          </label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              id="search"
              placeholder="Search by name, owner, or email..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        <div className="w-full md:w-[180px]">
          <label htmlFor="cuisine-filter" className="text-sm font-medium">
            Cuisine
          </label>
          <Select value={cuisineFilter} onValueChange={setCuisineFilter}>
            <SelectTrigger id="cuisine-filter">
              <SelectValue placeholder="Filter by cuisine" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Cuisines</SelectItem>
              <SelectItem value="American">American</SelectItem>
              <SelectItem value="Italian">Italian</SelectItem>
              <SelectItem value="Japanese">Japanese</SelectItem>
              <SelectItem value="Mexican">Mexican</SelectItem>
              <SelectItem value="Thai">Thai</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="w-full md:w-[180px]">
          <label htmlFor="status-filter" className="text-sm font-medium">
            Status
          </label>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger id="status-filter">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[250px]">
                <Button variant="ghost" className="p-0 hover:bg-transparent">
                  <span>Restaurant</span>
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Cuisine</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>
                <Button variant="ghost" className="p-0 hover:bg-transparent">
                  <span>Rating</span>
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredRestaurants.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">
                  No restaurants found.
                </TableCell>
              </TableRow>
            ) : (
              filteredRestaurants.map((restaurant) => (
                <TableRow key={restaurant.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <div className="relative h-10 w-10 rounded-md overflow-hidden">
                        <Image
                          src={restaurant.image || "/placeholder.svg"}
                          alt={restaurant.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      {restaurant.name}
                    </div>
                  </TableCell>
                  <TableCell>{restaurant.owner}</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="text-xs">{restaurant.email}</span>
                      <span className="text-xs text-muted-foreground">{restaurant.phone}</span>
                    </div>
                  </TableCell>
                  <TableCell>{restaurant.cuisine}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        restaurant.status === "active"
                          ? "bg-green-50 text-green-700 border-green-200"
                          : restaurant.status === "inactive"
                            ? "bg-red-50 text-red-700 border-red-200"
                            : "bg-yellow-50 text-yellow-700 border-yellow-200"
                      }
                    >
                      {restaurant.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{restaurant.rating}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      {restaurant.status === "pending" && (
                        <>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 text-green-600"
                            onClick={() => handleApproveRestaurant(restaurant.id)}
                          >
                            <Check className="h-4 w-4" />
                            <span className="sr-only">Approve</span>
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 text-red-600"
                            onClick={() => handleRejectRestaurant(restaurant.id)}
                          >
                            <X className="h-4 w-4" />
                            <span className="sr-only">Reject</span>
                          </Button>
                        </>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem
                            onClick={() => {
                              setSelectedRestaurant(restaurant)
                              setIsViewDialogOpen(true)
                            }}
                          >
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => {
                              setSelectedRestaurant(restaurant)
                              setIsDeleteDialogOpen(true)
                            }}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* View Restaurant Dialog */}
      {selectedRestaurant && (
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Restaurant Details</DialogTitle>
              <DialogDescription>View restaurant information</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="relative h-40 w-full rounded-md overflow-hidden">
                <Image
                  src={selectedRestaurant.image || "/placeholder.svg"}
                  alt={selectedRestaurant.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Name</h3>
                  <p className="font-medium">{selectedRestaurant.name}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Owner</h3>
                  <p className="font-medium">{selectedRestaurant.owner}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
                  <p className="font-medium">{selectedRestaurant.email}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Phone</h3>
                  <p className="font-medium">{selectedRestaurant.phone}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Cuisine</h3>
                  <p className="font-medium">{selectedRestaurant.cuisine}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Rating</h3>
                  <p className="font-medium">{selectedRestaurant.rating}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                  <Badge
                    variant="outline"
                    className={
                      selectedRestaurant.status === "active"
                        ? "bg-green-50 text-green-700 border-green-200"
                        : selectedRestaurant.status === "inactive"
                          ? "bg-red-50 text-red-700 border-red-200"
                          : "bg-yellow-50 text-yellow-700 border-yellow-200"
                    }
                  >
                    {selectedRestaurant.status}
                  </Badge>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Created</h3>
                  <p className="font-medium">{selectedRestaurant.createdAt}</p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                Close
              </Button>
              {selectedRestaurant.status === "pending" && (
                <>
                  <Button
                    variant="destructive"
                    onClick={() => {
                      handleRejectRestaurant(selectedRestaurant.id)
                      setIsViewDialogOpen(false)
                    }}
                  >
                    Reject
                  </Button>
                  <Button
                    onClick={() => {
                      handleApproveRestaurant(selectedRestaurant.id)
                      setIsViewDialogOpen(false)
                    }}
                  >
                    Approve
                  </Button>
                </>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Restaurant Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Restaurant</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedRestaurant?.name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteRestaurant}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
