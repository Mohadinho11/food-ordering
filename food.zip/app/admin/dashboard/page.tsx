"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DollarSign, Package, ShoppingCart, Users } from "lucide-react"
import { RevenueChart } from "@/components/admin/dashboard/revenue-chart"
import { RecentOrders } from "@/components/admin/dashboard/recent-orders"
import { TopProducts } from "@/components/admin/dashboard/top-products"
import { Button } from "@/components/ui/button"
import { DateRangePicker } from "@/components/admin/dashboard/date-range-picker"

export default function AdminDashboardPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [metrics, setMetrics] = useState({
    totalRevenue: 0,
    totalOrders: 0,
    totalProducts: 0,
    totalCustomers: 0,
    revenueGrowth: 0,
    ordersGrowth: 0,
    productsGrowth: 0,
    customersGrowth: 0,
  })
  const [dateRange, setDateRange] = useState({ from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), to: new Date() })

  useEffect(() => {
    // In a real app, this would fetch data from an API
    const fetchDashboardData = async () => {
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        setMetrics({
          totalRevenue: 48295,
          totalOrders: 1248,
          totalProducts: 156,
          totalCustomers: 2845,
          revenueGrowth: 18.3,
          ordersGrowth: -3.1,
          productsGrowth: 8.2,
          customersGrowth: 12.5,
        })
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDashboardData()
  }, [dateRange])

  const handleDateRangeChange = (range: { from: Date; to: Date }) => {
    setDateRange(range)
    setIsLoading(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Overview of your store's performance and metrics</p>
        </div>
        <div className="flex items-center gap-2">
          <DateRangePicker dateRange={dateRange} onChange={handleDateRangeChange} />
          <Button variant="outline">Export</Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className={isLoading ? "animate-pulse" : ""}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
              <DollarSign className="h-5 w-5 text-primary" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">${metrics.totalRevenue.toLocaleString()}</h3>
              <p className={`text-sm ${metrics.revenueGrowth >= 0 ? "text-green-500" : "text-red-500"}`}>
                {metrics.revenueGrowth >= 0 ? "+" : ""}
                {metrics.revenueGrowth}%
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to previous period</p>
          </CardContent>
        </Card>

        <Card className={isLoading ? "animate-pulse" : ""}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
              <ShoppingCart className="h-5 w-5 text-secondary" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">{metrics.totalOrders.toLocaleString()}</h3>
              <p className={`text-sm ${metrics.ordersGrowth >= 0 ? "text-green-500" : "text-red-500"}`}>
                {metrics.ordersGrowth >= 0 ? "+" : ""}
                {metrics.ordersGrowth}%
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to previous period</p>
          </CardContent>
        </Card>

        <Card className={isLoading ? "animate-pulse" : ""}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Products</p>
              <Package className="h-5 w-5 text-accent" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">{metrics.totalProducts.toLocaleString()}</h3>
              <p className={`text-sm ${metrics.productsGrowth >= 0 ? "text-green-500" : "text-red-500"}`}>
                {metrics.productsGrowth >= 0 ? "+" : ""}
                {metrics.productsGrowth}%
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to previous period</p>
          </CardContent>
        </Card>

        <Card className={isLoading ? "animate-pulse" : ""}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-y-0">
              <p className="text-sm font-medium text-muted-foreground">Total Customers</p>
              <Users className="h-5 w-5 text-purple-500" />
            </div>
            <div className="flex items-baseline space-x-2">
              <h3 className="text-3xl font-bold">{metrics.totalCustomers.toLocaleString()}</h3>
              <p className={`text-sm ${metrics.customersGrowth >= 0 ? "text-green-500" : "text-red-500"}`}>
                {metrics.customersGrowth >= 0 ? "+" : ""}
                {metrics.customersGrowth}%
              </p>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Compared to previous period</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Overview</CardTitle>
              <CardDescription>View your store's revenue performance over time</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <RevenueChart isLoading={isLoading} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="daily" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Revenue</CardTitle>
              <CardDescription>View your store's daily revenue performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <RevenueChart isLoading={isLoading} interval="daily" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="weekly" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Weekly Revenue</CardTitle>
              <CardDescription>View your store's weekly revenue performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <RevenueChart isLoading={isLoading} interval="weekly" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="monthly" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Revenue</CardTitle>
              <CardDescription>View your store's monthly revenue performance</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <RevenueChart isLoading={isLoading} interval="monthly" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Latest orders across the platform</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentOrders isLoading={isLoading} />
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Top Products</CardTitle>
            <CardDescription>Best selling products</CardDescription>
          </CardHeader>
          <CardContent>
            <TopProducts isLoading={isLoading} />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
