"use client"

import { useState, useEffect } from "react"
import { Calendar, Download, TrendingUp, TrendingDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"
import { RevenueChart } from "@/components/admin/analytics/revenue-chart"
import { ProductPerformanceChart } from "@/components/admin/analytics/product-performance-chart"
import { SalesByCategory } from "@/components/admin/analytics/sales-by-category"
import { DateRangePicker } from "@/components/admin/dashboard/date-range-picker"

export default function AnalyticsPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [dateRange, setDateRange] = useState({ from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), to: new Date() })
  const [timeframe, setTimeframe] = useState("30d")
  const [metrics, setMetrics] = useState({
    totalRevenue: 0,
    totalOrders: 0,
    averageOrderValue: 0,
    conversionRate: 0,
    revenueGrowth: 0,
    ordersGrowth: 0,
    aovGrowth: 0,
    conversionGrowth: 0,
  })
  const [topProducts, setTopProducts] = useState<any[]>([])
  const [topCategories, setTopCategories] = useState<any[]>([])

  useEffect(() => {
    // Simulate API call
    const fetchAnalyticsData = async () => {
      try {
        setIsLoading(true)
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Sample data - in a real app, this would come from an API
        setMetrics({
          totalRevenue: 48295.75,
          totalOrders: 1248,
          averageOrderValue: 38.72,
          conversionRate: 3.2,
          revenueGrowth: 18.3,
          ordersGrowth: 12.5,
          aovGrowth: 5.2,
          conversionGrowth: 0.8,
        })

        setTopProducts([
          {
            id: "prod-1",
            name: "Smartphone X Pro",
            sales: 124,
            revenue: 123876.76,
            growth: 15.2,
          },
          {
            id: "prod-2",
            name: "Wireless Headphones",
            sales: 98,
            revenue: 78234.5,
            growth: 9.8,
          },
          {
            id: "prod-3",
            name: "Smartwatch Series 7",
            sales: 85,
            revenue: 67543.21,
            growth: 7.5,
          },
        ])

        setTopCategories([
          {
            id: "cat-1",
            name: "Electronics",
            sales: 345,
            revenue: 274892.5,
            growth: 12.3,
          },
          {
            id: "cat-2",
            name: "Clothing",
            sales: 287,
            revenue: 189375.0,
            growth: 8.7,
          },
          {
            id: "cat-3",
            name: "Home & Kitchen",
            sales: 212,
            revenue: 134689.75,
            growth: 5.9,
          },
        ])
      } catch (error) {
        toast({
          title: "Error fetching analytics data.",
          description: "There was a problem fetching the analytics data. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchAnalyticsData()
  }, [])

  return (
    <>
      <div className="container max-w-7xl mx-auto py-6">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-semibold">Analytics</h1>
          <div className="space-x-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={cn(
                    "w-[300px] justify-start text-left font-normal",
                    !dateRange.from && "text-muted-foreground",
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {dateRange.from ? (
                    dateRange.to ? (
                      `${format(dateRange.from, "MMM dd, yyyy")} - ${format(dateRange.to, "MMM dd, yyyy")}`
                    ) : (
                      format(dateRange.from, "MMM dd, yyyy")
                    )
                  ) : (
                    <span>Pick a date</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <DateRangePicker date={dateRange} onDateChange={setDateRange} />
              </PopoverContent>
            </Popover>
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select a timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="180d">Last 180 days</SelectItem>
                <SelectItem value="365d">Last 365 days</SelectItem>
              </SelectContent>
            </Select>
            <Button>
              <Download className="mr-2 h-4 w-4" />
              Download Report
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <Card>
            <CardHeader>
              <CardTitle>Total Revenue</CardTitle>
              <CardDescription>All time revenue</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${metrics.totalRevenue.toLocaleString()}</div>
            </CardContent>
            <CardFooter className="text-sm text-muted-foreground">
              <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
              {metrics.revenueGrowth}%
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Total Orders</CardTitle>
              <CardDescription>All time orders</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.totalOrders.toLocaleString()}</div>
            </CardContent>
            <CardFooter className="text-sm text-muted-foreground">
              <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
              {metrics.ordersGrowth}%
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Average Order Value</CardTitle>
              <CardDescription>Average value per order</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${metrics.averageOrderValue.toLocaleString()}</div>
            </CardContent>
            <CardFooter className="text-sm text-muted-foreground">
              <TrendingDown className="mr-2 h-4 w-4 text-red-500" />
              {metrics.aovGrowth}%
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Conversion Rate</CardTitle>
              <CardDescription>Orders per visit</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.conversionRate}%</div>
            </CardContent>
            <CardFooter className="text-sm text-muted-foreground">
              <TrendingUp className="mr-2 h-4 w-4 text-green-500" />
              {metrics.conversionGrowth}%
            </CardFooter>
          </Card>
        </div>

        <Tabs defaultValue="revenue" className="w-full mb-4">
          <TabsList>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
          </TabsList>
          <TabsContent value="revenue">
            <RevenueChart />
          </TabsContent>
          <TabsContent value="products">
            <ProductPerformanceChart products={topProducts} />
          </TabsContent>
          <TabsContent value="categories">
            <SalesByCategory categories={topCategories} />
          </TabsContent>
        </Tabs>

        <Card>
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Your recent orders</CardDescription>
          </CardHeader>
          <CardContent className="overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">INV20240101</TableCell>
                  <TableCell>John Doe</TableCell>
                  <TableCell>2024-01-01</TableCell>
                  <TableCell>Shipped</TableCell>
                  <TableCell className="text-right">$120.00</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">INV20240102</TableCell>
                  <TableCell>Jane Smith</TableCell>
                  <TableCell>2024-01-02</TableCell>
                  <TableCell>Delivered</TableCell>
                  <TableCell className="text-right">$85.50</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">INV20240103</TableCell>
                  <TableCell>Alice Johnson</TableCell>
                  <TableCell>2024-01-03</TableCell>
                  <TableCell>Pending</TableCell>
                  <TableCell className="text-right">$210.00</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </>
  )
}
