"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { ArrowUpDown, Plus, Search, Edit, Trash2, MoreHorizontal, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"
import { Switch } from "@/components/ui/switch"

// Sample product data
const initialProducts = [
  {
    id: "prod-1",
    name: "Classic Cheeseburger",
    description: "Juicy beef patty with cheddar cheese, lettuce, tomato, onion, and special sauce on a toasted bun",
    price: 9.99,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
    category: "Burgers",
    inventory: 100,
    status: "active",
    featured: true,
    createdAt: "2023-05-15T14:30:00",
    sales: 342,
    revenue: 3416.58,
  },
  {
    id: "prod-2",
    name: "Margherita Pizza",
    description: "Traditional pizza with tomato sauce, fresh mozzarella, and basil on a thin, crispy crust",
    price: 12.99,
    image: "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?q=80&w=1974&auto=format&fit=crop",
    category: "Pizza",
    inventory: 50,
    status: "active",
    featured: true,
    createdAt: "2023-05-10T10:15:00",
    sales: 287,
    revenue: 3728.13,
  },
  {
    id: "prod-3",
    name: "Caesar Salad",
    description: "Crisp romaine lettuce with Caesar dressing, croutons, and parmesan cheese",
    price: 8.99,
    image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?q=80&w=2070&auto=format&fit=crop",
    category: "Salads",
    inventory: 75,
    status: "active",
    featured: false,
    createdAt: "2023-05-12T09:45:00",
    sales: 156,
    revenue: 1402.44,
  },
  {
    id: "prod-4",
    name: "Chocolate Brownie",
    description: "Warm chocolate brownie served with vanilla ice cream and chocolate sauce",
    price: 6.99,
    image: "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?q=80&w=1930&auto=format&fit=crop",
    category: "Desserts",
    inventory: 60,
    status: "active",
    featured: true,
    createdAt: "2023-05-08T16:20:00",
    sales: 198,
    revenue: 1384.02,
  },
  {
    id: "prod-5",
    name: "Spicy Thai Curry",
    description:
      "Authentic Thai curry with your choice of protein, vegetables, and aromatic spices served with jasmine rice",
    price: 14.99,
    image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?q=80&w=2070&auto=format&fit=crop",
    category: "Main Course",
    inventory: 40,
    status: "active",
    featured: false,
    createdAt: "2023-05-05T12:10:00",
    sales: 124,
    revenue: 1858.76,
  },
  {
    id: "prod-6",
    name: "Garlic Bread",
    description: "Toasted bread with garlic butter and herbs",
    price: 4.99,
    image: "https://images.unsplash.com/photo-1573140401455-cff6d6b4d3a2?q=80&w=1974&auto=format&fit=crop",
    category: "Appetizers",
    inventory: 90,
    status: "active",
    featured: false,
    createdAt: "2023-05-14T11:30:00",
    sales: 245,
    revenue: 1222.55,
  },
  {
    id: "prod-7",
    name: "Iced Coffee",
    description: "Cold brewed coffee served over ice with cream and sugar",
    price: 3.99,
    image: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?q=80&w=1974&auto=format&fit=crop",
    category: "Drinks",
    inventory: 120,
    status: "active",
    featured: false,
    createdAt: "2023-05-13T08:45:00",
    sales: 312,
    revenue: 1244.88,
  },
  {
    id: "prod-8",
    name: "Veggie Burger",
    description: "Plant-based patty with lettuce, tomato, onion, and vegan mayo on a whole grain bun",
    price: 10.99,
    image: "https://images.unsplash.com/photo-1520072959219-c595dc870360?q=80&w=2070&auto=format&fit=crop",
    category: "Burgers",
    inventory: 65,
    status: "inactive",
    featured: false,
    createdAt: "2023-05-11T13:25:00",
    sales: 87,
    revenue: 956.13,
  },
]

// Product categories
const categories = [
  { id: "all", name: "All Categories" },
  { id: "burgers", name: "Burgers" },
  { id: "pizza", name: "Pizza" },
  { id: "salads", name: "Salads" },
  { id: "desserts", name: "Desserts" },
  { id: "main-course", name: "Main Course" },
  { id: "appetizers", name: "Appetizers" },
  { id: "drinks", name: "Drinks" },
]

export default function ProductsPage() {
  const router = useRouter()
  const [products, setProducts] = useState(initialProducts)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sortField, setSortField] = useState("name")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")
  const [selectedProduct, setSelectedProduct] = useState<any>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  // Filter and sort products
  const filteredProducts = products
    .filter((product) => {
      // Search filter
      const matchesSearch =
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase())

      // Category filter
      const matchesCategory =
        categoryFilter === "all" || product.category.toLowerCase() === categoryFilter.toLowerCase()

      // Status filter
      const matchesStatus = statusFilter === "all" || product.status === statusFilter

      return matchesSearch && matchesCategory && matchesStatus
    })
    .sort((a, b) => {
      // Sort by selected field
      if (a[sortField as keyof typeof a] < b[sortField as keyof typeof b]) {
        return sortDirection === "asc" ? -1 : 1
      }
      if (a[sortField as keyof typeof a] > b[sortField as keyof typeof b]) {
        return sortDirection === "asc" ? 1 : -1
      }
      return 0
    })

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  const handleToggleStatus = (id: string) => {
    setProducts(
      products.map((product) => {
        if (product.id === id) {
          const newStatus = product.status === "active" ? "inactive" : "active"

          toast({
            title: `Product ${newStatus === "active" ? "activated" : "deactivated"}`,
            description: `${product.name} is now ${newStatus}`,
          })

          return {
            ...product,
            status: newStatus,
          }
        }
        return product
      }),
    )
  }

  const handleToggleFeatured = (id: string) => {
    setProducts(
      products.map((product) => {
        if (product.id === id) {
          const newFeatured = !product.featured

          toast({
            title: `Product ${newFeatured ? "featured" : "unfeatured"}`,
            description: `${product.name} is now ${newFeatured ? "featured" : "no longer featured"}`,
          })

          return {
            ...product,
            featured: newFeatured,
          }
        }
        return product
      }),
    )
  }

  const handleDeleteProduct = () => {
    if (!selectedProduct) return

    setProducts(products.filter((product) => product.id !== selectedProduct.id))
    setIsDeleteDialogOpen(false)

    toast({
      title: "Product deleted",
      description: `${selectedProduct.name} has been deleted`,
      variant: "destructive",
    })
  }

  const handleAddNewProduct = () => {
    router.push("/admin/products/new")
  }

  const handleEditProduct = (id: string) => {
    router.push(`/admin/products/${id}/edit`)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Products</h1>
          <p className="text-muted-foreground">Manage your product catalog</p>
        </div>
        <Button onClick={handleAddNewProduct} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Add Product
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="flex-1">
          <label htmlFor="search" className="text-sm font-medium">
            Search
          </label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              id="search"
              placeholder="Search by name, description, or category..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        <div className="w-full md:w-[180px]">
          <label htmlFor="category-filter" className="text-sm font-medium">
            Category
          </label>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger id="category-filter">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-full md:w-[180px]">
          <label htmlFor="status-filter" className="text-sm font-medium">
            Status
          </label>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger id="status-filter">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[250px]">
                <Button variant="ghost" className="p-0 hover:bg-transparent" onClick={() => handleSort("name")}>
                  <span>Product</span>
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead>Category</TableHead>
              <TableHead>
                <Button variant="ghost" className="p-0 hover:bg-transparent" onClick={() => handleSort("price")}>
                  <span>Price</span>
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead>
                <Button variant="ghost" className="p-0 hover:bg-transparent" onClick={() => handleSort("inventory")}>
                  <span>Inventory</span>
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead>
                <Button variant="ghost" className="p-0 hover:bg-transparent" onClick={() => handleSort("sales")}>
                  <span>Sales</span>
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Featured</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProducts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="h-24 text-center">
                  No products found.
                </TableCell>
              </TableRow>
            ) : (
              filteredProducts.map((product) => (
                <TableRow key={product.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <div className="relative h-10 w-10 rounded-md overflow-hidden">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="truncate max-w-[180px]">
                        <span className="font-medium">{product.name}</span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{product.category}</TableCell>
                  <TableCell>${product.price.toFixed(2)}</TableCell>
                  <TableCell>{product.inventory}</TableCell>
                  <TableCell>{product.sales}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Switch
                        checked={product.status === "active"}
                        onCheckedChange={() => handleToggleStatus(product.id)}
                        className="mr-2"
                      />
                      <Badge
                        variant={product.status === "active" ? "default" : "secondary"}
                        className={
                          product.status === "active"
                            ? "bg-green-100 text-green-800 hover:bg-green-100"
                            : "bg-gray-100 text-gray-800 hover:bg-gray-100"
                        }
                      >
                        {product.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Switch checked={product.featured} onCheckedChange={() => handleToggleFeatured(product.id)} />
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem
                          onClick={() => {
                            setSelectedProduct(product)
                            setIsViewDialogOpen(true)
                          }}
                        >
                          <Eye className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleEditProduct(product.id)}>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => {
                            setSelectedProduct(product)
                            setIsDeleteDialogOpen(true)
                          }}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* View Product Dialog */}
      {selectedProduct && (
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Product Details</DialogTitle>
              <DialogDescription>View product information</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="relative h-48 w-full rounded-lg overflow-hidden">
                <Image
                  src={selectedProduct.image || "/placeholder.svg"}
                  alt={selectedProduct.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h3 className="text-xl font-bold">{selectedProduct.name}</h3>
                <p className="text-sm text-muted-foreground">{selectedProduct.category}</p>
              </div>
              <div>
                <h4 className="font-semibold text-sm">Description</h4>
                <p className="text-sm">{selectedProduct.description}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-sm">Price</h4>
                  <p className="text-lg font-bold">${selectedProduct.price.toFixed(2)}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm">Inventory</h4>
                  <p className="text-lg font-bold">{selectedProduct.inventory}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm">Status</h4>
                  <Badge
                    variant={selectedProduct.status === "active" ? "default" : "secondary"}
                    className={
                      selectedProduct.status === "active"
                        ? "bg-green-100 text-green-800 hover:bg-green-100"
                        : "bg-gray-100 text-gray-800 hover:bg-gray-100"
                    }
                  >
                    {selectedProduct.status === "active" ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div>
                  <h4 className="font-semibold text-sm">Featured</h4>
                  <Badge
                    variant={selectedProduct.featured ? "default" : "secondary"}
                    className={
                      selectedProduct.featured
                        ? "bg-blue-100 text-blue-800 hover:bg-blue-100"
                        : "bg-gray-100 text-gray-800 hover:bg-gray-100"
                    }
                  >
                    {selectedProduct.featured ? "Featured" : "Not Featured"}
                  </Badge>
                </div>
                <div>
                  <h4 className="font-semibold text-sm">Created</h4>
                  <p>{formatDate(selectedProduct.createdAt)}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm">Sales</h4>
                  <p>{selectedProduct.sales} units</p>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-sm">Revenue</h4>
                <p className="text-lg font-bold">${selectedProduct.revenue.toFixed(2)}</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                Close
              </Button>
              <Button
                onClick={() => {
                  setIsViewDialogOpen(false)
                  handleEditProduct(selectedProduct.id)
                }}
              >
                Edit Product
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Product Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Product</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedProduct?.name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteProduct}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
