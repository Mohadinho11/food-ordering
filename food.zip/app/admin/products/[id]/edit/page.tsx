"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import { ArrowLeft, Upload, X, Save, Trash2, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

// Sample product data - in a real app, this would come from an API
const sampleProducts = [
  {
    id: "prod-1",
    name: "Classic Cheeseburger",
    description: "Juicy beef patty with cheddar cheese, lettuce, tomato, onion, and special sauce on a toasted bun",
    price: 9.99,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
    category: "Burgers",
    inventory: 100,
    status: "active",
    featured: true,
    createdAt: "2023-05-15T14:30:00",
    sales: 342,
    revenue: 3416.58,
    sku: "SKU123",
    weight: 0.3,
    dimensions: { length: 15, width: 15, height: 8 },
    metadata: { brand: "BurgerJoint", manufacturer: "LocalFoods", model: "CB100", releaseDate: "2023-01-01" },
    taxable: true,
  },
  {
    id: "prod-2",
    name: "Margherita Pizza",
    description: "Traditional pizza with tomato sauce, fresh mozzarella, and basil on a thin, crispy crust",
    price: 12.99,
    image: "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?q=80&w=1974&auto=format&fit=crop",
    category: "Pizza",
    inventory: 50,
    status: "active",
    featured: true,
    createdAt: "2023-05-10T10:15:00",
    sales: 287,
    revenue: 3728.13,
    sku: "SKU456",
    weight: 0.5,
    dimensions: { length: 30, width: 30, height: 4 },
    metadata: { brand: "PizzaPlace", manufacturer: "GlobalFoods", model: "MP200", releaseDate: "2023-02-15" },
    taxable: false,
  },
  // More products...
]

// Product categories
const categories = [
  { id: "burgers", name: "Burgers" },
  { id: "pizza", name: "Pizza" },
  { id: "salads", name: "Salads" },
  { id: "desserts", name: "Desserts" },
  { id: "main-course", name: "Main Course" },
  { id: "appetizers", name: "Appetizers" },
  { id: "drinks", name: "Drinks" },
]

export default function EditProductPage() {
  const params = useParams()
  const router = useRouter()
  const productId = params.id as string
  const isNewProduct = productId === "new"

  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    inventory: "",
    status: "active",
    featured: false,
    image: "",
    sku: "",
    weight: "",
    dimensions: { length: "", width: "", height: "" },
    metadata: { brand: "", manufacturer: "", model: "", releaseDate: "" },
    taxable: false,
  })

  const [product, setProduct] = useState({
    sku: "",
    weight: "",
    dimensions: { length: "", width: "", height: "" },
    metadata: { brand: "", manufacturer: "", model: "", releaseDate: "" },
    taxable: false,
  })

  // Load product data if editing an existing product
  useEffect(() => {
    if (!isNewProduct) {
      // In a real app, fetch the product data from an API
      const productData = sampleProducts.find((p) => p.id === productId)

      if (productData) {
        setFormData({
          name: productData.name,
          description: productData.description,
          price: productData.price.toString(),
          category: productData.category.toLowerCase(),
          inventory: productData.inventory.toString(),
          status: productData.status,
          featured: productData.featured,
          image: productData.image,
          sku: productData.sku,
          weight: productData.weight.toString(),
          dimensions: {
            length: productData.dimensions.length.toString(),
            width: productData.dimensions.width.toString(),
            height: productData.dimensions.height.toString(),
          },
          metadata: {
            brand: productData.metadata.brand,
            manufacturer: productData.metadata.manufacturer,
            model: productData.metadata.model,
            releaseDate: productData.metadata.releaseDate,
          },
          taxable: productData.taxable,
        })

        setProduct({
          sku: productData.sku,
          weight: productData.weight.toString(),
          dimensions: {
            length: productData.dimensions.length.toString(),
            width: productData.dimensions.width.toString(),
            height: productData.dimensions.height.toString(),
          },
          metadata: {
            brand: productData.metadata.brand,
            manufacturer: productData.metadata.manufacturer,
            model: productData.metadata.model,
            releaseDate: productData.metadata.releaseDate,
          },
          taxable: productData.taxable,
        })

        setImagePreview(productData.image)
      } else {
        toast({
          title: "Product not found",
          description: "The product you're trying to edit doesn't exist.",
          variant: "destructive",
        })
        router.push("/admin/products")
      }
    }

    setIsLoading(false)
  }, [isNewProduct, productId, router])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // In a real app, you would upload the file to a storage service
      // and get back a URL to store in the database
      const reader = new FileReader()
      reader.onload = () => {
        const result = reader.result as string
        setImagePreview(result)
        setFormData((prev) => ({ ...prev, image: result }))
      }
      reader.readAsDataURL(file)
    }
  }

  const handleRemoveImage = () => {
    setImagePreview(null)
    setFormData((prev) => ({ ...prev, image: "" }))
  }

  const validateForm = () => {
    if (!formData.name) {
      toast({
        title: "Name is required",
        description: "Please enter a product name.",
        variant: "destructive",
      })
      return false
    }

    if (!formData.price || isNaN(Number(formData.price)) || Number(formData.price) <= 0) {
      toast({
        title: "Invalid price",
        description: "Please enter a valid price greater than 0.",
        variant: "destructive",
      })
      return false
    }

    if (!formData.category) {
      toast({
        title: "Category is required",
        description: "Please select a product category",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  const handleSave = async () => {
    setIsSaving(true)

    if (!validateForm()) {
      setIsSaving(false)
      return
    }

    try {
      // Simulate API call to save product
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: isNewProduct ? "Product Created" : "Product Updated",
        description: `${formData.name} has been ${isNewProduct ? "created" : "updated"} successfully.`,
      })

      router.push("/admin/products")
    } catch (error) {
      console.error("Error saving product:", error)
      toast({
        title: "Error",
        description: `Failed to ${isNewProduct ? "create" : "update"} product. Please try again.`,
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async () => {
    try {
      // Simulate API call to delete product
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Product Deleted",
        description: `${formData.name} has been deleted successfully.`,
      })

      router.push("/admin/products")
    } catch (error) {
      console.error("Error deleting product:", error)
      toast({
        title: "Error",
        description: "Failed to delete product. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setProduct((prev) => ({ ...prev, [name]: value }))
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNestedChange = (parent: string, child: string, value: string) => {
    setProduct((prev) => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [child]: value,
      },
    }))
    setFormData((prev) => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [child]: value,
      },
    }))
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-200px)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/products">
                <ArrowLeft className="h-4 w-4" />
                <span className="sr-only">Back</span>
              </Link>
            </Button>
            <h1 className="text-3xl font-bold tracking-tight">
              {isNewProduct ? "Add New Product" : `Edit Product: ${formData.name}`}
            </h1>
          </div>
          <p className="text-muted-foreground">
            {isNewProduct ? "Add a new product to your inventory" : "Update product details and inventory"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {!isNewProduct && (
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(true)}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </Button>
          )}
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save
              </>
            )}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="shipping">Shipping</TabsTrigger>
          <TabsTrigger value="attributes">Attributes</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>Enter the basic details about your product</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">
                      Product Name <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Enter product name"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      placeholder="Enter product description"
                      rows={5}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="price">
                        Price <span className="text-destructive">*</span>
                      </Label>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5">$</span>
                        <Input
                          id="price"
                          name="price"
                          value={formData.price}
                          onChange={handleInputChange}
                          placeholder="0.00"
                          className="pl-7"
                          type="number"
                          step="0.01"
                          min="0"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category">
                        Category <span className="text-destructive">*</span>
                      </Label>
                      <Select
                        value={formData.category}
                        onValueChange={(value) => handleSelectChange("category", value)}
                      >
                        <SelectTrigger id="category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Product Metadata</CardTitle>
                  <CardDescription>Additional information about the product</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="brand">Brand</Label>
                      <Input
                        id="brand"
                        value={product.metadata.brand}
                        onChange={(e) => handleNestedChange("metadata", "brand", e.target.value)}
                        placeholder="Enter brand name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="manufacturer">Manufacturer</Label>
                      <Input
                        id="manufacturer"
                        value={product.metadata.manufacturer}
                        onChange={(e) => handleNestedChange("metadata", "manufacturer", e.target.value)}
                        placeholder="Enter manufacturer"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="model">Model</Label>
                      <Input
                        id="model"
                        value={product.metadata.model}
                        onChange={(e) => handleNestedChange("metadata", "model", e.target.value)}
                        placeholder="Enter model number"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="releaseDate">Release Date</Label>
                      <Input
                        id="releaseDate"
                        type="date"
                        value={product.metadata.releaseDate}
                        onChange={(e) => handleNestedChange("metadata", "releaseDate", e.target.value)}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Product Image</CardTitle>
                  <CardDescription>Upload a product image</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-center">
                    <div className="relative w-full h-48 border-2 border-dashed rounded-lg flex items-center justify-center overflow-hidden">
                      {imagePreview ? (
                        <Image
                          src={imagePreview || "/placeholder.svg"}
                          alt="Product Image"
                          className="object-contain"
                          fill
                        />
                      ) : (
                        <div className="text-muted-foreground">No image selected</div>
                      )}
                      <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 hover:opacity-100 transition-opacity">
                        <label htmlFor="image-upload" className="cursor-pointer">
                          <Button variant="secondary" size="sm" asChild>
                            <>
                              <Upload className="mr-2 h-4 w-4" />
                              Change Image
                            </>
                          </Button>
                        </label>
                        {imagePreview && (
                          <Button variant="destructive" size="sm" className="ml-2" onClick={handleRemoveImage}>
                            <X className="mr-2 h-4 w-4" />
                            Remove
                          </Button>
                        )}
                      </div>
                      <Input
                        type="file"
                        id="image-upload"
                        className="hidden"
                        accept="image/*"
                        onChange={handleImageUpload}
                      />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground text-center">Recommended: 1200×1200px, PNG or JPG</p>
                </CardContent>
              </Card>

              <Card className="mt-4">
                <CardHeader>
                  <CardTitle>Product Status</CardTitle>
                  <CardDescription>Control product visibility and features</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="status">Status</Label>
                      <p className="text-sm text-muted-foreground">Set the product's availability</p>
                    </div>
                    <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                      <SelectTrigger id="status" className="w-[140px]">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                        <SelectItem value="draft">Draft</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="featured">Featured Product</Label>
                      <p className="text-sm text-muted-foreground">Display prominently throughout the store</p>
                    </div>
                    <Switch
                      id="featured"
                      checked={formData.featured}
                      onCheckedChange={(checked) => handleSwitchChange("featured", checked)}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="taxable">Taxable Product</Label>
                      <p className="text-sm text-muted-foreground">Apply tax to this product</p>
                    </div>
                    <Switch
                      id="taxable"
                      checked={product.taxable}
                      onCheckedChange={() => handleSwitchChange("taxable", !product.taxable)}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Inventory Management</CardTitle>
              <CardDescription>Manage product stock and SKU</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sku">
                    SKU (Stock Keeping Unit) <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="sku"
                    name="sku"
                    value={product.sku}
                    onChange={handleChange}
                    placeholder="Enter SKU"
                    required
                  />
                  <p className="text-xs text-muted-foreground">A unique identifier for your product</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="inventory">Inventory Quantity</Label>
                  <Input
                    id="inventory"
                    name="inventory"
                    value={formData.inventory}
                    onChange={handleInputChange}
                    placeholder="Enter quantity"
                    type="number"
                    min="0"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shipping" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Shipping Information</CardTitle>
              <CardDescription>Product weight and dimensions for shipping calculations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="weight">Weight (kg)</Label>
                <Input
                  id="weight"
                  name="weight"
                  value={product.weight}
                  onChange={handleChange}
                  placeholder="Enter weight"
                  type="number"
                  step="0.01"
                  min="0"
                />
              </div>

              <div className="space-y-2">
                <Label>Dimensions (cm)</Label>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="length">Length</Label>
                    <Input
                      id="length"
                      value={product.dimensions.length}
                      onChange={(e) => handleNestedChange("dimensions", "length", e.target.value)}
                      placeholder="Length"
                      type="number"
                      step="0.1"
                      min="0"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="width">Width</Label>
                    <Input
                      id="width"
                      value={product.dimensions.width}
                      onChange={(e) => handleNestedChange("dimensions", "width", e.target.value)}
                      placeholder="Width"
                      type="number"
                      step="0.1"
                      min="0"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="height">Height</Label>
                    <Input
                      id="height"
                      value={product.dimensions.height}
                      onChange={(e) => handleNestedChange("dimensions", "height", e.target.value)}
                      placeholder="Height"
                      type="number"
                      step="0.1"
                      min="0"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attributes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Product Attributes</CardTitle>
              <CardDescription>Add custom attributes to your product</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Custom Attributes</Label>
                <p className="text-sm text-muted-foreground">Add key-value pairs for additional product information</p>

                <div className="border rounded-md p-4">
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <Input placeholder="Attribute name" />
                    <Input placeholder="Attribute value" />
                  </div>

                  <Button variant="outline" size="sm" className="w-full">
                    Add Attribute
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the product "{formData.name}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
