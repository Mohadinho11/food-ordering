"use client"

import { useState } from "react"
import { ArrowUpDown, Eye, MoreHorizontal, Search, Trash2, Utensils } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Switch } from "@/components/ui/switch"
import Image from "next/image"

// Sample menu items data
const initialMenuItems = [
  {
    id: "1",
    name: "Classic Cheeseburger",
    restaurant: "Burger Palace",
    description: "Juicy beef patty with cheddar cheese, lettuce, tomato, and special sauce",
    price: 9.99,
    category: "Main Course",
    isVegetarian: false,
    isPopular: true,
    isAvailable: true,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
  },
  {
    id: "2",
    name: "Margherita Pizza",
    restaurant: "Pizza Heaven",
    description: "Traditional pizza with tomato sauce, mozzarella, and fresh basil",
    price: 12.99,
    category: "Main Course",
    isVegetarian: true,
    isPopular: true,
    isAvailable: true,
    image: "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?q=80&w=1974&auto=format&fit=crop",
  },
  {
    id: "3",
    name: "California Roll",
    restaurant: "Sushi World",
    description: "Crab, avocado, and cucumber wrapped in seaweed and rice",
    price: 8.99,
    category: "Appetizer",
    isVegetarian: false,
    isPopular: true,
    isAvailable: true,
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: "4",
    name: "Beef Tacos",
    restaurant: "Taco Fiesta",
    description: "Seasoned ground beef in corn tortillas with lettuce, cheese, and salsa",
    price: 3.99,
    category: "Main Course",
    isVegetarian: false,
    isPopular: false,
    isAvailable: true,
    image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?q=80&w=2080&auto=format&fit=crop",
  },
  {
    id: "5",
    name: "Pad Thai",
    restaurant: "Thai Spice",
    description: "Stir-fried rice noodles with eggs, tofu, bean sprouts, and peanuts",
    price: 12.99,
    category: "Main Course",
    isVegetarian: true,
    isPopular: true,
    isAvailable: false,
    image: "https://images.unsplash.com/photo-1562565652-a0d8f0c59eb4?q=80&w=1932&auto=format&fit=crop",
  },
  {
    id: "6",
    name: "Caesar Salad",
    restaurant: "Burger Palace",
    description: "Romaine lettuce with Caesar dressing, croutons, and parmesan cheese",
    price: 8.99,
    category: "Salad",
    isVegetarian: true,
    isPopular: false,
    isAvailable: true,
    image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: "7",
    name: "Chocolate Brownie",
    restaurant: "Burger Palace",
    description: "Warm chocolate brownie served with vanilla ice cream",
    price: 6.99,
    category: "Dessert",
    isVegetarian: true,
    isPopular: true,
    isAvailable: true,
    image: "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?q=80&w=1930&auto=format&fit=crop",
  },
]

export default function MenuItemsPage() {
  const [menuItems, setMenuItems] = useState(initialMenuItems)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [restaurantFilter, setRestaurantFilter] = useState("all")
  const [availabilityFilter, setAvailabilityFilter] = useState("all")
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedMenuItem, setSelectedMenuItem] = useState<any>(null)

  // Get unique categories and restaurants for filters
  const categories = Array.from(new Set(menuItems.map((item) => item.category)))
  const restaurants = Array.from(new Set(menuItems.map((item) => item.restaurant)))

  // Filter menu items based on search query, category, restaurant, and availability
  const filteredMenuItems = menuItems.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.restaurant.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesCategory = categoryFilter === "all" || item.category === categoryFilter
    const matchesRestaurant = restaurantFilter === "all" || item.restaurant === restaurantFilter
    const matchesAvailability =
      availabilityFilter === "all" ||
      (availabilityFilter === "available" && item.isAvailable) ||
      (availabilityFilter === "unavailable" && !item.isAvailable)

    return matchesSearch && matchesCategory && matchesRestaurant && matchesAvailability
  })

  const handleToggleAvailability = (id: string) => {
    setMenuItems(menuItems.map((item) => (item.id === id ? { ...item, isAvailable: !item.isAvailable } : item)))

    const item = menuItems.find((item) => item.id === id)

    toast({
      title: "Item availability updated",
      description: `${item?.name} is now ${item?.isAvailable ? "unavailable" : "available"}`,
    })
  }

  const handleDeleteMenuItem = () => {
    if (!selectedMenuItem) return

    setMenuItems(menuItems.filter((item) => item.id !== selectedMenuItem.id))
    setIsDeleteDialogOpen(false)

    toast({
      title: "Menu item deleted",
      description: `${selectedMenuItem.name} has been deleted`,
      variant: "destructive",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Menu Items</h1>
          <p className="text-muted-foreground">Manage restaurant menu items</p>
        </div>
        <Button className="flex items-center gap-2">
          <Utensils className="h-4 w-4" />
          Add Menu Item
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="flex-1">
          <label htmlFor="search" className="text-sm font-medium">
            Search
          </label>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              id="search"
              placeholder="Search by name, description, or restaurant..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        <div className="w-full md:w-[180px]">
          <label htmlFor="category-filter" className="text-sm font-medium">
            Category
          </label>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger id="category-filter">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-full md:w-[180px]">
          <label htmlFor="restaurant-filter" className="text-sm font-medium">
            Restaurant
          </label>
          <Select value={restaurantFilter} onValueChange={setRestaurantFilter}>
            <SelectTrigger id="restaurant-filter">
              <SelectValue placeholder="Filter by restaurant" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Restaurants</SelectItem>
              {restaurants.map((restaurant) => (
                <SelectItem key={restaurant} value={restaurant}>
                  {restaurant}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-full md:w-[180px]">
          <label htmlFor="availability-filter" className="text-sm font-medium">
            Availability
          </label>
          <Select value={availabilityFilter} onValueChange={setAvailabilityFilter}>
            <SelectTrigger id="availability-filter">
              <SelectValue placeholder="Filter by availability" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Items</SelectItem>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="unavailable">Unavailable</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[250px]">
                <Button variant="ghost" className="p-0 hover:bg-transparent">
                  <span>Name</span>
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead>Restaurant</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>
                <Button variant="ghost" className="p-0 hover:bg-transparent">
                  <span>Price</span>
                  <ArrowUpDown className="ml-2 h-4 w-4" />
                </Button>
              </TableHead>
              <TableHead>Tags</TableHead>
              <TableHead>Availability</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMenuItems.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">
                  No menu items found.
                </TableCell>
              </TableRow>
            ) : (
              filteredMenuItems.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <div className="relative h-10 w-10 rounded-md overflow-hidden">
                        <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                      </div>
                      {item.name}
                    </div>
                  </TableCell>
                  <TableCell>{item.restaurant}</TableCell>
                  <TableCell>{item.category}</TableCell>
                  <TableCell>${item.price.toFixed(2)}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {item.isVegetarian && (
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Vegetarian
                        </Badge>
                      )}
                      {item.isPopular && <Badge variant="secondary">Popular</Badge>}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={item.isAvailable}
                      onCheckedChange={() => handleToggleAvailability(item.id)}
                      aria-label="Toggle availability"
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem
                          onClick={() => {
                            setSelectedMenuItem(item)
                            setIsViewDialogOpen(true)
                          }}
                        >
                          <Eye className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem>Edit Item</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => {
                            setSelectedMenuItem(item)
                            setIsDeleteDialogOpen(true)
                          }}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* View Menu Item Dialog */}
      {selectedMenuItem && (
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Menu Item Details</DialogTitle>
              <DialogDescription>View menu item information</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="relative h-40 w-full rounded-md overflow-hidden">
                <Image
                  src={selectedMenuItem.image || "/placeholder.svg"}
                  alt={selectedMenuItem.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h3 className="text-xl font-bold">{selectedMenuItem.name}</h3>
                <p className="text-sm text-muted-foreground">{selectedMenuItem.restaurant}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">Description</h3>
                <p className="text-sm">{selectedMenuItem.description}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Price</h3>
                  <p className="font-medium">${selectedMenuItem.price.toFixed(2)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Category</h3>
                  <p className="font-medium">{selectedMenuItem.category}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Availability</h3>
                  <Badge
                    variant="outline"
                    className={
                      selectedMenuItem.isAvailable
                        ? "bg-green-50 text-green-700 border-green-200"
                        : "bg-red-50 text-red-700 border-red-200"
                    }
                  >
                    {selectedMenuItem.isAvailable ? "Available" : "Unavailable"}
                  </Badge>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Tags</h3>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedMenuItem.isVegetarian && (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        Vegetarian
                      </Badge>
                    )}
                    {selectedMenuItem.isPopular && <Badge variant="secondary">Popular</Badge>}
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                Close
              </Button>
              <Button
                variant={selectedMenuItem.isAvailable ? "destructive" : "default"}
                onClick={() => {
                  handleToggleAvailability(selectedMenuItem.id)
                  setSelectedMenuItem({
                    ...selectedMenuItem,
                    isAvailable: !selectedMenuItem.isAvailable,
                  })
                }}
              >
                {selectedMenuItem.isAvailable ? "Mark Unavailable" : "Mark Available"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Menu Item Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Menu Item</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedMenuItem?.name}? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteMenuItem}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
