import Link from "next/link"
import Image from "next/image"
import { Suspense } from "react"
import { ArrowRight, Star, Clock, Utensils, TrendingUp, ThumbsUp } from "lucide-react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { RestaurantCard } from "@/components/restaurant/restaurant-card"
import { CategorySlider } from "@/components/ui/category-slider"
import { TestimonialCard } from "@/components/ui/testimonial-card"
import { FadeIn } from "@/components/animations/fade-in"

// Sample data
const featuredRestaurants = [
  {
    id: "1",
    name: "Burger Palace",
    image: "/placeholder.svg?height=200&width=300",
    cuisine: "American",
    rating: 4.8,
    deliveryTime: "20-30 min",
    deliveryFee: "$2.99",
    minOrder: "$10",
    distance: "1.2 miles",
    isNew: false,
    isFeatured: true,
  },
  {
    id: "2",
    name: "Pizza Heaven",
    image: "/placeholder.svg?height=200&width=300",
    cuisine: "Italian",
    rating: 4.6,
    deliveryTime: "25-35 min",
    deliveryFee: "$1.99",
    minOrder: "$15",
    distance: "0.8 miles",
    isNew: true,
    isFeatured: true,
  },
  {
    id: "3",
    name: "Sushi World",
    image: "/placeholder.svg?height=200&width=300",
    cuisine: "Japanese",
    rating: 4.9,
    deliveryTime: "30-40 min",
    deliveryFee: "$3.99",
    minOrder: "$20",
    distance: "1.5 miles",
    isNew: false,
    isFeatured: true,
  },
  {
    id: "4",
    name: "Taco Fiesta",
    image: "/placeholder.svg?height=200&width=300",
    cuisine: "Mexican",
    rating: 4.7,
    deliveryTime: "15-25 min",
    deliveryFee: "$2.49",
    minOrder: "$12",
    distance: "0.5 miles",
    isNew: false,
    isFeatured: true,
  },
]

const categories = [
  { id: "1", name: "Pizza", icon: "🍕", count: 42 },
  { id: "2", name: "Burgers", icon: "🍔", count: 38 },
  { id: "3", name: "Sushi", icon: "🍣", count: 24 },
  { id: "4", name: "Mexican", icon: "🌮", count: 31 },
  { id: "5", name: "Indian", icon: "🍛", count: 19 },
  { id: "6", name: "Italian", icon: "🍝", count: 27 },
  { id: "7", name: "Chinese", icon: "🥡", count: 33 },
  { id: "8", name: "Thai", icon: "🍲", count: 15 },
  { id: "9", name: "Desserts", icon: "🍰", count: 22 },
  { id: "10", name: "Healthy", icon: "🥗", count: 18 },
]

const testimonials = [
  {
    id: "1",
    name: "Sarah Johnson",
    image: "/placeholder.svg?height=80&width=80",
    rating: 5,
    text: "FoodFlex has completely changed how I order food. The variety of restaurants and the seamless ordering process make it my go-to app for all my food delivery needs!",
  },
  {
    id: "2",
    name: "Michael Chen",
    image: "/placeholder.svg?height=80&width=80",
    rating: 5,
    text: "I love the special offers and discounts available on FoodFlex. The food always arrives hot and on time. Definitely recommend to anyone looking for convenient food delivery.",
  },
  {
    id: "3",
    name: "Emily Rodriguez",
    image: "/placeholder.svg?height=80&width=80",
    rating: 4,
    text: "Great selection of restaurants and cuisines. The app is easy to use and the delivery tracking feature is super helpful. My only wish is for more vegan options!",
  },
]

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-24 bg-gradient-to-br from-food-primary/10 to-food-accent/10">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <FadeIn className="space-y-6">
              <h1 className="text-5xl md:text-6xl font-bold text-food-dark leading-tight">
                Delicious Food <br />
                <span className="text-food-primary">Delivered to Your Door</span>
              </h1>
              <p className="text-lg text-gray-600 max-w-lg">
                Discover the best restaurants in your area and enjoy your favorite meals without leaving the comfort of
                your home.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button className="btn-food-primary text-base h-12 px-8">
                  Order Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button variant="outline" className="btn-food-outline text-base h-12 px-8">
                  View Restaurants
                </Button>
              </div>
              <div className="flex items-center gap-6 pt-4">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-food-accent fill-food-accent" />
                  <span className="font-medium">4.8 Rating</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-food-secondary" />
                  <span className="font-medium">30 min Delivery</span>
                </div>
                <div className="flex items-center gap-2">
                  <Utensils className="h-5 w-5 text-food-primary" />
                  <span className="font-medium">500+ Restaurants</span>
                </div>
              </div>
            </FadeIn>

            <FadeIn delay={0.2} className="relative">
              <div className="relative h-[400px] lg:h-[500px] rounded-2xl overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=500&width=600"
                  alt="Delicious food"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-4 animate-bounce-subtle">
                <div className="flex items-center gap-3">
                  <div className="bg-food-primary/10 rounded-full p-2">
                    <TrendingUp className="h-6 w-6 text-food-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Daily Orders</p>
                    <p className="text-xl font-bold">10,000+</p>
                  </div>
                </div>
              </div>
              <div
                className="absolute -top-6 -right-6 bg-white rounded-xl shadow-lg p-4 animate-bounce-subtle"
                style={{ animationDelay: "1s" }}
              >
                <div className="flex items-center gap-3">
                  <div className="bg-food-secondary/10 rounded-full p-2">
                    <ThumbsUp className="h-6 w-6 text-food-secondary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Happy Customers</p>
                    <p className="text-xl font-bold">50,000+</p>
                  </div>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <FadeIn>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
              <div>
                <h2 className="text-3xl font-bold mb-2">Explore Categories</h2>
                <p className="text-gray-600">Find your favorite cuisine from our wide selection</p>
              </div>
              <Link
                href="/cuisines"
                className="mt-4 md:mt-0 text-food-primary font-medium hover:underline flex items-center"
              >
                View All Categories
                <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </FadeIn>

          <FadeIn delay={0.1}>
            <Suspense fallback={<div className="h-24 bg-gray-100 animate-pulse rounded-xl"></div>}>
              <CategorySlider categories={categories} />
            </Suspense>
          </FadeIn>
        </div>
      </section>

      {/* Featured Restaurants Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <FadeIn>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
              <div>
                <h2 className="text-3xl font-bold mb-2">Featured Restaurants</h2>
                <p className="text-gray-600">Discover the best restaurants in your area</p>
              </div>
              <Link
                href="/restaurants"
                className="mt-4 md:mt-0 text-food-primary font-medium hover:underline flex items-center"
              >
                View All Restaurants
                <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </FadeIn>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
            {featuredRestaurants.map((restaurant, index) => (
              <FadeIn key={restaurant.id} delay={0.1 * (index + 1)}>
                <RestaurantCard restaurant={restaurant} />
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <FadeIn>
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">How It Works</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Ordering your favorite food has never been easier. Follow these simple steps to get started.
              </p>
            </div>
          </FadeIn>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: "🍔",
                title: "Choose a Restaurant",
                description:
                  "Browse through our extensive list of restaurants and cuisines to find what you're craving.",
              },
              {
                icon: "🛒",
                title: "Select Your Meal",
                description: "Explore menus, read reviews, and add your favorite dishes to your cart.",
              },
              {
                icon: "🚚",
                title: "Enjoy Your Delivery",
                description: "Track your order in real-time and enjoy your delicious meal delivered to your doorstep.",
              },
            ].map((step, index) => (
              <FadeIn key={index} delay={0.2 * (index + 1)}>
                <div className="bg-white rounded-xl p-6 shadow-soft hover:shadow-hover transition-all text-center">
                  <div className="text-4xl mb-4 mx-auto">{step.icon}</div>
                  <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <FadeIn>
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">What Our Customers Say</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Don't just take our word for it. Here's what our happy customers have to say about their experience.
              </p>
            </div>
          </FadeIn>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <FadeIn key={testimonial.id} delay={0.1 * (index + 1)}>
                <TestimonialCard testimonial={testimonial} />
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-food-primary/10">
        <div className="container-custom">
          <div className="bg-white rounded-2xl shadow-soft p-8 md:p-12">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <FadeIn>
                <div className="space-y-4">
                  <h2 className="text-3xl md:text-4xl font-bold">Ready to Order Your Favorite Food?</h2>
                  <p className="text-gray-600">
                    Download our mobile app now and enjoy exclusive offers, faster ordering, and real-time delivery
                    tracking.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 pt-4">
                    <Button className="btn-food-primary text-base h-12">Download App</Button>
                    <Button variant="outline" className="btn-food-outline text-base h-12">
                      Order Online
                    </Button>
                  </div>
                </div>
              </FadeIn>

              <FadeIn delay={0.2}>
                <div className="relative h-[300px] rounded-xl overflow-hidden">
                  <Image src="/placeholder.svg?height=300&width=500" alt="Mobile app" fill className="object-cover" />
                </div>
              </FadeIn>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
