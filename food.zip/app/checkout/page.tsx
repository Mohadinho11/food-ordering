"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, CreditCard, MapPin } from "lucide-react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent } from "@/components/ui/card"
import { FadeIn } from "@/components/animations/fade-in"
import { toast } from "@/hooks/use-toast"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { AddressForm } from "@/components/checkout/address-form"
import { DeliveryOptions } from "@/components/checkout/delivery-options"
import { PaymentForm } from "@/components/checkout/payment-form"

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
  restaurant: string
  restaurantId: string
}

interface CheckoutData {
  items: CartItem[]
  subtotal: number
  discount: number
  deliveryFee: number
  tax: number
  total: number
}

export default function CheckoutPage() {
  const router = useRouter()
  const [checkoutData, setCheckoutData] = useState<CheckoutData | null>(null)
  const [activeStep, setActiveStep] = useState<string>("delivery")
  const [isProcessing, setIsProcessing] = useState(false)

  // Form state
  const [deliveryInfo, setDeliveryInfo] = useState({
    fullName: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    deliveryInstructions: "",
    deliveryOption: "standard",
  })

  const [paymentMethod, setPaymentMethod] = useState("credit_card")
  const [cardInfo, setCardInfo] = useState({
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
  })

  // Load checkout data from localStorage on component mount
  useEffect(() => {
    const savedCheckout = localStorage.getItem("checkoutItems")
    if (savedCheckout) {
      try {
        const parsedCheckout = JSON.parse(savedCheckout)
        setCheckoutData(parsedCheckout)
      } catch (error) {
        console.error("Error parsing checkout data:", error)
        router.push("/cart")
      }
    } else {
      // Redirect to cart if no checkout data
      router.push("/cart")
    }
  }, [router])

  const handleDeliveryInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setDeliveryInfo((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleDeliveryOptionChange = (value: string) => {
    setDeliveryInfo((prev) => ({
      ...prev,
      deliveryOption: value,
    }))
  }

  const handleCardInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setCardInfo((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handlePaymentMethodChange = (value: string) => {
    setPaymentMethod(value)
  }

  const validateDeliveryInfo = () => {
    const { fullName, phone, address, city, state, zipCode } = deliveryInfo
    if (!fullName || !phone || !address || !city || !state || !zipCode) {
      toast({
        title: "Missing information",
        description: "Please fill in all required delivery information",
        variant: "destructive",
      })
      return false
    }
    return true
  }

  const validatePaymentInfo = () => {
    if (paymentMethod === "credit_card") {
      const { cardNumber, cardName, expiryDate, cvv } = cardInfo
      if (!cardNumber || !cardName || !expiryDate || !cvv) {
        toast({
          title: "Missing information",
          description: "Please fill in all required payment information",
          variant: "destructive",
        })
        return false
      }

      // Basic validation
      if (cardNumber.replace(/\s/g, "").length !== 16) {
        toast({
          title: "Invalid card number",
          description: "Please enter a valid 16-digit card number",
          variant: "destructive",
        })
        return false
      }

      if (cvv.length < 3) {
        toast({
          title: "Invalid CVV",
          description: "Please enter a valid CVV code",
          variant: "destructive",
        })
        return false
      }
    }
    return true
  }

  const handleContinueToPayment = () => {
    if (validateDeliveryInfo()) {
      setActiveStep("payment")
    }
  }

  const handlePlaceOrder = () => {
    if (!validatePaymentInfo()) return

    setIsProcessing(true)

    // Simulate API call to place order
    setTimeout(() => {
      setIsProcessing(false)

      // Generate random order ID
      const randomOrderId = "ORD-" + Math.floor(10000 + Math.random() * 90000)

      // Save order details to localStorage for confirmation page
      localStorage.setItem(
        "orderConfirmation",
        JSON.stringify({
          orderId: randomOrderId,
          items: checkoutData?.items || [],
          subtotal: checkoutData?.subtotal || 0,
          discount: checkoutData?.discount || 0,
          deliveryFee: checkoutData?.deliveryFee || 0,
          tax: checkoutData?.tax || 0,
          total: checkoutData?.total || 0,
          deliveryInfo,
          paymentMethod,
          cardInfo:
            paymentMethod === "credit_card"
              ? {
                  ...cardInfo,
                  cardNumber: cardInfo.cardNumber.slice(-4).padStart(16, "*"),
                }
              : null,
          orderDate: new Date().toISOString(),
        }),
      )

      // Clear cart and checkout data
      localStorage.removeItem("cartItems")
      localStorage.removeItem("checkoutItems")

      // Redirect to confirmation page
      router.push("/confirmation")
    }, 2000)
  }

  if (!checkoutData) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Loading checkout...</h1>
            <p className="text-gray-600 mb-4">Please wait while we prepare your checkout.</p>
            <Link href="/cart">
              <Button variant="outline">Return to Cart</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        <div className="container-custom">
          <FadeIn>
            <div className="flex items-center gap-2 mb-8">
              <Link href="/cart" className="text-food-primary hover:underline flex items-center">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back to Cart
              </Link>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold mb-8">Checkout</h1>
          </FadeIn>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Checkout Form */}
            <div className="lg:col-span-2">
              <FadeIn delay={0.1}>
                <Accordion
                  type="single"
                  collapsible
                  defaultValue={activeStep}
                  value={activeStep}
                  onValueChange={setActiveStep}
                >
                  <AccordionItem value="delivery" className="border rounded-lg mb-4 bg-white shadow-sm">
                    <AccordionTrigger className="px-6 py-4 hover:no-underline">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary">
                          <MapPin className="h-4 w-4" />
                        </div>
                        <span className="font-semibold">Delivery Information</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-6 pb-6">
                      <AddressForm deliveryInfo={deliveryInfo} onChange={handleDeliveryInfoChange} />

                      <div className="mt-6">
                        <h3 className="font-medium mb-3">Delivery Options</h3>
                        <DeliveryOptions
                          selectedOption={deliveryInfo.deliveryOption}
                          onChange={handleDeliveryOptionChange}
                        />
                      </div>

                      <Button
                        className="mt-6 bg-food-primary hover:bg-food-primary/90 text-white"
                        onClick={handleContinueToPayment}
                      >
                        Continue to Payment
                      </Button>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="payment" className="border rounded-lg mb-4 bg-white shadow-sm">
                    <AccordionTrigger className="px-6 py-4 hover:no-underline">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary">
                          <CreditCard className="h-4 w-4" />
                        </div>
                        <span className="font-semibold">Payment Method</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-6 pb-6">
                      <PaymentForm
                        paymentMethod={paymentMethod}
                        onPaymentMethodChange={handlePaymentMethodChange}
                        cardInfo={cardInfo}
                        onCardInfoChange={handleCardInfoChange}
                      />

                      <Button
                        className="mt-6 bg-food-primary hover:bg-food-primary/90 text-white"
                        onClick={handlePlaceOrder}
                        disabled={isProcessing}
                      >
                        {isProcessing ? "Processing..." : "Place Order"}
                      </Button>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </FadeIn>
            </div>

            {/* Order Summary */}
            <div>
              <FadeIn delay={0.2}>
                <Card className="sticky top-24">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-bold mb-4">Order Summary</h2>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        {checkoutData.items.map((item) => (
                          <div key={item.id} className="flex justify-between text-sm">
                            <span>
                              {item.quantity}x {item.name}
                            </span>
                            <span>${(item.price * item.quantity).toFixed(2)}</span>
                          </div>
                        ))}
                      </div>

                      <Separator />

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Subtotal</span>
                          <span>${checkoutData.subtotal.toFixed(2)}</span>
                        </div>

                        {checkoutData.discount > 0 && (
                          <div className="flex justify-between text-sm text-green-600">
                            <span>Discount</span>
                            <span>-${checkoutData.discount.toFixed(2)}</span>
                          </div>
                        )}

                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Delivery Fee</span>
                          <span>${checkoutData.deliveryFee.toFixed(2)}</span>
                        </div>

                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Tax</span>
                          <span>${checkoutData.tax.toFixed(2)}</span>
                        </div>
                      </div>

                      <Separator />

                      <div className="flex justify-between font-bold">
                        <span>Total</span>
                        <span className="text-food-primary">${checkoutData.total.toFixed(2)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </FadeIn>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
