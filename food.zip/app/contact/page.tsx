"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { FadeIn } from "@/components/animations/fade-in"
import { toast } from "@/hooks/use-toast"
import { MapPin, Phone, Mail, Clock, Send, CheckCircle } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

// Define the form schema with validation
const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  subject: z.string().min(5, { message: "Subject must be at least 5 characters" }),
  message: z.string().min(10, { message: "Message must be at least 10 characters" }),
})

type FormValues = z.infer<typeof formSchema>

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  })

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Show success message
      setIsSuccess(true)
      toast({
        title: "Message sent successfully!",
        description: "We'll get back to you as soon as possible.",
      })

      // Reset form
      reset()

      // Hide success message after 5 seconds
      setTimeout(() => {
        setIsSuccess(false)
      }, 5000)
    } catch (error) {
      toast({
        title: "Error sending message",
        description: "Please try again later.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-food-primary/10 to-food-accent/10 py-12">
          <div className="container-custom">
            <FadeIn>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Contact Us</h1>
              <p className="text-gray-600 max-w-2xl mb-6">
                Have questions, feedback, or want to place a large order? We'd love to hear from you. Reach out to our
                team using the form below or contact information.
              </p>
            </FadeIn>
          </div>
        </div>

        <div className="container-custom py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <FadeIn delay={0.1}>
              <div className="bg-white rounded-xl shadow-sm p-6 md:p-8">
                <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>

                {isSuccess ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="bg-green-100 rounded-full p-3 mb-4">
                      <CheckCircle className="h-12 w-12 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Message Sent Successfully!</h3>
                    <p className="text-gray-600 mb-6">
                      Thank you for reaching out. We'll get back to you as soon as possible.
                    </p>
                    <Button onClick={() => setIsSuccess(false)}>Send Another Message</Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                    <div className="space-y-2">
                      <label htmlFor="name" className="block text-sm font-medium">
                        Your Name <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="name"
                        placeholder="John Doe"
                        {...register("name")}
                        className={errors.name ? "border-red-500" : ""}
                      />
                      {errors.name && <p className="text-red-500 text-sm">{errors.name.message}</p>}
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="email" className="block text-sm font-medium">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="john.doe@example.com"
                        {...register("email")}
                        className={errors.email ? "border-red-500" : ""}
                      />
                      {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="subject" className="block text-sm font-medium">
                        Subject <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="subject"
                        placeholder="How can we help you?"
                        {...register("subject")}
                        className={errors.subject ? "border-red-500" : ""}
                      />
                      {errors.subject && <p className="text-red-500 text-sm">{errors.subject.message}</p>}
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="message" className="block text-sm font-medium">
                        Message <span className="text-red-500">*</span>
                      </label>
                      <Textarea
                        id="message"
                        placeholder="Your message here..."
                        rows={5}
                        {...register("message")}
                        className={errors.message ? "border-red-500" : ""}
                      />
                      {errors.message && <p className="text-red-500 text-sm">{errors.message.message}</p>}
                    </div>

                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4 mr-2" />
                          Send Message
                        </>
                      )}
                    </Button>
                  </form>
                )}
              </div>
            </FadeIn>

            {/* Contact Information */}
            <FadeIn delay={0.2}>
              <div className="space-y-8">
                <div className="bg-white rounded-xl shadow-sm p-6 md:p-8">
                  <h2 className="text-2xl font-bold mb-6">Contact Information</h2>

                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="bg-food-primary/10 rounded-full p-3 shrink-0">
                        <MapPin className="h-6 w-6 text-food-primary" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">Our Location</h3>
                        <p className="text-gray-600">123 Food Street, Cuisine City, FC 12345</p>
                        <a
                          href="https://maps.google.com"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-food-primary hover:underline text-sm mt-1 inline-block"
                        >
                          Get Directions
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="bg-food-secondary/10 rounded-full p-3 shrink-0">
                        <Phone className="h-6 w-6 text-food-secondary" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">Phone Numbers</h3>
                        <p className="text-gray-600">Customer Service: (555) 123-4567</p>
                        <p className="text-gray-600">Order Support: (555) 987-6543</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="bg-food-accent/10 rounded-full p-3 shrink-0">
                        <Mail className="h-6 w-6 text-food-accent" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">Email Addresses</h3>
                        <p className="text-gray-600">General Inquiries: info@foodflex.com</p>
                        <p className="text-gray-600">Support: support@foodf.ex.com</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="bg-purple-100 rounded-full p-3 shrink-0">
                        <Clock className="h-6 w-6 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">Business Hours</h3>
                        <p className="text-gray-600">Monday - Friday: 9:00 AM - 8:00 PM</p>
                        <p className="text-gray-600">Saturday - Sunday: 10:00 AM - 6:00 PM</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm p-6 md:p-8">
                  <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>

                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                      <AccordionTrigger>How do I place an order?</AccordionTrigger>
                      <AccordionContent>
                        You can place an order through our website or mobile app. Simply browse restaurants, select your
                        items, add them to your cart, and proceed to checkout.
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="item-2">
                      <AccordionTrigger>What are your delivery hours?</AccordionTrigger>
                      <AccordionContent>
                        Our delivery hours vary by restaurant, but most restaurants deliver from 10:00 AM to 10:00 PM.
                        You can check specific delivery hours on each restaurant's page.
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="item-3">
                      <AccordionTrigger>How can I track my order?</AccordionTrigger>
                      <AccordionContent>
                        Once your order is confirmed, you can track it in real-time through the "Orders" section of your
                        account. You'll receive updates via email and notifications as your order progresses.
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="item-4">
                      <AccordionTrigger>What payment methods do you accept?</AccordionTrigger>
                      <AccordionContent>
                        We accept credit/debit cards, digital wallets (Apple Pay, Google Pay), and cash on delivery for
                        most orders. Payment options may vary by restaurant.
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </div>
            </FadeIn>
          </div>

          {/* CTA Section */}
          <FadeIn delay={0.3}>
            <div className="mt-16 bg-food-primary/10 rounded-xl p-8 md:p-12 text-center">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Order?</h2>
              <p className="text-gray-600 max-w-2xl mx-auto mb-8">
                Explore our wide selection of restaurants and cuisines. Order now and enjoy delicious food delivered
                straight to your door.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-food-primary hover:bg-food-primary/90 text-white">Browse Restaurants</Button>
                <Button variant="outline">View Menu</Button>
              </div>
            </div>
          </FadeIn>
        </div>
      </main>

      <Footer />
    </div>
  )
}
