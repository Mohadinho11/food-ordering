"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, CheckCircle, Clock } from "lucide-react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { FadeIn } from "@/components/animations/fade-in"
import { OrderSummary } from "@/components/confirmation/order-summary"
import { DeliveryAddress } from "@/components/confirmation/delivery-address"
import { PaymentDetails } from "@/components/confirmation/payment-details"

interface OrderConfirmation {
  orderId: string
  items: any[]
  subtotal: number
  discount: number
  deliveryFee: number
  tax: number
  total: number
  deliveryInfo: any
  paymentMethod: string
  cardInfo: any
  orderDate: string
}

export default function ConfirmationPage() {
  const router = useRouter()
  const [orderData, setOrderData] = useState<OrderConfirmation | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const savedOrder = localStorage.getItem("orderConfirmation")
    if (savedOrder) {
      try {
        const parsedOrder = JSON.parse(savedOrder)
        setOrderData(parsedOrder)
      } catch (error) {
        console.error("Error parsing order data:", error)
        router.push("/")
      }
    } else {
      router.push("/")
    }
    setIsLoading(false)
  }, [router])

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
            <p className="mt-4 text-lg">Loading order confirmation...</p>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  if (!orderData) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 pt-24 pb-16 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Order not found</h1>
            <p className="text-gray-600 mb-4">We couldn't find your order information.</p>
            <Link href="/">
              <Button>Return to Home</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  const estimatedDeliveryTime = new Date(new Date(orderData.orderDate).getTime() + 45 * 60000)
  const formattedDeliveryTime = estimatedDeliveryTime.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  })

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        <div className="container-custom max-w-4xl">
          <FadeIn>
            <div className="flex items-center gap-2 mb-8">
              <Link href="/" className="text-food-primary hover:underline flex items-center">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back to Home
              </Link>
            </div>

            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-6 bg-green-50 border-b border-green-100 flex items-center gap-4">
                <div className="bg-green-100 rounded-full p-2">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-green-800">Order Confirmed!</h1>
                  <p className="text-green-700">Your order #{orderData.orderId} has been placed successfully.</p>
                </div>
              </div>

              <div className="p-6 border-b">
                <div className="flex items-center gap-3 mb-4">
                  <Clock className="h-5 w-5 text-food-primary" />
                  <div>
                    <h2 className="font-medium">Estimated Delivery Time</h2>
                    <p className="text-gray-600">Today, {formattedDeliveryTime}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                  <OrderSummary
                    items={orderData.items}
                    subtotal={orderData.subtotal}
                    discount={orderData.discount}
                    deliveryFee={orderData.deliveryFee}
                    tax={orderData.tax}
                    total={orderData.total}
                  />

                  <DeliveryAddress deliveryInfo={orderData.deliveryInfo} />

                  <PaymentDetails paymentMethod={orderData.paymentMethod} cardInfo={orderData.cardInfo} />
                </div>
              </div>

              <div className="p-6 flex flex-col sm:flex-row gap-4 justify-between items-center">
                <p className="text-gray-600 text-sm text-center sm:text-left">
                  A confirmation email has been sent to your email address.
                </p>
                <div className="flex gap-4">
                  <Link href={`/track-order/${orderData.orderId}`}>
                    <Button variant="outline">Track Order</Button>
                  </Link>
                  <Link href="/restaurants">
                    <Button>Continue Shopping</Button>
                  </Link>
                </div>
              </div>
            </div>
          </FadeIn>
        </div>
      </main>

      <Footer />
    </div>
  )
}
