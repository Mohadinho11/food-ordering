import { type NextRequest, NextResponse } from "next/server"
import Order from "@/models/Order"
import Restaurant from "@/models/Restaurant"
import MenuItem from "@/models/MenuItem"
import { connectToDatabase } from "@/lib/db"
import { verifyAuth } from "@/lib/auth"

// Get orders (filtered by user for customers, all for admin)
export async function GET(request: NextRequest) {
  try {
    await connectToDatabase()

    // Verify authentication
    const authResult = await verifyAuth(request)
    if (!authResult.success) {
      return NextResponse.json({ success: false, message: authResult.error }, { status: authResult.status })
    }

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const restaurant = searchParams.get("restaurant")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    // Build query based on user role
    const query: any = {}

    // Regular users can only see their own orders
    if (authResult.user.role === "customer") {
      query.user = authResult.user.userId
    }
    // Restaurant owners can only see orders for their restaurants
    else if (authResult.user.role === "restaurant_owner") {
      const ownedRestaurants = await Restaurant.find({ owner: authResult.user.userId }).select("_id")
      const restaurantIds = ownedRestaurants.map((r) => r._id)
      query.restaurant = { $in: restaurantIds }
    }
    // Admin can see all orders

    // Add filters
    if (status) {
      query.orderStatus = status
    }

    if (restaurant) {
      query.restaurant = restaurant
    }

    // Execute query with pagination
    const skip = (page - 1) * limit
    const total = await Order.countDocuments(query)
    const orders = await Order.find(query)
      .skip(skip)
      .limit(limit)
      .sort({ createdAt: -1 })
      .populate("user", "name email")
      .populate("restaurant", "name")

    return NextResponse.json({
      success: true,
      count: orders.length,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
      },
      data: orders,
    })
  } catch (error) {
    console.error("Get orders error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}

// Create new order
export async function POST(request: NextRequest) {
  try {
    await connectToDatabase()

    // Verify authentication
    const authResult = await verifyAuth(request)
    if (!authResult.success) {
      return NextResponse.json({ success: false, message: authResult.error }, { status: authResult.status })
    }

    const orderData = await request.json()

    // Set user to current user
    orderData.user = authResult.user.userId

    // Validate order items
    if (!orderData.items || orderData.items.length === 0) {
      return NextResponse.json({ success: false, message: "Order must contain at least one item" }, { status: 400 })
    }

    // Check if restaurant exists
    const restaurant = await Restaurant.findById(orderData.restaurant)
    if (!restaurant) {
      return NextResponse.json({ success: false, message: "Restaurant not found" }, { status: 404 })
    }

    // Verify menu items and calculate total
    let subtotal = 0
    for (const item of orderData.items) {
      const menuItem = await MenuItem.findById(item.menuItem)
      if (!menuItem) {
        return NextResponse.json({ success: false, message: `Menu item ${item.menuItem} not found` }, { status: 404 })
      }

      if (menuItem.restaurant.toString() !== orderData.restaurant) {
        return NextResponse.json(
          { success: false, message: `Menu item ${menuItem.name} does not belong to the selected restaurant` },
          { status: 400 },
        )
      }

      // Set item name and price from database
      item.name = menuItem.name
      item.price = menuItem.price

      subtotal += menuItem.price * item.quantity
    }

    // Calculate tax and total
    const tax = subtotal * 0.1 // 10% tax
    const deliveryFee = 2.99
    const total = subtotal + tax + deliveryFee

    // Set calculated values
    orderData.subtotal = subtotal
    orderData.tax = tax
    orderData.deliveryFee = deliveryFee
    orderData.total = total

    // Set initial status
    orderData.orderStatus = "pending"
    orderData.statusHistory = [{ status: "pending" }]

    // Create order
    const order = await Order.create(orderData)

    return NextResponse.json(
      {
        success: true,
        data: order,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create order error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}
