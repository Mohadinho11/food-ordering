import { type NextRequest, NextResponse } from "next/server"
import Restaurant from "@/models/Restaurant"
import { connectToDatabase } from "@/lib/db"
import { verifyAuth } from "@/lib/auth"

// Get all restaurants with filtering
export async function GET(request: NextRequest) {
  try {
    await connectToDatabase()

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const search = searchParams.get("search")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    // Build query
    const query: any = { status: "active" }

    if (category) {
      query.category = category
    }

    if (search) {
      query.$or = [{ name: { $regex: search, $options: "i" } }, { description: { $regex: search, $options: "i" } }]
    }

    // Execute query with pagination
    const skip = (page - 1) * limit
    const total = await Restaurant.countDocuments(query)
    const restaurants = await Restaurant.find(query).skip(skip).limit(limit).sort({ rating: -1 })

    return NextResponse.json({
      success: true,
      count: restaurants.length,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
      },
      data: restaurants,
    })
  } catch (error) {
    console.error("Get restaurants error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}

// Create new restaurant (admin or restaurant owner only)
export async function POST(request: NextRequest) {
  try {
    await connectToDatabase()

    // Verify authentication
    const authResult = await verifyAuth(request)
    if (!authResult.success) {
      return NextResponse.json({ success: false, message: authResult.error }, { status: authResult.status })
    }

    // Check if user has admin or restaurant_owner role
    if (authResult.user.role !== "admin" && authResult.user.role !== "restaurant_owner") {
      return NextResponse.json({ success: false, message: "Not authorized to create restaurants" }, { status: 403 })
    }

    const restaurantData = await request.json()

    // Set owner to current user if not specified and user is restaurant_owner
    if (authResult.user.role === "restaurant_owner" && !restaurantData.owner) {
      restaurantData.owner = authResult.user.userId
    }

    // Create restaurant
    const restaurant = await Restaurant.create(restaurantData)

    return NextResponse.json(
      {
        success: true,
        data: restaurant,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create restaurant error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}
