import { type NextRequest, NextResponse } from "next/server"
import Restaurant from "@/models/Restaurant"
import { connectToDatabase } from "@/lib/db"
import { verifyAuth } from "@/lib/auth"

// Get single restaurant
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase()

    const restaurant = await Restaurant.findById(params.id)

    if (!restaurant) {
      return NextResponse.json({ success: false, message: "Restaurant not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: restaurant,
    })
  } catch (error) {
    console.error("Get restaurant error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}

// Update restaurant
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase()

    // Verify authentication
    const authResult = await verifyAuth(request)
    if (!authResult.success) {
      return NextResponse.json({ success: false, message: authResult.error }, { status: authResult.status })
    }

    // Get restaurant
    const restaurant = await Restaurant.findById(params.id)
    if (!restaurant) {
      return NextResponse.json({ success: false, message: "Restaurant not found" }, { status: 404 })
    }

    // Check if user is authorized (admin or restaurant owner)
    if (authResult.user.role !== "admin" && restaurant.owner.toString() !== authResult.user.userId) {
      return NextResponse.json({ success: false, message: "Not authorized to update this restaurant" }, { status: 403 })
    }

    const updateData = await request.json()

    // Update restaurant
    const updatedRestaurant = await Restaurant.findByIdAndUpdate(params.id, updateData, {
      new: true,
      runValidators: true,
    })

    return NextResponse.json({
      success: true,
      data: updatedRestaurant,
    })
  } catch (error) {
    console.error("Update restaurant error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}

// Delete restaurant
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase()

    // Verify authentication
    const authResult = await verifyAuth(request)
    if (!authResult.success) {
      return NextResponse.json({ success: false, message: authResult.error }, { status: authResult.status })
    }

    // Get restaurant
    const restaurant = await Restaurant.findById(params.id)
    if (!restaurant) {
      return NextResponse.json({ success: false, message: "Restaurant not found" }, { status: 404 })
    }

    // Check if user is authorized (admin or restaurant owner)
    if (authResult.user.role !== "admin" && restaurant.owner.toString() !== authResult.user.userId) {
      return NextResponse.json({ success: false, message: "Not authorized to delete this restaurant" }, { status: 403 })
    }

    await restaurant.deleteOne()

    return NextResponse.json({
      success: true,
      data: {},
    })
  } catch (error) {
    console.error("Delete restaurant error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}
