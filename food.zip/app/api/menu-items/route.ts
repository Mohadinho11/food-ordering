import { type NextRequest, NextResponse } from "next/server"
import MenuItem from "@/models/MenuItem"
import Restaurant from "@/models/Restaurant"
import { connectToDatabase } from "@/lib/db"
import { verifyAuth } from "@/lib/auth"

// Get all menu items with filtering
export async function GET(request: NextRequest) {
  try {
    await connectToDatabase()

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const restaurant = searchParams.get("restaurant")
    const category = searchParams.get("category")
    const search = searchParams.get("search")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")

    // Build query
    const query: any = { status: "available" }

    if (restaurant) {
      query.restaurant = restaurant
    }

    if (category) {
      query.category = category
    }

    if (search) {
      query.$or = [{ name: { $regex: search, $options: "i" } }, { description: { $regex: search, $options: "i" } }]
    }

    // Execute query with pagination
    const skip = (page - 1) * limit
    const total = await MenuItem.countDocuments(query)
    const menuItems = await MenuItem.find(query).skip(skip).limit(limit).sort({ name: 1 })

    return NextResponse.json({
      success: true,
      count: menuItems.length,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
      },
      data: menuItems,
    })
  } catch (error) {
    console.error("Get menu items error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}

// Create new menu item
export async function POST(request: NextRequest) {
  try {
    await connectToDatabase()

    // Verify authentication
    const authResult = await verifyAuth(request)
    if (!authResult.success) {
      return NextResponse.json({ success: false, message: authResult.error }, { status: authResult.status })
    }

    const menuItemData = await request.json()

    // Check if restaurant exists
    const restaurant = await Restaurant.findById(menuItemData.restaurant)
    if (!restaurant) {
      return NextResponse.json({ success: false, message: "Restaurant not found" }, { status: 404 })
    }

    // Check if user is authorized (admin or restaurant owner)
    if (authResult.user.role !== "admin" && restaurant.owner.toString() !== authResult.user.userId) {
      return NextResponse.json(
        { success: false, message: "Not authorized to add menu items to this restaurant" },
        { status: 403 },
      )
    }

    // Create menu item
    const menuItem = await MenuItem.create(menuItemData)

    return NextResponse.json(
      {
        success: true,
        data: menuItem,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create menu item error:", error)
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 })
  }
}
