import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { FadeIn } from "@/components/animations/fade-in"
import { Separator } from "@/components/ui/separator"
import { Check, ChevronRight, Clock, MapPin, ShieldCheck, Truck, Users } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-food-primary/10 to-food-accent/10 py-16 md:py-24">
          <div className="container-custom">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <FadeIn>
                <h1 className="text-4xl md:text-5xl font-bold mb-4">About FoodFlex</h1>
                <p className="text-lg text-gray-600 mb-6">
                  We're on a mission to make food delivery more convenient, reliable, and delicious than ever before.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button className="bg-food-primary hover:bg-food-primary/90 text-white">Our Restaurants</Button>
                  <Button variant="outline">Contact Us</Button>
                </div>
              </FadeIn>

              <FadeIn delay={0.2}>
                <div className="relative h-[400px] rounded-xl overflow-hidden shadow-xl">
                  <Image
                    src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=2070&auto=format&fit=crop"
                    alt="Food delivery"
                    fill
                    className="object-cover"
                  />
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Our Story Section */}
        <section className="py-16">
          <div className="container-custom">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <FadeIn>
                <div className="relative h-[400px] rounded-xl overflow-hidden shadow-xl">
                  <Image
                    src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=1974&auto=format&fit=crop"
                    alt="Our story"
                    fill
                    className="object-cover"
                  />
                </div>
              </FadeIn>

              <FadeIn delay={0.2}>
                <h2 className="text-3xl font-bold mb-4">Our Story</h2>
                <p className="text-gray-600 mb-4">
                  FoodFlex was founded in 2020 with a simple idea: make it easier for people to enjoy their favorite
                  restaurant meals at home. What started as a small operation in one city has quickly grown into a
                  nationwide service.
                </p>
                <p className="text-gray-600 mb-6">
                  Our team of food enthusiasts and tech experts work together to create the best possible food delivery
                  experience. We partner with top restaurants to bring you a wide variety of cuisines, all delivered
                  fresh and fast.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-food-primary shrink-0 mt-0.5" />
                    <p className="text-gray-600">
                      <span className="font-medium text-gray-900">500+ Restaurant Partners</span> across the country
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-food-primary shrink-0 mt-0.5" />
                    <p className="text-gray-600">
                      <span className="font-medium text-gray-900">50,000+ Happy Customers</span> and growing every day
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-food-primary shrink-0 mt-0.5" />
                    <p className="text-gray-600">
                      <span className="font-medium text-gray-900">30 Minute Average Delivery Time</span> to ensure your
                      food arrives hot and fresh
                    </p>
                  </div>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Our Values Section */}
        <section className="py-16 bg-gray-50">
          <div className="container-custom">
            <FadeIn>
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold mb-4">Our Values</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  At FoodFlex, we're guided by a set of core values that shape everything we do, from how we treat our
                  customers to how we work with our restaurant partners.
                </p>
              </div>
            </FadeIn>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: <Truck className="h-8 w-8 text-food-primary" />,
                  title: "Fast & Reliable Delivery",
                  description:
                    "We know that time matters when you're hungry. That's why we strive to deliver your food as quickly as possible without compromising on quality.",
                },
                {
                  icon: <ShieldCheck className="h-8 w-8 text-food-secondary" />,
                  title: "Quality & Safety",
                  description:
                    "We work only with restaurants that meet our high standards for food quality and safety. Your health and satisfaction are our top priorities.",
                },
                {
                  icon: <Users className="h-8 w-8 text-food-accent" />,
                  title: "Customer First",
                  description:
                    "Our customers are at the heart of everything we do. We're constantly improving our service based on your feedback to provide the best possible experience.",
                },
              ].map((value, index) => (
                <FadeIn key={index} delay={0.1 * (index + 1)}>
                  <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow h-full">
                    <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                      {value.icon}
                    </div>
                    <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                    <p className="text-gray-600">{value.description}</p>
                  </div>
                </FadeIn>
              ))}
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-16">
          <div className="container-custom">
            <FadeIn>
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold mb-4">How It Works</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Ordering your favorite food has never been easier. Follow these simple steps to get started.
                </p>
              </div>
            </FadeIn>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: "🍔",
                  title: "Choose a Restaurant",
                  description:
                    "Browse through our extensive list of restaurants and cuisines to find what you're craving.",
                },
                {
                  icon: "🛒",
                  title: "Select Your Meal",
                  description: "Explore menus, read reviews, and add your favorite dishes to your cart.",
                },
                {
                  icon: "🚚",
                  title: "Enjoy Your Delivery",
                  description:
                    "Track your order in real-time and enjoy your delicious meal delivered to your doorstep.",
                },
              ].map((step, index) => (
                <FadeIn key={index} delay={0.2 * (index + 1)}>
                  <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all text-center relative">
                    {index < 2 && (
                      <div className="hidden md:block absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2 z-10">
                        <ChevronRight className="h-8 w-8 text-gray-300" />
                      </div>
                    )}
                    <div className="text-4xl mb-4 mx-auto">{step.icon}</div>
                    <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                    <p className="text-gray-600">{step.description}</p>
                  </div>
                </FadeIn>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16 bg-gray-50">
          <div className="container-custom">
            <FadeIn>
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  The passionate people behind FoodFlex who work tirelessly to bring you the best food delivery
                  experience.
                </p>
              </div>
            </FadeIn>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  name: "Sarah Johnson",
                  role: "CEO & Founder",
                  image: "https://randomuser.me/api/portraits/women/44.jpg",
                },
                {
                  name: "Michael Chen",
                  role: "CTO",
                  image: "https://randomuser.me/api/portraits/men/32.jpg",
                },
                {
                  name: "Emily Rodriguez",
                  role: "Head of Operations",
                  image: "https://randomuser.me/api/portraits/women/67.jpg",
                },
                {
                  name: "David Wilson",
                  role: "Marketing Director",
                  image: "https://randomuser.me/api/portraits/men/54.jpg",
                },
              ].map((member, index) => (
                <FadeIn key={index} delay={0.1 * (index + 1)}>
                  <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                    <div className="relative h-64 w-full">
                      <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
                    </div>
                    <div className="p-4 text-center">
                      <h3 className="font-bold text-lg">{member.name}</h3>
                      <p className="text-gray-600">{member.role}</p>
                    </div>
                  </div>
                </FadeIn>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16">
          <div className="container-custom">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <FadeIn>
                <h2 className="text-3xl font-bold mb-4">Get In Touch</h2>
                <p className="text-gray-600 mb-6">
                  Have questions, feedback, or want to partner with us? We'd love to hear from you. Reach out to our
                  team using the contact information below.
                </p>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-food-primary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Our Office</p>
                      <p className="text-gray-600">123 Food Street, Cuisine City, FC 12345</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-food-primary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Business Hours</p>
                      <p className="text-gray-600">Monday - Friday: 9:00 AM - 6:00 PM</p>
                      <p className="text-gray-600">Saturday - Sunday: 10:00 AM - 4:00 PM</p>
                    </div>
                  </div>

                  <Separator />

                  <div className="pt-2">
                    <p className="font-medium mb-2">Connect With Us</p>
                    <div className="flex gap-4">
                      <Button variant="outline" size="sm">
                        Email Us
                      </Button>
                      <Button variant="outline" size="sm">
                        Call Us
                      </Button>
                    </div>
                  </div>
                </div>
              </FadeIn>

              <FadeIn delay={0.2}>
                <div className="relative h-[400px] rounded-xl overflow-hidden shadow-xl">
                  <Image
                    src="https://images.unsplash.com/photo-1577563908411-5077b6dc7624?q=80&w=2070&auto=format&fit=crop"
                    alt="Contact us"
                    fill
                    className="object-cover"
                  />
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-food-primary/10">
          <div className="container-custom">
            <div className="bg-white rounded-2xl shadow-sm p-8 md:p-12">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <FadeIn>
                  <div className="space-y-4">
                    <h2 className="text-3xl md:text-4xl font-bold">Ready to Order Your Favorite Food?</h2>
                    <p className="text-gray-600">
                      Download our mobile app now and enjoy exclusive offers, faster ordering, and real-time delivery
                      tracking.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 pt-4">
                      <Button className="bg-food-primary hover:bg-food-primary/90 text-white">Download App</Button>
                      <Link href="/restaurants">
                        <Button variant="outline">Browse Restaurants</Button>
                      </Link>
                    </div>
                  </div>
                </FadeIn>

                <FadeIn delay={0.2}>
                  <div className="relative h-[300px] rounded-xl overflow-hidden">
                    <Image
                      src="https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=2070&auto=format&fit=crop"
                      alt="Mobile app"
                      fill
                      className="object-cover"
                    />
                  </div>
                </FadeIn>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
