"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { RestaurantCard } from "@/components/restaurant/restaurant-card"
import { FadeIn } from "@/components/animations/fade-in"
import { Search, MapPin, Filter } from "lucide-react"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"

// Sample restaurant data
const restaurantsData = [
  {
    id: "rest_1",
    name: "Burger Palace",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
    cuisine: "American",
    rating: 4.8,
    deliveryTime: "20-30 min",
    deliveryFee: "$2.99",
    minOrder: "$10",
    distance: "1.2 miles",
    isNew: false,
    isFeatured: true,
  },
  {
    id: "rest_2",
    name: "Pizza Heaven",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop",
    cuisine: "Italian",
    rating: 4.6,
    deliveryTime: "25-35 min",
    deliveryFee: "$1.99",
    minOrder: "$15",
    distance: "0.8 miles",
    isNew: true,
    isFeatured: true,
  },
  {
    id: "rest_3",
    name: "Sushi World",
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=2070&auto=format&fit=crop",
    cuisine: "Japanese",
    rating: 4.9,
    deliveryTime: "30-40 min",
    deliveryFee: "$3.99",
    minOrder: "$20",
    distance: "1.5 miles",
    isNew: false,
    isFeatured: true,
  },
  {
    id: "rest_4",
    name: "Taco Fiesta",
    image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?q=80&w=2080&auto=format&fit=crop",
    cuisine: "Mexican",
    rating: 4.7,
    deliveryTime: "15-25 min",
    deliveryFee: "$2.49",
    minOrder: "$12",
    distance: "0.5 miles",
    isNew: false,
    isFeatured: true,
  },
  {
    id: "rest_5",
    name: "Thai Spice",
    image: "https://images.unsplash.com/photo-1562565652-a0d8f0c59eb4?q=80&w=1932&auto=format&fit=crop",
    cuisine: "Thai",
    rating: 4.5,
    deliveryTime: "25-35 min",
    deliveryFee: "$2.99",
    minOrder: "$15",
    distance: "1.8 miles",
    isNew: true,
    isFeatured: false,
  },
  {
    id: "rest_6",
    name: "Indian Delight",
    image: "https://images.unsplash.com/photo-1585937421612-70a008356c36?q=80&w=2036&auto=format&fit=crop",
    cuisine: "Indian",
    rating: 4.7,
    deliveryTime: "30-40 min",
    deliveryFee: "$3.49",
    minOrder: "$18",
    distance: "2.2 miles",
    isNew: false,
    isFeatured: false,
  },
  {
    id: "rest_7",
    name: "Pasta Paradise",
    image: "https://images.unsplash.com/photo-1473093295043-cdd812d0e601?q=80&w=2070&auto=format&fit=crop",
    cuisine: "Italian",
    rating: 4.4,
    deliveryTime: "25-35 min",
    deliveryFee: "$2.49",
    minOrder: "$15",
    distance: "1.3 miles",
    isNew: false,
    isFeatured: false,
  },
  {
    id: "rest_8",
    name: "Healthy Greens",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=2070&auto=format&fit=crop",
    cuisine: "Salads",
    rating: 4.3,
    deliveryTime: "15-25 min",
    deliveryFee: "$1.99",
    minOrder: "$12",
    distance: "0.7 miles",
    isNew: true,
    isFeatured: false,
  },
]

// Cuisine categories
const cuisines = [
  { id: "all", name: "All Cuisines" },
  { id: "american", name: "American" },
  { id: "italian", name: "Italian" },
  { id: "japanese", name: "Japanese" },
  { id: "mexican", name: "Mexican" },
  { id: "thai", name: "Thai" },
  { id: "indian", name: "Indian" },
  { id: "salads", name: "Salads" },
]

export default function RestaurantsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCuisine, setSelectedCuisine] = useState("all")
  const [sortOption, setSortOption] = useState("recommended")
  const [filters, setFilters] = useState({
    newOnly: false,
    freeDelivery: false,
    highlyRated: false,
  })
  const [priceRange, setPriceRange] = useState([0, 30])
  const [deliveryTime, setDeliveryTime] = useState("any")
  const [filteredRestaurants, setFilteredRestaurants] = useState(restaurantsData)
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false)

  // Apply filters whenever filter criteria change
  useEffect(() => {
    let filtered = [...restaurantsData]

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (restaurant) =>
          restaurant.name.toLowerCase().includes(query) || restaurant.cuisine.toLowerCase().includes(query),
      )
    }

    // Filter by cuisine
    if (selectedCuisine !== "all") {
      filtered = filtered.filter((restaurant) => restaurant.cuisine.toLowerCase() === selectedCuisine.toLowerCase())
    }

    // Apply additional filters
    if (filters.newOnly) {
      filtered = filtered.filter((restaurant) => restaurant.isNew)
    }

    if (filters.freeDelivery) {
      filtered = filtered.filter((restaurant) => restaurant.deliveryFee === "$0.00")
    }

    if (filters.highlyRated) {
      filtered = filtered.filter((restaurant) => restaurant.rating >= 4.5)
    }

    // Filter by delivery time
    if (deliveryTime !== "any") {
      switch (deliveryTime) {
        case "under30":
          filtered = filtered.filter((restaurant) => {
            const maxTime = Number.parseInt(restaurant.deliveryTime.split("-")[1])
            return maxTime <= 30
          })
          break
        case "under45":
          filtered = filtered.filter((restaurant) => {
            const maxTime = Number.parseInt(restaurant.deliveryTime.split("-")[1])
            return maxTime <= 45
          })
          break
      }
    }

    // Sort restaurants
    switch (sortOption) {
      case "rating":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "delivery-time":
        filtered.sort((a, b) => {
          const aTime = Number.parseInt(a.deliveryTime.split("-")[0])
          const bTime = Number.parseInt(b.deliveryTime.split("-")[0])
          return aTime - bTime
        })
        break
      case "distance":
        filtered.sort((a, b) => {
          const aDist = Number.parseFloat(a.distance.split(" ")[0])
          const bDist = Number.parseFloat(b.distance.split(" ")[0])
          return aDist - bDist
        })
        break
      case "recommended":
      default:
        // Keep the default order or apply a recommendation algorithm
        filtered.sort((a, b) => (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0))
        break
    }

    setFilteredRestaurants(filtered)
  }, [searchQuery, selectedCuisine, sortOption, filters, deliveryTime, priceRange])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Search is already handled by the useEffect
  }

  const handleFilterChange = (filter: keyof typeof filters) => {
    setFilters((prev) => ({
      ...prev,
      [filter]: !prev[filter],
    }))
  }

  const handleClearFilters = () => {
    setSearchQuery("")
    setSelectedCuisine("all")
    setSortOption("recommended")
    setFilters({
      newOnly: false,
      freeDelivery: false,
      highlyRated: false,
    })
    setPriceRange([0, 30])
    setDeliveryTime("any")
  }

  const FilterContent = () => (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">Filters</h3>
          <Button variant="ghost" size="sm" onClick={handleClearFilters} className="h-8 text-muted-foreground">
            Clear All
          </Button>
        </div>

        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-3">Sort By</h4>
            <RadioGroup value={sortOption} onValueChange={setSortOption} className="space-y-2">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="recommended" id="recommended" />
                <Label htmlFor="recommended">Recommended</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="rating" id="rating" />
                <Label htmlFor="rating">Rating</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="delivery-time" id="delivery-time" />
                <Label htmlFor="delivery-time">Delivery Time</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="distance" id="distance" />
                <Label htmlFor="distance">Distance</Label>
              </div>
            </RadioGroup>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-3">Cuisine</h4>
            <RadioGroup value={selectedCuisine} onValueChange={setSelectedCuisine} className="space-y-2">
              {cuisines.map((cuisine) => (
                <div key={cuisine.id} className="flex items-center space-x-2">
                  <RadioGroupItem value={cuisine.id} id={`cuisine-${cuisine.id}`} />
                  <Label htmlFor={`cuisine-${cuisine.id}`}>{cuisine.name}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-3">Delivery Time</h4>
            <RadioGroup value={deliveryTime} onValueChange={setDeliveryTime} className="space-y-2">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="any" id="any-time" />
                <Label htmlFor="any-time">Any Time</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="under30" id="under30" />
                <Label htmlFor="under30">Under 30 minutes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="under45" id="under45" />
                <Label htmlFor="under45">Under 45 minutes</Label>
              </div>
            </RadioGroup>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-3">More Filters</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="new-only"
                  checked={filters.newOnly}
                  onCheckedChange={() => handleFilterChange("newOnly")}
                />
                <Label htmlFor="new-only">New Restaurants</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="free-delivery"
                  checked={filters.freeDelivery}
                  onCheckedChange={() => handleFilterChange("freeDelivery")}
                />
                <Label htmlFor="free-delivery">Free Delivery</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="highly-rated"
                  checked={filters.highlyRated}
                  onCheckedChange={() => handleFilterChange("highlyRated")}
                />
                <Label htmlFor="highly-rated">4.5+ Rating</Label>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium">Price Range</h4>
              <span className="text-sm text-muted-foreground">
                ${priceRange[0]} - ${priceRange[1]}
              </span>
            </div>
            <Slider
              defaultValue={priceRange}
              min={0}
              max={30}
              step={5}
              value={priceRange}
              onValueChange={(value) => setPriceRange(value as [number, number])}
              className="my-6"
            />
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-food-primary/10 to-food-accent/10 py-12">
          <div className="container-custom">
            <FadeIn>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Restaurants Near You</h1>
              <p className="text-gray-600 max-w-2xl mb-6">
                Discover the best restaurants in your area. Filter by cuisine, delivery time, or search for your
                favorites.
              </p>

              <div className="flex flex-col md:flex-row gap-4">
                <form onSubmit={handleSearch} className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search for restaurants or cuisines..."
                      className="pl-10 rounded-full"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </form>

                <div className="flex gap-2">
                  <Button variant="outline" className="rounded-full flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    Current Location
                  </Button>

                  <Sheet open={isFilterSheetOpen} onOpenChange={setIsFilterSheetOpen}>
                    <SheetTrigger asChild>
                      <Button variant="outline" className="rounded-full flex items-center gap-2">
                        <Filter className="h-4 w-4" />
                        Filters
                      </Button>
                    </SheetTrigger>
                    <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto">
                      <SheetHeader>
                        <SheetTitle>Filters</SheetTitle>
                      </SheetHeader>
                      <div className="mt-6">
                        <FilterContent />
                      </div>
                    </SheetContent>
                  </Sheet>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>

        <div className="container-custom py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {/* Filters - Desktop */}
            <div className="hidden md:block">
              <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
                <FilterContent />
              </div>
            </div>

            {/* Restaurant Grid */}
            <div className="md:col-span-2 lg:col-span-3">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">
                  {selectedCuisine === "all"
                    ? "All Restaurants"
                    : cuisines.find((c) => c.id === selectedCuisine)?.name || "Restaurants"}
                </h2>
                <p className="text-muted-foreground">{filteredRestaurants.length} restaurants</p>
              </div>

              {filteredRestaurants.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-xl shadow-sm">
                  <h3 className="text-lg font-medium mb-2">No restaurants found</h3>
                  <p className="text-muted-foreground mb-4">Try adjusting your filters or search criteria</p>
                  <Button onClick={handleClearFilters} variant="outline">
                    Clear all filters
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredRestaurants.map((restaurant, index) => (
                    <FadeIn key={restaurant.id} delay={0.05 * index}>
                      <RestaurantCard restaurant={restaurant} />
                    </FadeIn>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
