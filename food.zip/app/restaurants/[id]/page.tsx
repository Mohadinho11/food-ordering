import Image from "next/image"
import { notFound } from "next/navigation"
import { Star, Clock, MapPin, Phone, Mail, Heart, Share2 } from "lucide-react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MenuItemCard } from "@/components/restaurant/menu-item-card"
import { FadeIn } from "@/components/animations/fade-in"

// This would normally come from a database
const getRestaurant = (id: string) => {
  // Sample restaurant data
  const restaurant = {
    id: "1",
    name: "Burger Palace",
    image: "/placeholder.svg?height=400&width=1200",
    logo: "/placeholder.svg?height=120&width=120",
    cuisine: "American",
    rating: 4.8,
    reviewCount: 243,
    deliveryTime: "20-30 min",
    deliveryFee: "$2.99",
    minOrder: "$10",
    distance: "1.2 miles",
    address: "123 Main St, Anytown, USA",
    phone: "(555) 123-4567",
    email: "info@burgerpalace.com",
    openingHours: {
      monday: "11:00 AM - 10:00 PM",
      tuesday: "11:00 AM - 10:00 PM",
      wednesday: "11:00 AM - 10:00 PM",
      thursday: "11:00 AM - 10:00 PM",
      friday: "11:00 AM - 11:00 PM",
      saturday: "11:00 AM - 11:00 PM",
      sunday: "12:00 PM - 9:00 PM",
    },
    description:
      "Burger Palace offers the juiciest burgers in town, made with 100% premium beef and fresh ingredients. Our menu features a variety of classic and specialty burgers, along with sides, salads, and shakes.",
    isNew: false,
    isFeatured: true,
    categories: [
      { id: "burgers", name: "Burgers" },
      { id: "sides", name: "Sides" },
      { id: "drinks", name: "Drinks" },
      { id: "desserts", name: "Desserts" },
    ],
    menuItems: [
      {
        id: "1",
        name: "Classic Cheeseburger",
        description: "Juicy beef patty with cheddar cheese, lettuce, tomato, onion, and special sauce on a toasted bun",
        price: 8.99,
        image: "/placeholder.svg?height=120&width=120",
        category: "burgers",
        isPopular: true,
        isVegetarian: false,
      },
      {
        id: "2",
        name: "Bacon Deluxe Burger",
        description: "Beef patty topped with crispy bacon, cheddar cheese, lettuce, tomato, and mayo on a toasted bun",
        price: 10.99,
        image: "/placeholder.svg?height=120&width=120",
        category: "burgers",
        isPopular: true,
        isVegetarian: false,
      },
      {
        id: "3",
        name: "Veggie Burger",
        description: "Plant-based patty with lettuce, tomato, onion, and vegan mayo on a whole grain bun",
        price: 9.99,
        image: "/placeholder.svg?height=120&width=120",
        category: "burgers",
        isPopular: false,
        isVegetarian: true,
      },
      {
        id: "4",
        name: "French Fries",
        description: "Crispy golden fries seasoned with sea salt",
        price: 3.99,
        image: "/placeholder.svg?height=120&width=120",
        category: "sides",
        isPopular: true,
        isVegetarian: true,
      },
      {
        id: "5",
        name: "Onion Rings",
        description: "Crispy battered onion rings served with dipping sauce",
        price: 4.99,
        image: "/placeholder.svg?height=120&width=120",
        category: "sides",
        isPopular: false,
        isVegetarian: true,
      },
      {
        id: "6",
        name: "Chocolate Milkshake",
        description: "Rich and creamy chocolate milkshake topped with whipped cream",
        price: 5.99,
        image: "/placeholder.svg?height=120&width=120",
        category: "drinks",
        isPopular: true,
        isVegetarian: true,
      },
      {
        id: "7",
        name: "Soft Drink",
        description: "Your choice of soda (Coke, Diet Coke, Sprite, or Dr. Pepper)",
        price: 2.49,
        image: "/placeholder.svg?height=120&width=120",
        category: "drinks",
        isPopular: false,
        isVegetarian: true,
      },
      {
        id: "8",
        name: "Chocolate Brownie Sundae",
        description: "Warm chocolate brownie topped with vanilla ice cream, chocolate sauce, and whipped cream",
        price: 6.99,
        image: "/placeholder.svg?height=120&width=120",
        category: "desserts",
        isPopular: true,
        isVegetarian: true,
      },
    ],
  }

  return restaurant
}

export default function RestaurantPage({ params }: { params: { id: string } }) {
  const restaurant = getRestaurant(params.id)

  if (!restaurant) {
    notFound()
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-20">
        {/* Restaurant Hero */}
        <div className="relative h-[300px] md:h-[400px]">
          <Image
            src={restaurant.image || "/placeholder.svg"}
            alt={restaurant.name}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>

          <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
            <div className="container-custom">
              <div className="flex flex-col md:flex-row md:items-end gap-6">
                <div className="relative h-24 w-24 md:h-32 md:w-32 rounded-xl overflow-hidden border-4 border-white shadow-lg">
                  <Image
                    src={restaurant.logo || "/placeholder.svg"}
                    alt={`${restaurant.name} logo`}
                    fill
                    className="object-cover"
                  />
                </div>

                <div className="flex-1">
                  <h1 className="text-3xl md:text-4xl font-bold mb-2">{restaurant.name}</h1>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mb-2">
                    <span className="text-food-accent">{restaurant.cuisine}</span>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-food-accent text-food-accent" />
                      <span>{restaurant.rating}</span>
                      <span className="text-gray-300">({restaurant.reviewCount} reviews)</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{restaurant.deliveryTime}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{restaurant.distance}</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge className="bg-food-primary/90 hover:bg-food-primary text-white border-none">
                      Delivery Fee: {restaurant.deliveryFee}
                    </Badge>
                    <Badge className="bg-food-secondary/90 hover:bg-food-secondary text-white border-none">
                      Min Order: {restaurant.minOrder}
                    </Badge>
                  </div>
                </div>

                <div className="flex gap-2 mt-4 md:mt-0">
                  <Button
                    variant="outline"
                    size="icon"
                    className="rounded-full bg-white/20 border-white/50 text-white hover:bg-white/30 hover:text-white"
                  >
                    <Heart className="h-5 w-5" />
                    <span className="sr-only">Save</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="rounded-full bg-white/20 border-white/50 text-white hover:bg-white/30 hover:text-white"
                  >
                    <Share2 className="h-5 w-5" />
                    <span className="sr-only">Share</span>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Restaurant Content */}
        <div className="container-custom py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Menu Section */}
            <div className="lg:col-span-2">
              <FadeIn>
                <Tabs defaultValue="burgers" className="w-full">
                  <div className="overflow-x-auto pb-2">
                    <TabsList className="bg-muted/50 p-1">
                      {restaurant.categories.map((category) => (
                        <TabsTrigger
                          key={category.id}
                          value={category.id}
                          className="data-[state=active]:bg-white data-[state=active]:text-food-primary"
                        >
                          {category.name}
                        </TabsTrigger>
                      ))}
                    </TabsList>
                  </div>

                  {restaurant.categories.map((category) => (
                    <TabsContent key={category.id} value={category.id} className="mt-6 space-y-6">
                      <div className="space-y-4">
                        <h2 className="text-2xl font-bold">{category.name}</h2>
                        <div className="space-y-4">
                          {restaurant.menuItems
                            .filter((item) => item.category === category.id)
                            .map((item, index) => (
                              <FadeIn key={item.id} delay={0.05 * index}>
                                <MenuItemCard item={item} />
                              </FadeIn>
                            ))}
                        </div>
                      </div>
                    </TabsContent>
                  ))}
                </Tabs>
              </FadeIn>
            </div>

            {/* Restaurant Info Section */}
            <div>
              <FadeIn delay={0.2}>
                <div className="bg-white rounded-xl shadow-card p-6 sticky top-24">
                  <h2 className="text-xl font-bold mb-4">Restaurant Information</h2>

                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">About</h3>
                      <p className="text-gray-600 text-sm">{restaurant.description}</p>
                    </div>

                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">Contact</h3>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-food-primary shrink-0 mt-0.5" />
                          <span className="text-gray-600">{restaurant.address}</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-food-primary shrink-0" />
                          <a href={`tel:${restaurant.phone}`} className="text-gray-600 hover:text-food-primary">
                            {restaurant.phone}
                          </a>
                        </li>
                        <li className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-food-primary shrink-0" />
                          <a href={`mailto:${restaurant.email}`} className="text-gray-600 hover:text-food-primary">
                            {restaurant.email}
                          </a>
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">Opening Hours</h3>
                      <ul className="space-y-1 text-sm">
                        {Object.entries(restaurant.openingHours).map(([day, hours]) => (
                          <li key={day} className="flex justify-between">
                            <span className="capitalize text-gray-600">{day}</span>
                            <span className="font-medium">{hours}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-2">
                      <Button className="w-full bg-food-primary hover:bg-food-primary/90 text-white">
                        View on Map
                      </Button>
                    </div>
                  </div>
                </div>
              </FadeIn>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
