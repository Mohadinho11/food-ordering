"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft } from "lucide-react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { FadeIn } from "@/components/animations/fade-in"
import { MenuItemsList } from "@/components/menu/menu-items-list"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample restaurant data - in a real app, this would come from an API
const restaurant = {
  id: "rest-1",
  name: "Burger Palace",
  description: "Serving the juiciest burgers in town since 2010",
  image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
  coverImage: "https://images.unsplash.com/photo-1555992336-fb0d29498b13?q=80&w=2064&auto=format&fit=crop",
  logo: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
  rating: 4.8,
  reviewCount: 243,
  address: "123 Main St, Anytown, USA",
  phone: "(555) 123-4567",
  categories: [
    { id: "burgers", name: "Burgers", icon: "🍔" },
    { id: "sides", name: "Sides", icon: "🍟" },
    { id: "desserts", name: "Dess erts", icon: "🍦" },
    { id: "drinks", name: "Drinks", icon: "🥤" },
  ],
  menuItems: [
    {
      id: "item-1",
      name: "Classic Cheeseburger",
      description: "Juicy beef patty with cheddar cheese, lettuce, tomato, onion, and special sauce on a toasted bun",
      price: 9.99,
      image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1899&auto=format&fit=crop",
      category: "burgers",
      isVegetarian: false,
      isVegan: false,
      isGlutenFree: false,
      isPopular: true,
      rating: 4.8,
      restaurant: "Burger Palace",
      restaurantId: "rest-1",
    },
    {
      id: "item-2",
      name: "Bacon Deluxe Burger",
      description: "Beef patty topped with crispy bacon, cheddar cheese, lettuce, tomato, and mayo on a toasted bun",
      price: 11.99,
      image: "https://images.unsplash.com/photo-1553979459-d2229ba7433b?q=80&w=1968&auto=format&fit=crop",
      category: "burgers",
      isVegetarian: false,
      isVegan: false,
      isGlutenFree: false,
      isPopular: true,
      rating: 4.7,
      restaurant: "Burger Palace",
      restaurantId: "rest-1",
    },
    {
      id: "item-3",
      name: "Veggie Burger",
      description: "Plant-based patty with lettuce, tomato, onion, and vegan mayo on a whole grain bun",
      price: 10.99,
      image: "https://images.unsplash.com/photo-1520072959219-c595dc870360?q=80&w=2070&auto=format&fit=crop",
      category: "burgers",
      isVegetarian: true,
      isVegan: true,
      isGlutenFree: false,
      isPopular: false,
      rating: 4.5,
      restaurant: "Burger Palace",
      restaurantId: "rest-1",
    },
    {
      id: "item-4",
      name: "French Fries",
      description: "Crispy golden fries seasoned with sea salt",
      price: 3.99,
      image: "https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?q=80&w=1925&auto=format&fit=crop",
      category: "sides",
      isVegetarian: true,
      isVegan: true,
      isGlutenFree: true,
      isPopular: true,
      rating: 4.6,
      restaurant: "Burger Palace",
      restaurantId: "rest-1",
    },
    {
      id: "item-5",
      name: "Onion Rings",
      description: "Crispy battered onion rings served with dipping sauce",
      price: 4.99,
      image: "https://images.unsplash.com/photo-1639024471283-03518883512d?q=80&w=1974&auto=format&fit=crop",
      category: "sides",
      isVegetarian: true,
      isVegan: false,
      isGlutenFree: false,
      isPopular: false,
      rating: 4.4,
      restaurant: "Burger Palace",
      restaurantId: "rest-1",
    },
    {
      id: "item-6",
      name: "Chocolate Milkshake",
      description: "Rich and creamy chocolate milkshake topped with whipped cream",
      price: 5.99,
      image: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?q=80&w=1974&auto=format&fit=crop",
      category: "drinks",
      isVegetarian: true,
      isVegan: false,
      isGlutenFree: true,
      isPopular: true,
      rating: 4.9,
      restaurant: "Burger Palace",
      restaurantId: "rest-1",
    },
    {
      id: "item-7",
      name: "Soft Drink",
      description: "Your choice of soda (Coke, Diet Coke, Sprite, or Dr. Pepper)",
      price: 2.49,
      image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=2070&auto=format&fit=crop",
      category: "drinks",
      isVegetarian: true,
      isVegan: true,
      isGlutenFree: true,
      isPopular: false,
      rating: 4.3,
      restaurant: "Burger Palace",
      restaurantId: "rest-1",
    },
    {
      id: "item-8",
      name: "Chocolate Brownie Sundae",
      description: "Warm chocolate brownie topped with vanilla ice cream, chocolate sauce, and whipped cream",
      price: 6.99,
      image: "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?q=80&w=1930&auto=format&fit=crop",
      category: "desserts",
      isVegetarian: true,
      isVegan: false,
      isGlutenFree: false,
      isPopular: true,
      rating: 4.8,
      restaurant: "Burger Palace",
      restaurantId: "rest-1",
    },
  ],
}

export default function RestaurantMenuPage() {
  const params = useParams()
  const restaurantId = params.id as string
  const [activeCategory, setActiveCategory] = useState("all")

  // Filter menu items by category
  const getFilteredItems = (category: string) => {
    if (category === "all") {
      return restaurant.menuItems
    }
    return restaurant.menuItems.filter((item) => item.category === category)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-16">
        {/* Restaurant Header */}
        <div className="relative h-[250px] md:h-[300px] overflow-hidden">
          <Image
            src={restaurant.coverImage || "/placeholder.svg"}
            alt={restaurant.name}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>

          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="container-custom">
              <div className="flex items-end gap-4">
                <div className="relative h-20 w-20 md:h-24 md:w-24 rounded-xl overflow-hidden border-4 border-white shadow-lg">
                  <Image
                    src={restaurant.logo || "/placeholder.svg"}
                    alt={`${restaurant.name} logo`}
                    fill
                    className="object-cover"
                  />
                </div>

                <div className="flex-1 text-white">
                  <h1 className="text-2xl md:text-3xl font-bold">{restaurant.name}</h1>
                  <p className="text-sm md:text-base opacity-90">{restaurant.description}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container-custom py-6">
          <FadeIn>
            <div className="flex items-center gap-2 mb-6">
              <Link
                href={`/restaurants/${restaurantId}`}
                className="text-food-primary hover:underline flex items-center"
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back to Restaurant
              </Link>
            </div>

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
              <h2 className="text-2xl font-bold">Menu</h2>

              <div className="flex items-center gap-4 mt-2 md:mt-0">
                <Button className="bg-food-primary hover:bg-food-primary/90 text-white">Start Order</Button>
              </div>
            </div>
          </FadeIn>

          <FadeIn delay={0.1}>
            <Tabs defaultValue="all" value={activeCategory} onValueChange={setActiveCategory} className="w-full">
              <div className="overflow-x-auto pb-2">
                <TabsList className="bg-muted/50 p-1">
                  <TabsTrigger value="all">All Items</TabsTrigger>
                  {restaurant.categories.map((category) => (
                    <TabsTrigger
                      key={category.id}
                      value={category.id}
                      className="data-[state=active]:bg-white data-[state=active]:text-food-primary"
                    >
                      {category.icon} {category.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </div>

              <TabsContent value="all" className="mt-6">
                <div className="bg-white rounded-xl shadow-sm p-6">
                  <MenuItemsList items={getFilteredItems("all")} title="All Menu Items" />
                </div>
              </TabsContent>

              {restaurant.categories.map((category) => (
                <TabsContent key={category.id} value={category.id} className="mt-6">
                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <MenuItemsList items={getFilteredItems(category.id)} title={category.name} />
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </FadeIn>
        </div>
      </main>

      <Footer />
    </div>
  )
}
