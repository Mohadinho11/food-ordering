"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { ArrowLeft, Trash2, Plus, Minus, ShoppingBag, Clock } from "lucide-react"
import { Header } from "@/components/ui/header"
import { Footer } from "@/components/ui/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { FadeIn } from "@/components/animations/fade-in"
import { useRouter } from "next/navigation"
import { toast } from "@/hooks/use-toast"

// Sample cart data with unique IDs
const initialCartItems = [
  {
    id: "item_1",
    name: "Classic Cheeseburger",
    price: 8.99,
    quantity: 2,
    image: "/placeholder.svg?height=80&width=80",
    restaurant: "Burger Palace",
    restaurantId: "rest_1",
  },
  {
    id: "item_2",
    name: "French Fries",
    price: 3.99,
    quantity: 1,
    image: "/placeholder.svg?height=80&width=80",
    restaurant: "Burger Palace",
    restaurantId: "rest_1",
  },
  {
    id: "item_3",
    name: "Chocolate Milkshake",
    price: 5.99,
    quantity: 1,
    image: "/placeholder.svg?height=80&width=80",
    restaurant: "Burger Palace",
    restaurantId: "rest_1",
  },
]

export default function CartPage() {
  const [cartItems, setCartItems] = useState(initialCartItems)
  const [promoCode, setPromoCode] = useState("")
  const [promoApplied, setPromoApplied] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  // Load cart items from localStorage on component mount
  useEffect(() => {
    const savedCart = localStorage.getItem("cartItems")
    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart)
        if (Array.isArray(parsedCart) && parsedCart.length > 0) {
          setCartItems(parsedCart)
        }
      } catch (error) {
        console.error("Error parsing cart data:", error)
      }
    }
  }, [])

  // Save cart items to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems))
  }, [cartItems])

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity === 0) {
      removeItem(id)
      return
    }

    setCartItems((prev) => prev.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))

    toast({
      title: "Cart updated",
      description: "Item quantity has been updated",
    })
  }

  const removeItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id))

    toast({
      title: "Item removed",
      description: "Item has been removed from your cart",
      variant: "destructive",
    })
  }

  const applyPromoCode = () => {
    if (promoCode.trim() === "") {
      toast({
        title: "Error",
        description: "Please enter a promo code",
        variant: "destructive",
      })
      return
    }

    // Simulate API call to validate promo code
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)

      // For demo purposes, accept any promo code
      setPromoApplied(true)
      toast({
        title: "Promo code applied",
        description: "10% discount has been applied to your order",
      })
    }, 1000)
  }

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast({
        title: "Empty cart",
        description: "Please add items to your cart before checkout",
        variant: "destructive",
      })
      return
    }

    // Save cart to localStorage for checkout page
    localStorage.setItem(
      "checkoutItems",
      JSON.stringify({
        items: cartItems,
        subtotal,
        discount,
        deliveryFee,
        tax,
        total,
      }),
    )

    router.push("/checkout")
  }

  // Calculate totals
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const discount = promoApplied ? subtotal * 0.1 : 0 // 10% discount
  const deliveryFee = cartItems.length > 0 ? 2.99 : 0
  const tax = (subtotal - discount) * 0.08 // 8% tax
  const total = subtotal - discount + deliveryFee + tax

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        <div className="container-custom">
          <FadeIn>
            <div className="flex items-center gap-2 mb-8">
              <Link href="/restaurants" className="text-food-primary hover:underline flex items-center">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Continue Shopping
              </Link>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold mb-8">Your Cart</h1>
          </FadeIn>

          {cartItems.length === 0 ? (
            <FadeIn delay={0.1}>
              <div className="text-center py-16">
                <div className="mx-auto w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center mb-6">
                  <ShoppingBag className="h-12 w-12 text-gray-400" />
                </div>
                <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
                <p className="text-gray-600 mb-8">Looks like you haven't added any items to your cart yet.</p>
                <Link href="/restaurants">
                  <Button className="bg-food-primary hover:bg-food-primary/90 text-white">Browse Restaurants</Button>
                </Link>
              </div>
            </FadeIn>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                <FadeIn delay={0.1}>
                  <div className="bg-white rounded-xl shadow-card p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-xl font-bold">Cart Items</h2>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-food-secondary" />
                        <span>Estimated delivery: 30-45 min</span>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <AnimatePresence initial={false}>
                        {cartItems.map((item) => (
                          <motion.div
                            key={item.id}
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.3 }}
                            className="overflow-hidden"
                          >
                            <div className="flex gap-4">
                              <div className="relative h-20 w-20 rounded-md overflow-hidden shrink-0">
                                <Image
                                  src={item.image || "/placeholder.svg"}
                                  alt={item.name}
                                  fill
                                  className="object-cover"
                                />
                              </div>

                              <div className="flex-1">
                                <div className="flex justify-between">
                                  <div>
                                    <h3 className="font-medium">{item.name}</h3>
                                    <p className="text-sm text-gray-500">{item.restaurant}</p>
                                  </div>
                                  <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                                </div>

                                <div className="flex items-center justify-between mt-4">
                                  <div className="flex items-center gap-3">
                                    <Button
                                      variant="outline"
                                      size="icon"
                                      className="h-8 w-8 rounded-full border-gray-300"
                                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                      aria-label={`Decrease quantity of ${item.name}`}
                                    >
                                      <Minus className="h-3 w-3" />
                                    </Button>
                                    <span className="font-medium w-4 text-center">{item.quantity}</span>
                                    <Button
                                      variant="outline"
                                      size="icon"
                                      className="h-8 w-8 rounded-full border-gray-300"
                                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                      aria-label={`Increase quantity of ${item.name}`}
                                    >
                                      <Plus className="h-3 w-3" />
                                    </Button>
                                  </div>

                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-red-500 hover:bg-red-50 hover:text-red-600 px-2 h-8"
                                    onClick={() => removeItem(item.id)}
                                    aria-label={`Remove ${item.name} from cart`}
                                  >
                                    <Trash2 className="h-4 w-4 mr-1" />
                                    Remove
                                  </Button>
                                </div>
                              </div>
                            </div>

                            <Separator className="mt-6" />
                          </motion.div>
                        ))}
                      </AnimatePresence>
                    </div>
                  </div>
                </FadeIn>
              </div>

              {/* Order Summary */}
              <div>
                <FadeIn delay={0.2}>
                  <div className="bg-white rounded-xl shadow-card p-6 sticky top-24">
                    <h2 className="text-xl font-bold mb-6">Order Summary</h2>

                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Subtotal</span>
                        <span className="font-medium">${subtotal.toFixed(2)}</span>
                      </div>

                      {promoApplied && (
                        <div className="flex justify-between text-green-600">
                          <span>Discount (10%)</span>
                          <span>-${discount.toFixed(2)}</span>
                        </div>
                      )}

                      <div className="flex justify-between">
                        <span className="text-gray-600">Delivery Fee</span>
                        <span className="font-medium">${deliveryFee.toFixed(2)}</span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-gray-600">Tax</span>
                        <span className="font-medium">${tax.toFixed(2)}</span>
                      </div>

                      <Separator />

                      <div className="flex justify-between">
                        <span className="font-bold">Total</span>
                        <span className="font-bold text-food-primary">${total.toFixed(2)}</span>
                      </div>

                      <div className="pt-4">
                        <div className="flex gap-2 mb-4">
                          <Input
                            type="text"
                            placeholder="Promo code"
                            value={promoCode}
                            onChange={(e) => setPromoCode(e.target.value)}
                            className="flex-1"
                            disabled={promoApplied || isLoading}
                            aria-label="Enter promo code"
                          />
                          <Button
                            variant="outline"
                            className="border-food-primary text-food-primary hover:bg-food-primary/10"
                            onClick={applyPromoCode}
                            disabled={promoApplied || isLoading}
                          >
                            {isLoading ? "Applying..." : "Apply"}
                          </Button>
                        </div>

                        <Button
                          className="w-full bg-food-primary hover:bg-food-primary/90 text-white h-12"
                          onClick={handleCheckout}
                        >
                          Proceed to Checkout
                        </Button>

                        <p className="text-xs text-gray-500 text-center mt-4">
                          By proceeding to checkout, you agree to our Terms of Service and Privacy Policy.
                        </p>
                      </div>
                    </div>
                  </div>
                </FadeIn>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
